---
toc_max_heading_level: 3
hide_title: true
---

# IEventListenerItem

Defined in: [interfaces/items/IEventListenerItem.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IEventListenerItem.ts#L112)

Event listener item.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | The unique item identifier used by the service to recognize the item | [interfaces/items/IEventListenerItem.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IEventListenerItem.ts#L117) |
| <a id="eventtype"></a> `eventType` | [`Events`](../../enums/Events.md#events) | The event type which will be executed. Presently the following events are available: CREATE, RENAME, ROOM_CREATE, ROOM_EDIT, CHANGE_COLUMN, CHANGE_USER_TYPE, CREATE_PLUGIN_FILE. | [interfaces/items/IEventListenerItem.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IEventListenerItem.ts#L124) |
| <a id="eventhandler"></a> `eventHandler` | () => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | A function that will be executed when the event is triggered. This function can be asynchronous. After the event is executed, only updating the items or displaying toast is possible, other actions are blocked. | [interfaces/items/IEventListenerItem.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IEventListenerItem.ts#L132) |
| <a id="userstypes"></a> `usersTypes?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who have the access to the current item. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the current item will be available for all user types. | [interfaces/items/IEventListenerItem.ts:140](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IEventListenerItem.ts#L140) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current item will be available. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the current item will be available in any device types. | [interfaces/items/IEventListenerItem.ts:148](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IEventListenerItem.ts#L148) |
### Examples

Automatic room categorization with role-based access

```typescript
const roomCategorizer: IEventListenerItem = {
  key: "auto-categorize-room",
  eventType: Events.ROOM_CREATE,
  eventHandler: async () => {
    try {
      await categorizationService.processNewRoom();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Room Categorized Successfully",
          message: "Room categorized successfully | Category: New Category | Status: Success"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "warning",
          title: "Room Categorization Skipped",
          message: "Error occurred during categorization | Status: Failed"
        }]
      };
    }
  },
  usersTypes: [UsersType.docSpaceAdmin, UsersType.roomAdmin],
  devices: [Devices.desktop]
}
```

File rename audit logging with permission control

```typescript
const fileRenameTracker: IEventListenerItem = {
  key: "file-rename-tracker",
  eventType: Events.RENAME,
  eventHandler: async () => {
    try {
      await auditService.logFileRename();
      return {
        actions: [Actions.updateItems],
        itemList: await getUpdatedFileList()
      };
    } catch (error) {
      console.error("Failed to log file rename:", error);
    }
  },
  usersTypes: [
    UsersType.owner,
    UsersType.docSpaceAdmin,
    UsersType.roomAdmin,
    UsersType.collaborator
  ]
}
```

Device-aware column layout change notification

```typescript
const columnChangeNotifier: IEventListenerItem = {
  key: "column-change-notifier",
  eventType: Events.CHANGE_COLUMN,
  eventHandler: () => {
    return {
      actions: [Actions.showToast],
      toastProps: [{
        type: "info",
        title: "Column Layout Updated",
        message: "Column layout updated successfully | New layout applied"
      }]
    };
  },
  devices: [Devices.desktop, Devices.tablet]
}
```

