---
toc_max_heading_level: 3
hide_title: true
---

# IMainButtonItem

Defined in: [interfaces/items/IMainButtonItem.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L95)

Describes an item that will be embedded in the More item of the main button menu. It is available only inside a room (folder) and is not available for the room list.

<img alt="main-button-plugin" src="/assets/images/docspace/main-button-plugin.png" style={{width: "400px"}} />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | The unique item identifier used by the service to recognize the item | [interfaces/items/IMainButtonItem.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L100) |
| <a id="label"></a> `label` | `string` | The item display name | [interfaces/items/IMainButtonItem.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L106) |
| <a id="icon"></a> `icon` | `string` | The item display icon. The icon image must be uploaded to the assets folder. Only the image name with the extension must be specified in this field. The required icon size is 16x16 px. Otherwise, it will be compressed to this size. | [interfaces/items/IMainButtonItem.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L114) |
| <a id="onclick"></a> ~~`onClick?`~~ | (`id`: `number`) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | A function that takes the folder/room id as an argument. This function can be asynchronous. **Deprecated** Use `onItemClick` instead to support both string and number IDs. This method will be removed in a future major version. | [interfaces/items/IMainButtonItem.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L123) |
| <a id="onitemclick"></a> `onItemClick?` | (`id`: `string` \| `number`) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Callback invoked when the main button action is triggered. Supports both string and number identifiers. **Remarks** This is the preferred method over the deprecated `onClick`. | [interfaces/items/IMainButtonItem.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L134) |
| <a id="userstype"></a> `usersType?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who will see the current item in the main button menu. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the current main button item will be displayed for all user types. | [interfaces/items/IMainButtonItem.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L143) |
| <a id="items"></a> `items?` | [`IMainButtonItem`](#imainbuttonitem)[] | The main button items that are added to the current item as a drop-down list. In this case, the onClick event does not work. | [interfaces/items/IMainButtonItem.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L149) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current item will be displayed in the main button menu. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the current main button item will be displayed in any device types. | [interfaces/items/IMainButtonItem.ts:156](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IMainButtonItem.ts#L156) |
### Examples

PDF export functionality with progress feedback

```typescript
const exportToPdf: IMainButtonItem = {
  key: "export-pdf",
  label: "Export to PDF",
  icon: "pdf-icon.svg",
  onItemClick: async (folderId) => {
    try {
      const result = await exportFiles(folderId, "pdf");
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Export Complete",
          message: "Files exported to PDF | Processing complete | Ready to download"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Export Failed",
          message: "Unable to export files | Check file permissions"
        }]
      };
    }
  }
};
```

File backup system with status notifications

```typescript
const backupFiles: IMainButtonItem = {
  key: "backup-files",
  label: "Backup Files",
  icon: "backup-icon.svg",
  onItemClick: async (folderId) => {
    try {
      const backup = await createBackup(folderId);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Backup Complete",
          message: "Backup created successfully | Files archived | Ready for storage"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Backup Failed",
          message: "Unable to create backup | Check storage space"
        }]
      };
    }
  }
};
```

