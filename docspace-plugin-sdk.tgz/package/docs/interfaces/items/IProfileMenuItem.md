---
toc_max_heading_level: 3
hide_title: true
---

# IProfileMenuItem

Defined in: [interfaces/items/IProfileMenuItem.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L95)

Describes an item that will be embedded in the profile menu.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | The unique item identifier used by the service to recognize the item | [interfaces/items/IProfileMenuItem.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L97) |
| <a id="label"></a> `label` | `string` | The item display name | [interfaces/items/IProfileMenuItem.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L100) |
| <a id="icon"></a> `icon` | `string` | The item display icon. The icon image must be uploaded to the assets folder. Only the image name with the extension must be specified in this field. The required icon size is 16x16 px. Otherwise, it will be compressed to this size. | [interfaces/items/IProfileMenuItem.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L107) |
| <a id="onclick"></a> `onClick` | () => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | A function that takes the file/folder/room id as an argument. This function can be asynchronous. | [interfaces/items/IProfileMenuItem.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L113) |
| <a id="userstype"></a> `usersType?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who will see the current item in the profile menu. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the current profile menu item will be displayed for all user types. | [interfaces/items/IProfileMenuItem.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L120) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current item will be displayed in the profile menu. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the current profile menu item will be displayed in any device types. | [interfaces/items/IProfileMenuItem.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IProfileMenuItem.ts#L127) |
### Examples

API key management with status monitoring

```typescript
const apiKeyManager: IProfileMenuItem = {
  key: "api-keys",
  label: "API Keys",
  icon: "key-icon.svg",
  onClick: async () => {
    try {
      const keys = await fetchApiKeys();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "API Keys Status",
          message: "Keys retrieved successfully | Usage within limits | No expiring keys"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Failed to fetch API keys",
          message: "Unable to retrieve keys | Check permissions"
        }]
      };
    }
  }
};
```

Service integration health checker

```typescript
const integrationSettings: IProfileMenuItem = {
  key: "integrations",
  label: "Integrations",
  icon: "integration-icon.svg",
  onClick: async () => {
    try {
      const status = await checkIntegrations();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Integration Status",
          message: "All integrations active | Services connected | Sync complete"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Failed to check integrations",
          message: "Unable to verify integrations | Check connection"
        }]
      };
    }
  }
};
```

