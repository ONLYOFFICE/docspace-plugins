---
toc_max_heading_level: 3
hide_title: true
---

# IInfoPanelItem

Defined in: [interfaces/items/IInfoPanelItem.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L124)

The info panel item that is displayed in the info panel.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | The unique item identifier used by the service to recognize the item | [interfaces/items/IInfoPanelItem.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L129) |
| <a id="submenu"></a> `subMenu` | [`IInfoPanelSubMenu`](#iinfopanelsubmenu) | The item submenu | [interfaces/items/IInfoPanelItem.ts:135](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L135) |
| <a id="body"></a> `body` | [`IBox`](../components/IBox.md#ibox) | The tab UI of the info panel | [interfaces/items/IInfoPanelItem.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L141) |
| <a id="isheadervisible"></a> `isHeaderVisible?` | `boolean` | The property that controls whether the header is visible in the info panel. By default, the header is visible. | [interfaces/items/IInfoPanelItem.ts:148](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L148) |
| <a id="onload"></a> `onLoad?` | () => `Promise`\<\{ `body`: [`IBox`](../components/IBox.md#ibox); \}\> | A function that is executed after opening a tab. It returns a new body. If this functionality is not needed, the old body value is returned. | [interfaces/items/IInfoPanelItem.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L154) |
| <a id="filestype"></a> `filesType?` | [`FilesType`](../../enums/Files.md#filestype)[] | The types of files where the current item will be displayed in the info panel. Presently the following file types are available: room, file, folder, image, video. If this parameter is not specified, then the current info panel item will be displayed in any file type. | [interfaces/items/IInfoPanelItem.ts:162](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L162) |
| <a id="filesexsts"></a> `filesExsts?` | `string`[] | The extensions of files where the current item will be displayed in the info panel. It only works if the FilesType.Files is specified in the fileType parameter. If this parameter is not specified, then the current info panel item will be displayed in any file extension. | [interfaces/items/IInfoPanelItem.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L170) |
| <a id="userstypes"></a> `usersTypes?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who will see the current item in the info panel. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the current info panel item will be displayed for all user types. | [interfaces/items/IInfoPanelItem.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L178) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current item will be displayed in the info panel. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the current info panel item will be displayed in any device types. | [interfaces/items/IInfoPanelItem.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L186) |
### Examples

AI-powered document analysis with error handling

```typescript
const documentAnalysis: IInfoPanelItem = {
  key: "ai-analysis",
  title: "AI Analysis",
  icon: "ai-icon.svg",
  onClick: async (id) => {
    try {
      const analysis = await analyzeDocument(id);
      await exportAnalysis(id, analysis);

      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Document Analysis Complete",
          message: "Analysis completed | Report generated | Export finished"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Analysis failed",
          message: "Unable to analyze document | Check file format"
        }]
      };
    }
  }
}
```

Image metadata viewer with file type restrictions

```typescript
const imageMetadata: IInfoPanelItem = {
  key: "image-metadata",
  title: "Image Info",
  icon: "image-info.svg",
  onClick: async (id) => {
    try {
      const metadata = await getImageMetadata(id);
      await copyToClipboard(metadata);

      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Image Information",
          message: "Metadata retrieved | Details copied | Ready to use"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Failed to load metadata",
          message: "Unable to read image info | Check file access"
        }]
      };
    }
  },
  filesType: [FilesType.Files],
  filesExsts: [
    FilesExst.jpeg,
    FilesExst.jpg,
    FilesExst.png,
    FilesExst.gif,
    FilesExst.bmp
  ]
}
```

## IInfoPanelSubMenu

Defined in: [interfaces/items/IInfoPanelItem.ts:29](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L29)

Describes the item submenu.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="name"></a> `name` | `string` | The tab display name | [interfaces/items/IInfoPanelItem.ts:31](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L31) |
| <a id="onclick"></a> `onClick?` | (`id`: `number`) => \| `void` \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | A function that takes the file/folder/room id as an argument. This function can be asynchronous. It will be executed when clicking on the tab. | [interfaces/items/IInfoPanelItem.ts:37](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L37) |

***

