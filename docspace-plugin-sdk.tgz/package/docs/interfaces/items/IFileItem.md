---
toc_max_heading_level: 3
hide_title: true
---

# IFileItem

Defined in: [interfaces/items/IFileItem.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L137)

Describes an item that will be embedded in the file list.
The file item can be displayed as a file or a folder.

<img alt="file-icon" src="/assets/images/docspace/file-icon.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="extension"></a> `extension` | `string` | The file extension. If several plugins have the same extension, the last plugin from this list is taken | [interfaces/items/IFileItem.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L139) |
| <a id="onclick"></a> `onClick` | (`item`: [`File`](#file)) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | A function that takes the File object with the file data as an argument. This function can be asynchronous. It will be executed when the user clicks on a file with the required extension. | [interfaces/items/IFileItem.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L145) |
| <a id="userstype"></a> `usersType?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who have the access to the current item. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the current item will be available for all user types. | [interfaces/items/IFileItem.ts:152](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L152) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current item will be available. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the current item will be available in any device types. | [interfaces/items/IFileItem.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L159) |
| <a id="filetypename"></a> `fileTypeName?` | `string` | A file type which is displayed in the list (for example, Document/Folder) | [interfaces/items/IFileItem.ts:162](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L162) |
| <a id="filerowicon"></a> `fileRowIcon?` | `string` | A file icon which is displayed in the table format. The preferred icon size is 32x32 px | [interfaces/items/IFileItem.ts:165](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L165) |
| <a id="filetileicon"></a> `fileTileIcon?` | `string` | A file icon which is displayed in the tile format. The preferred icon size is 96x96 px | [interfaces/items/IFileItem.ts:168](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L168) |
| <a id="filesecurity"></a> `fileSecurity?` | [`FilesSecurity`](../../enums/Files.md#filessecurity)[] | The security parameters of the file that will be checked. | [interfaces/items/IFileItem.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L171) |
| <a id="security"></a> `security?` | [`Security`](../../enums/Security.md#security)[] | The security parameters of the parent folder or room that will be checked. | [interfaces/items/IFileItem.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L174) |

***

### Examples

3D model viewer with format validation

```typescript
const modelViewer: IFileItem = {
  key: "3d-model",
  extensions: [".obj", ".stl", ".fbx"],
  onClick: async (file) => {
    try {
      const modelData = await load3DModel(file.id);
      await downloadModel(file.id);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "3D Model Info",
          message: "Model loaded successfully | Rendering started | Processing complete"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Failed to load 3D model",
          message: "Unable to process 3D model | Check file format"
        }]
      };
    }
  }
}
```

Markdown content processor with error handling

```typescript
const markdownPreview: IFileItem = {
  key: "markdown",
  extensions: [".md", ".markdown"],
  onClick: async (file) => {
    try {
      const content = await fetchMarkdownContent(file.id);
      await saveMarkdown(file.id, content);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Markdown File Processed",
          message: "File processed successfully | Content saved | Ready to view"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Failed to process markdown",
          message: "Unable to process markdown file | Check file format"
        }]
      };
    }
  }
}
```

Interactive audio player with metadata support

```typescript
const audioPlayer: IFileItem = {
  key: "audio-player",
  extensions: [".mp3", ".wav", ".ogg"],
  onClick: async (file) => {
    try {
      const audioMetadata = await getAudioMetadata(file.id);
      await playAudio(file.id);
      return {
        actions: [Actions.showToast, Actions.updateContext],
        toastProps: [{
          type: "success",
          title: "Audio Playback",
          message: "Audio file loaded | Playback started | Ready to stream"
        }],
        contextProps: [{
          name: "audio-player",
          props: {
            isPlaying: true,
            currentTime: 0
          }
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Failed to play audio file",
          message: "Unable to play audio file | Check file format"
        }]
      };
    }
  }
}
```

## File

Defined in: [interfaces/items/IFileItem.ts:182](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L182)

Describes the file properties.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="folderid"></a> `folderId` | `number` | The folder ID where the current file is located | [interfaces/items/IFileItem.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L184) |
| <a id="fileexst"></a> `fileExst` | `string` | The file extension | [interfaces/items/IFileItem.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L187) |
| <a id="id"></a> `id` | `number` | The file ID | [interfaces/items/IFileItem.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L190) |
| <a id="rootfoldertype"></a> `rootFolderType` | `number` | The root folder type of the current file | [interfaces/items/IFileItem.ts:193](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L193) |
| <a id="rootfolderid"></a> `rootFolderId` | `number` | The root folder ID of the current file | [interfaces/items/IFileItem.ts:196](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L196) |
| <a id="title"></a> `title` | `string` | The file title | [interfaces/items/IFileItem.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L199) |
| <a id="viewurl"></a> `viewUrl` | `string` | The URL to open the current file in the viewer | [interfaces/items/IFileItem.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L202) |
| <a id="weburl"></a> `webUrl` | `string` | The absolute URL where the source viewed or edited document is stored | [interfaces/items/IFileItem.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L205) |
