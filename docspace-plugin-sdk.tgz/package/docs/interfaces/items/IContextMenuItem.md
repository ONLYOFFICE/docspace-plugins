---
toc_max_heading_level: 3
hide_title: true
---

# IContextMenuItem

Defined in: [interfaces/items/IContextMenuItem.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L166)

Describes an item that will be embedded in the context menu.

<img alt="context-menu-plugin" src="/assets/images/docspace/context-menu-plugin.png" style={{width: "400px"}} />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | The unique item identifier used by the service to recognize the item | [interfaces/items/IContextMenuItem.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L171) |
| <a id="label"></a> `label` | `string` | The item display name | [interfaces/items/IContextMenuItem.ts:177](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L177) |
| <a id="icon"></a> `icon` | `string` | The item display icon. The icon image must be uploaded to the "assets" folder. Only the image name with the extension must be specified in this field. The required icon size is 16x16 px. Otherwise, it will be compressed to this size. | [interfaces/items/IContextMenuItem.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L185) |
| <a id="onclick"></a> ~~`onClick?`~~ | (`id`: `number`) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Callback invoked when the action is triggered for a single selected file, folder, or room. **Remarks** This callback is executed only for single selection. If `isGroupAction` is set to `true`, this callback will not be triggered. **Deprecated** Use `onItemClick` instead to support both string and number IDs. This method will be removed in a future major version. | [interfaces/items/IContextMenuItem.ts:200](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L200) |
| <a id="onitemclick"></a> `onItemClick?` | (`id`: `string` \| `number`) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Callback invoked when the action is triggered for a single selected file, folder, or room. Supports both string and number identifiers. **Remarks** This callback is executed only for single selection. If `isGroupAction` is set to `true`, this callback will not be triggered. This is the preferred method over the deprecated `onClick`. | [interfaces/items/IContextMenuItem.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L213) |
| <a id="ongroupclick"></a> `onGroupClick?` | (`items`: `GroupItem`[]) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Callback invoked when the action is triggered for multiple selected files, folders, or rooms. **Remarks** To make the action appear in the group actions menu, set `isGroupAction` to `true`. When `isGroupAction` is `true`, the action will not be shown for single selected items. | [interfaces/items/IContextMenuItem.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L227) |
| <a id="isgroupaction"></a> `isGroupAction?` | `boolean` | Indicates whether this item should be displayed in the group actions context menu when multiple files, folders, or rooms are selected. | [interfaces/items/IContextMenuItem.ts:236](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L236) |
| <a id="withactiveitem"></a> `withActiveItem?` | `boolean` | Whether to add the action state to the item in the file list when the onClick event is triggered | [interfaces/items/IContextMenuItem.ts:242](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L242) |
| <a id="fileext"></a> `fileExt?` | `string`[] | The extensions of files where the current item will be displayed in the context menu. It only works if the FilesType.Files is specified in the fileType parameter. If this parameter is not specified, then the current context menu item will be displayed in any file extension. | [interfaces/items/IContextMenuItem.ts:250](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L250) |
| <a id="filetype"></a> `fileType?` | [`FilesType`](../../enums/Files.md#filestype)[] | The types of files where the current item will be displayed in the context menu. Presently the following file types are available: room, file, folder, image, video. If this parameter is not specified, then the current context menu item will be displayed in any file type. | [interfaces/items/IContextMenuItem.ts:258](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L258) |
| <a id="items"></a> `items?` | `Omit`\<[`IContextMenuItem`](#icontextmenuitem), `"items"` \| `"placement"`\>[] | Specifies elements as submenus. If specified, onClick on the parent will not work. If none of the child elements are displayed, for example due to security or itemSecurity, the parent will also be hidden. Max level of the menu is 2. | [interfaces/items/IContextMenuItem.ts:266](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L266) |
| <a id="userstypes"></a> `usersTypes?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who will see the current item in the context menu. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the current context menu item will be displayed for all user types. | [interfaces/items/IContextMenuItem.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L274) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current item will be displayed in the context menu. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the current context menu item will be displayed in any device types. | [interfaces/items/IContextMenuItem.ts:282](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L282) |
| <a id="security"></a> `security?` | [`Security`](../../enums/Security.md#security)[] | The security parameters of the parent folder or room that will be checked. If all the parameters are true, the current item will be displayed in the context menu. If this parameter is undefined, it will be ignored. | [interfaces/items/IContextMenuItem.ts:290](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L290) |
| <a id="itemsecurity"></a> `itemSecurity?` | ( \| [`FilesSecurity`](../../enums/Files.md#filessecurity) \| [`Security`](../../enums/Security.md#security))[] | The security parameters of the file or folder or room that will be checked. If all the parameters are true, the current item will be displayed in the context menu. If this parameter is undefined, it will be ignored. | [interfaces/items/IContextMenuItem.ts:298](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L298) |
| <a id="placement"></a> `placement?` | `"top"` \| `"topLast"` | Defines where the item appears in the context menu (top block only). - `top` — inserted at the very beginning of the menu, before all other items in the top block. - `topLast` — inserted at the end of the top block, just before the first separator. - If not specified, the item is placed inside the "More Options" submenu (default behavior). Only applies to root-level items. Nested items (`items[]`) ignore this property. | [interfaces/items/IContextMenuItem.ts:308](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L308) |
### Examples

File analysis with progress reporting

```typescript
const analyzeFile: IContextMenuItem = {
  key: "analyze-file",
  label: "Analyze File",
  icon: "analysis-icon.svg",
  onItemClick: async (fileId) => {
    try {
      const analysis = await analyzeFile(fileId);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "File Analysis Complete",
          message: "Analysis completed successfully | Report generated | Ready to view"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Analysis Failed",
          message: "Unable to analyze file | Check file access"
        }]
      };
    }
  }
};
```

Secure file sharing with clipboard integration

```typescript
const shareFile: IContextMenuItem = {
  key: "share-file",
  label: "Share File",
  icon: "share-icon.svg",
  onItemClick: async (fileId) => {
    try {
      const shareInfo = await generateShareLink(fileId);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Share Link Generated",
          message: "Link generated successfully | Ready to share | Copied to clipboard"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Share Failed",
          message: "Unable to generate share link | Check permissions"
        }]
      };
    }
  }
};
```

Nested context menu items from previous examples

```typescript
const manageFile: IContextMenuItem = {
  key: "manage-file",
  label: "Manage File",
  icon: "manage-file-icon.svg",
  items: [
    shareFile,
    analyzeFile
 ]
};
```

Group action for multiple selected items

```typescript
const exportFiles: IContextMenuItem = {
  key: "export-files",
  label: "Export Selected",
  icon: "export-icon.svg",
  isGroupAction: true,
  fileType: [FilesType.file, FilesType.folder],
  onGroupClick: async (items) => {
    const count = items.length;

    const filesIds = items
                  .filter((item) => item.itemType === "file")
                  .map((item) => item.id);

    const foldersIds = items
                  .filter((item) => item.itemType === "folder")
                  .map((item) => item.id);

    return {
      actions: [Actions.showToast],
      toastProps: [{
        type: "success",
        title: "Export Started",
        message: `Exporting ${count} items...`
      }]
    };
  }
};
```

