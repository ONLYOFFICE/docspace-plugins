---
toc_max_heading_level: 3
hide_title: true
---

# IArticleButtonItem

Defined in: [interfaces/items/IArticleButtonItem.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IArticleButtonItem.ts#L83)

Describes a button item that will be embedded in the article sidebar.
Article button items are displayed as custom plugin components above the DevTools section.
Maximum 5 items can be displayed at once.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | The unique item identifier used by the service to recognize the item | [interfaces/items/IArticleButtonItem.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IArticleButtonItem.ts#L87) |
| <a id="body"></a> `body` | [`IBox`](../components/IBox.md#ibox) | The body of the article button item. This is the main content that will be displayed. Recommended size: 32x32 pixels to fit properly in the article sidebar. | [interfaces/items/IArticleButtonItem.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IArticleButtonItem.ts#L93) |
| <a id="onload"></a> `onLoad?` | () => `Promise`\<\{ `body`: [`IBox`](../components/IBox.md#ibox); \}\> | A function that is executed after the article button item is loaded. It returns a new body. If this functionality is not needed, the old body value is returned. | [interfaces/items/IArticleButtonItem.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IArticleButtonItem.ts#L99) |
| <a id="userstypes"></a> `usersTypes?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who will see the current button item in the article. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the item will be displayed for all user types. | [interfaces/items/IArticleButtonItem.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IArticleButtonItem.ts#L106) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the current button item will be displayed. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the item will be displayed on all device types. | [interfaces/items/IArticleButtonItem.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IArticleButtonItem.ts#L113) |
### Examples

Article button item with custom component

```typescript
const notificationItem: IArticleButtonItem = {
  key: "notifications-item",
  body: {
    component: Components.box,
    props: {
      children: [
        {
          component: Components.button,
          props: {
            label: "Notifications",
            onClick: async () => {
              // Handle click
            }
          }
        }
      ]
    }
  },
  usersTypes: [UsersType.owner, UsersType.docSpaceAdmin]
};
```

Plugin settings access button item with onLoad

```typescript
const settingsItem: IArticleButtonItem = {
  key: "plugin-settings-item",
  body: {
    component: Components.skeleton,
    props: { width: "100%", height: "32px" }
  },
  onLoad: async () => {
    return {
      body: {
        component: Components.button,
        props: {
          label: "Settings",
          onClick: async () => { }
        }
      }
    };
  },
  usersTypes: [UsersType.owner, UsersType.docSpaceAdmin],
  devices: [Devices.desktop, Devices.tablet]
};
```

