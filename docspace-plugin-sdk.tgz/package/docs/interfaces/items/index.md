---
sidebar_position: 2
---

# Items

Plugin items that extend specific DocSpace UI locations — context menus, file rows, info panels, toolbars and profile menus.

Choose the item interface that matches the DocSpace UI area you want to extend with your plugin action.

## Overview

Each plugin type has specific items described in this section:

| Interface | Description | When to use |
| --- | --- | --- |
| [`IArticleButtonItem`](IArticleButtonItem.md) | Describes a button item that will be embedded in the article sidebar. | Add a button to the left navigation bar. |
| [`IContextMenuItem`](IContextMenuItem.md) | Describes an item that will be embedded in the context menu. | Embed a custom action in the file/folder context menu. |
| [`IEventListenerItem`](IEventListenerItem.md) | Event listener item. | React to built-in DocSpace events (file created, room opened, etc.). |
| [`IFileItem`](IFileItem.md) | Describes an item that will be embedded in the file list. | Handle clicks on files of a specific extension. |
| [`IInfoPanelItem`](IInfoPanelItem.md) | Describes the item submenu. | Add a custom tab to the file info panel on the right side. |
| [`IMainButtonItem`](IMainButtonItem.md) | Describes an item that will be embedded in the More item of the main button menu. | Add a sub-action to the main **More** button inside a room. |
| [`IProfileMenuItem`](IProfileMenuItem.md) | Describes an item that will be embedded in the profile menu. | Add a link or action to the user profile dropdown. |