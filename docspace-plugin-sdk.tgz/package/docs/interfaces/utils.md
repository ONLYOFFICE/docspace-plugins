---
sidebar_label: "Utils"
toc_max_heading_level: 3
hide_title: true
---

# Utils

Utility types for plugin messaging, return values, and panel navigation.

## IPostMessage

Defined in: [interfaces/utils/index.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L77)

The properties that are used to send a message to a frame.
If the frame ID is not specified or the frame with such an ID does not exist, then nothing changes.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="frameid"></a> `frameId` | `string` | Defines the frame ID | [interfaces/utils/index.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L79) |
| <a id="message"></a> `message` | \{ \[`key`: `string`\]: `any`; \} | Defines a message that will be sent to a frame | [interfaces/utils/index.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L82) |

***

### Example

Document preview frame communication

```typescript
const previewMessage: IPostMessage = {
  frameId: "document-preview-frame",
  message: {
    action: "zoom",
    scale: 1.5,
    position: { x: 100, y: 200 }
  }
};
```

## IMessage

Defined in: [interfaces/utils/index.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L154)

A message which is returned when any item interacts with a user (onClick, onChange, onSelect, etc.).

### Properties

#### actions?

```ts
optional actions: Actions[];
```

Defined in: [interfaces/utils/index.ts:160](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L160)

Defines a collection of events that will be processed on the portal side.
The specified actions will be performed depending on the set of values.

#### newProps?

```ts
optional newProps: 
  | IComboBox
  | IButton
  | ICheckbox
  | IInput
  | ITextArea
  | IToggleButton;
```

Defined in: [interfaces/utils/index.ts:167](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L167)

Defines the properties that update the state of the items which interact with the users.
This parameter is used only with Actions.updateProps.

#### toastProps?

```ts
optional toastProps: IToast[];
```

Defined in: [interfaces/utils/index.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L174)

Defines the properties that display a toast notification after the user actions.
This parameter is used only with Actions.showToast.

#### contextProps?

```ts
optional contextProps: {
  name: string;
  props:   | IComboBox
     | IButton
     | ICheckbox
     | IFrame
     | IImage
     | IInput
     | ILabel
     | ISkeleton
     | IText
     | ITextArea
     | IToggleButton
     | IBox;
}[];
```

Defined in: [interfaces/utils/index.ts:183](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L183)

Defines the properties that update the state of the parent or child item after the event was executed.
Contains an array of objects with:
- name: Defines the item name
- props: Defines the new properties for the parent or child item

##### Type Declaration

| Name | Type | Defined in |
| ------ | ------ | ------ |
| `name` | `string` | [interfaces/utils/index.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L184) |
| `props` | \| [`IComboBox`](components/IComboBox.md#icombobox) \| [`IButton`](components/IButton.md#ibutton) \| [`ICheckbox`](components/ICheckbox.md#icheckbox) \| [`IFrame`](components/IFrame.md#iframe) \| [`IImage`](components/IImage.md#iimage) \| [`IInput`](components/IInput.md#iinput) \| [`ILabel`](components/ILabel.md#ilabel) \| [`ISkeleton`](components/ISkeleton.md#iskeleton) \| [`IText`](components/IText.md#itext) \| [`ITextArea`](components/ITextArea.md#itextarea) \| [`IToggleButton`](components/IToggleButton.md#itogglebutton) \| [`IBox`](components/IBox.md#ibox) | [interfaces/utils/index.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L185) |

#### createDialogProps?

```ts
optional createDialogProps: ICreateDialog;
```

Defined in: [interfaces/utils/index.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L205)

Defines the properties that display the default dialog box for creating a file/folder managed by the plugin.
This parameter is used only with Actions.showCreateDialogModal.

#### modalDialogProps?

```ts
optional modalDialogProps: IModalDialog;
```

Defined in: [interfaces/utils/index.ts:212](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L212)

Defines the properties that display the modal window.
This parameter is used only with Actions.showModal.

#### selectorProps?

```ts
optional selectorProps: TSelector;
```

Defined in: [interfaces/utils/index.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L219)

Defines the properties that display the selector.
This parameter is used only with Actions.showSelector.

#### floatingOperationsButtonProps?

```ts
optional floatingOperationsButtonProps: IFloatingOperationsButton;
```

Defined in: [interfaces/utils/index.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L227)

Defines the configuration for the floating operations button that displays progress of long-running operations.
Used with Actions.addFloatingOperationsButton to create a new button or Actions.updateFloatingOperationsButton to update existing one.
The button appears as a floating action button in the bottom-right corner. Multiple plugins can show operations simultaneously.

#### floatingOperationsButtonPropsId?

```ts
optional floatingOperationsButtonPropsId: string;
```

Defined in: [interfaces/utils/index.ts:235](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L235)

Unique identifier for the floating operations button to remove.
Used only with Actions.removeFloatingOperationsButton to close a specific operations panel.
The ID should match the `id` property of the IFloatingOperationsButton that was previously added.

#### postMessage?

```ts
optional postMessage: IPostMessage;
```

Defined in: [interfaces/utils/index.ts:243](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L243)

Defines the properties that are used to send a message to a frame.
If the frame ID is not specified or the frame with such an ID does not exist, then nothing changes.
This parameter is used only with Actions.sendPostMessage.

#### settings?

```ts
optional settings: string;
```

Defined in: [interfaces/utils/index.ts:250](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L250)

Defines a parameter that is used to save and transfer the administrator or owner plugin settings to all the portal users.
This parameter is used only with Actions.saveSettings.

#### navigatePath?

```ts
optional navigatePath: string;
```

Defined in: [interfaces/utils/index.ts:258](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L258)

Defines the path to navigate to.
All actions listed after navigate will be called after the navigation is complete.
This parameter is used only with Actions.navigate.

#### infoPanelTab?

```ts
optional infoPanelTab: string;
```

Defined in: [interfaces/utils/index.ts:265](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L265)

Defines the info panel tab to open.
This parameter is used only with Actions.openInfoPanel.

#### mediaViewerProps?

```ts
optional mediaViewerProps: IMediaViewer;
```

Defined in: [interfaces/utils/index.ts:272](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L272)

Defines the properties for the media viewer.
This parameter is used only with Actions.showMediaViewer and Actions.updateMediaViewer.

***

### Examples

Form submission with validation and toast notification

```typescript
const formSubmissionMessage: IMessage = {
  actions: [Actions.updateProps, Actions.showToast, Actions.updateContext],
  newProps: {
    type: "input",
    id: "email-input",
    value: "user@example.com",
    isDisabled: true
  },
  toastProps: [{
    type: "success",
    title: "Form Submitted",
    message: "Your data has been saved successfully"
  }],
  contextProps: [{
    name: "submit-button",
    props: {
      type: "button",
      label: "Submitted",
      isDisabled: true
    }
  }]
};
```

Dynamic form field updates with error handling

```typescript
const fieldUpdateMessage: IMessage = {
  actions: [Actions.updateProps, Actions.showToast, Actions.updateContext],
  newProps: {
    type: "comboBox",
    id: "country-select",
    options: [
      { value: "us", label: "United States" },
      { value: "uk", label: "United Kingdom" }
    ],
    value: "us"
  },
  toastProps: [{
    type: "error",
    title: "Validation Error",
    message: "Please complete all required fields"
  }],
  contextProps: [{
    name: "state-select",
    props: {
      type: "comboBox",
      options: [
        { value: "ca", label: "California" },
        { value: "ny", label: "New York" }
      ],
      isDisabled: false
    }
  }]
};
```

## IPostMessageCallbackMessage

Defined in: [interfaces/utils/index.ts:294](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L294)

A message which is returned from the postMessage callback.
It is similar to [IMessage](#imessage) but with a reduced set of available actions.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="actions-1"></a> `actions?` | ( \| [`updateContextMenuItems`](../enums/Actions.md#updatecontextmenuitems) \| [`updateInfoPanelItems`](../enums/Actions.md#updateinfopanelitems) \| [`updateMainButtonItems`](../enums/Actions.md#updatemainbuttonitems) \| [`updateProfileMenuItems`](../enums/Actions.md#updateprofilemenuitems) \| [`updateFileItems`](../enums/Actions.md#updatefileitems) \| [`updateEventListenerItems`](../enums/Actions.md#updateeventlisteneritems) \| [`showToast`](../enums/Actions.md#showtoast) \| [`showCreateDialogModal`](../enums/Actions.md#showcreatedialogmodal) \| [`showModal`](../enums/Actions.md#showmodal) \| [`closeModal`](../enums/Actions.md#closemodal) \| [`showSelector`](../enums/Actions.md#showselector) \| [`addFloatingOperationsButton`](../enums/Actions.md#addfloatingoperationsbutton) \| [`removeFloatingOperationsButton`](../enums/Actions.md#removefloatingoperationsbutton) \| [`navigate`](../enums/Actions.md#navigate) \| [`openInfoPanel`](../enums/Actions.md#openinfopanel) \| [`showMediaViewer`](../enums/Actions.md#showmediaviewer) \| [`closeMediaViewer`](../enums/Actions.md#closemediaviewer))[] | Defines a collection of events that will be processed on the portal side. Only the following actions are available: updateContextMenuItems, updateInfoPanelItems, updateMainButtonItems, updateProfileMenuItems, updateFileItems, updateEventListenerItems, showToast, showCreateDialogModal, showModal, showSelector, addFloatingOperationsButton, navigate, openInfoPanel. | [interfaces/utils/index.ts:303](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L303) |
| <a id="toastprops-1"></a> `toastProps?` | [`IToast`](components/IToast.md#itoast)[] | Defines the properties that display a toast notification after the user actions. This parameter is used only with Actions.showToast. | [interfaces/utils/index.ts:327](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L327) |
| <a id="createdialogprops-1"></a> `createDialogProps?` | [`ICreateDialog`](components/ICreateDialog.md#icreatedialog) | Defines the properties that display the default dialog box for creating a file/folder managed by the plugin. This parameter is used only with Actions.showCreateDialogModal. | [interfaces/utils/index.ts:333](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L333) |
| <a id="modaldialogprops-1"></a> `modalDialogProps?` | [`IModalDialog`](components/IModalDialog.md#imodaldialog) | Defines the properties that display the modal window. This parameter is used only with Actions.showModal. | [interfaces/utils/index.ts:339](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L339) |
| <a id="selectorprops-1"></a> `selectorProps?` | [`TSelector`](components/Selector.md#tselector) | Defines the properties that display the selector. This parameter is used only with Actions.showSelector. | [interfaces/utils/index.ts:345](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L345) |
| <a id="floatingoperationsbuttonprops-1"></a> `floatingOperationsButtonProps?` | [`IFloatingOperationsButton`](components/IFloatingOperationsButton.md#ifloatingoperationsbutton) | Defines the configuration for the floating operations button that displays progress of long-running operations. Used with Actions.addFloatingOperationsButton to create a new button. | [interfaces/utils/index.ts:351](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L351) |
| <a id="floatingoperationsbuttonpropsid-1"></a> `floatingOperationsButtonPropsId?` | `string` | Unique identifier for the floating operations button to remove. Used with Actions.removeFloatingOperationsButton to close a specific operations panel. The ID should match the `id` property of the IFloatingOperationsButton that was previously added. | [interfaces/utils/index.ts:358](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L358) |
| <a id="navigatepath-1"></a> `navigatePath?` | `string` | Defines the path to navigate to. All actions listed after navigate will be called after the navigation is complete. This parameter is used only with Actions.navigate. | [interfaces/utils/index.ts:365](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L365) |
| <a id="infopaneltab-1"></a> `infoPanelTab?` | `string` | Defines the info panel tab to open. This parameter is used only with Actions.openInfoPanel. | [interfaces/utils/index.ts:371](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L371) |

***

### Example

Handling a postMessage callback with a toast notification

```typescript
const postMessageResponse: IPostMessageCallbackMessage = {
  actions: [Actions.showToast],
  toastProps: [{
    type: "success",
    title: "Message Received",
    message: "Frame message processed successfully"
  }]
};
```

## TInfoPanelTab

```ts
type TInfoPanelTab = "info_members" | "info_history" | "info_details" | "info_share" | string;
```

Defined in: [interfaces/utils/index.ts:49](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L49)

Defines the info panel tab to open.

***

## TReturnPostMessage

```ts
type TReturnPostMessage = 
  | Promise<IPostMessageCallbackMessage>
  | Promise<void>
  | void
  | IPostMessageCallbackMessage;
```

Defined in: [interfaces/utils/index.ts:374](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L374)

***

## TReturnMessage

```ts
type TReturnMessage = 
  | Promise<IMessage>
  | Promise<void>
  | void
  | IMessage;
```

Defined in: [interfaces/utils/index.ts:385](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L385)

Describes a return message.
