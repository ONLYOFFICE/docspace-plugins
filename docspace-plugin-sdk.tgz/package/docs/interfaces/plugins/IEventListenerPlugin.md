---
toc_max_heading_level: 3
hide_title: true
---

# IEventListenerPlugin

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L138)

The plugin that is given the access to the portal events.

### Methods

#### addEventListenerItem()

```ts
addEventListenerItem(item: IEventListenerItem): void;
```

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L149)

Add a new event listener item to the collection.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IEventListenerItem`](../items/IEventListenerItem.md#ieventlisteneritem) | The event listener item to add, containing key, event type, and onEvent handler |

##### Returns

`void`

#### getEventListenerItems()

```ts
getEventListenerItems(): Map<string, IEventListenerItem>;
```

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:155](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L155)

Get all registered event listener items.

##### Returns

`Map`\<`string`, [`IEventListenerItem`](../items/IEventListenerItem.md#ieventlisteneritem)\>

A Map containing all registered event listener items, where keys are item identifiers

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="eventlisteneritems"></a> `eventListenerItems` | `Map`\<`string`, [`IEventListenerItem`](../items/IEventListenerItem.md#ieventlisteneritem)\> | Stores a collection of elements where the keys are the key parameters from the EventListenerItem objects. A list of event listeners is generated based on this collection. | [interfaces/plugins/IEventListenerPlugin.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L143) |
### Examples

Room activity monitor with permission checks

```typescript
const roomListener: IEventListenerPlugin = {
  eventListenerItems: new Map([
    ["room-activity", {
      key: "room-activity",
      event: Events.ROOM_CREATE,
      onEvent: async (data) => {
        try {
          await logRoomActivity(data);
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Room Created",
              message: "Room initialized | Settings applied | Ready to use"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Room Creation Failed",
              message: "Unable to create room | Check permissions"
            }]
          };
        }
      }
    }]
  ]),
  addEventListenerItem(item) {
    this.eventListenerItems.set(item.key, item);
  },
  getEventListenerItems() {
    return this.eventListenerItems;
  }
};
```

File operations tracker with history logging

```typescript
const fileMonitor: IEventListenerPlugin = {
  eventListenerItems: new Map([
    ["file-rename", {
      key: "file-rename",
      event: Events.RENAME,
      onEvent: async (data) => {
        try {
          await trackFileRename(data);
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "File Renamed",
              message: "Name updated | Records modified | History logged"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Rename Failed",
              message: "Unable to rename | Check file status"
            }]
          };
        }
      }
    }],
    ["file-delete", {
      key: "file-delete",
      event: Events.DELETE,
      onEvent: async (data) => {
        try {
          await handleFileDeletion(data);
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "File Deleted",
              message: "File removed | Space cleared | Records updated"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Deletion Failed",
              message: "Unable to delete | Check file access"
            }]
          };
        }
      }
    }]
  ]),
  addEventListenerItem(item) {
    this.eventListenerItems.set(item.key, item);
  },
  getEventListenerItems() {
    return this.eventListenerItems;
  }
};
```

