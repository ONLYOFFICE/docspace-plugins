---
toc_max_heading_level: 3
hide_title: true
---

# IInfoPanelPlugin

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L114)

The plugin that is embedded as a separate tab in the file info panel.

### Methods

#### addInfoPanelItem()

```ts
addInfoPanelItem(item: IInfoPanelItem): void;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L122)

Add a new info panel item

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `item` | [`IInfoPanelItem`](../items/IInfoPanelItem.md#iinfopanelitem) |

##### Returns

`void`

#### getInfoPanelItems()

```ts
getInfoPanelItems(): Map<string, IInfoPanelItem>;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L125)

Get all the info panel items

##### Returns

`Map`\<`string`, [`IInfoPanelItem`](../items/IInfoPanelItem.md#iinfopanelitem)\>

#### updateInfoPanelItem()

```ts
updateInfoPanelItem(item: IInfoPanelItem): void;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L128)

Update the info panel item

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `item` | [`IInfoPanelItem`](../items/IInfoPanelItem.md#iinfopanelitem) |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="infopanelitems"></a> `infoPanelItems` | `Map`\<`string`, [`IInfoPanelItem`](../items/IInfoPanelItem.md#iinfopanelitem)\> | Stores a collection of elements where the keys are the key parameters from the InfoPanelItem objects. A list for embedding into the info panel is generated based on this collection. | [interfaces/plugins/IInfoPanelPlugin.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L119) |
### Examples

Document metadata viewer with permission checks

```typescript
const documentInfoPanel: IInfoPanelPlugin = {
  infoPanelItems: new Map([
    ["doc-info", {
      key: "doc-info",
      label: "Document Info",
      icon: "info-icon.svg",
      onClick: async () => {
        try {
          const info = await getDocumentInfo();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Info Retrieved",
              message: "Document details | Data loaded | Panel updated"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Info Failed",
              message: "Unable to load info | Check permissions"
            }]
          };
        }
      }
    }]
  ]),
  getInfoPanelItems() {
    return this.infoPanelItems;
  },
  updateInfoPanelItem(item) {
    this.infoPanelItems.set(item.key, item);
  }
};
```

File statistics analyzer with visualization

```typescript
const analyticsPanel: IInfoPanelPlugin = {
  infoPanelItems: new Map([
    ["file-stats", {
      key: "file-stats",
      label: "File Analytics",
      icon: "analytics-icon.svg",
      onClick: async () => {
        try {
          await loadFileAnalytics();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Analytics Loaded",
              message: "Stats calculated | Charts rendered | View ready"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Analytics Failed",
              message: "Unable to load stats | Check data source"
            }]
          };
        }
      }
    }]
  ]),
  getInfoPanelItems() {
    return this.infoPanelItems;
  },
  updateInfoPanelItem(item) {
    this.infoPanelItems.set(item.key, item);
  }
};
```

