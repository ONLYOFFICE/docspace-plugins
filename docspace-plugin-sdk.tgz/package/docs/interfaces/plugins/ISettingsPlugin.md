---
toc_max_heading_level: 3
hide_title: true
---

# ISettingsPlugin

Defined in: [interfaces/plugins/ISettingsPlugin.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/ISettingsPlugin.ts#L159)

The plugin that manages settings for the administrator or owner.
The plugin that can interact with the settings panel.

<img alt="settings-block" src="/assets/images/docspace/settings-block.png" style={{width: "400px"}} />

### Methods

#### setAdminPluginSettings()

```ts
setAdminPluginSettings(settings: ISettings | null): void;
```

Defined in: [interfaces/plugins/ISettingsPlugin.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/ISettingsPlugin.ts#L164)

Update the administrator or owner plugin settings

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `settings` | [`ISettings`](../settings/ISettings.md#isettings) \| `null` |

##### Returns

`void`

#### setAdminPluginSettingsValue()

```ts
setAdminPluginSettingsValue(settings: string | null): void;
```

Defined in: [interfaces/plugins/ISettingsPlugin.ts:167](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/ISettingsPlugin.ts#L167)

Transfer the administrator or owner plugin settings to all the portal users. It functions on the DocSpace side

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `settings` | `string` \| `null` |

##### Returns

`void`

#### getAdminPluginSettings()

```ts
getAdminPluginSettings(): ISettings | null;
```

Defined in: [interfaces/plugins/ISettingsPlugin.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/ISettingsPlugin.ts#L170)

Get the administrator or owner plugin settings

##### Returns

[`ISettings`](../settings/ISettings.md#isettings) \| `null`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="adminpluginsettings"></a> `adminPluginSettings` | [`ISettings`](../settings/ISettings.md#isettings) \| `null` | The administrator or owner settings block that is embedded in the modal window with the plugin description | [interfaces/plugins/ISettingsPlugin.ts:161](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/ISettingsPlugin.ts#L161) |
### Examples

Theme customization settings with error handling

```typescript
const themeSettings: ISettingsPlugin = {
  adminPluginSettings: new Map([
    ["theme", {
      key: "theme",
      label: "Theme Settings",
      icon: "theme-icon.svg",
      onClick: async () => {
        try {
          await loadThemeSettings();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Theme Settings",
              message: "Preferences loaded | Colors ready | Panel opened"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Settings Failed",
              message: "Unable to load theme | Check configuration"
            }]
          };
        }
      }
    }]
  ]),
  setAdminPluginSettings(settings) {
    this.adminPluginSettings = settings;
  },
  setAdminPluginSettingsValue(settings) {
    try {
      this.adminPluginSettings.set("theme", settings);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Setting Updated",
          message: "Value saved | Config updated | Changes applied"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Update Failed",
          message: "Unable to save setting | Check value format"
        }]
      };
    }
  },
  getAdminPluginSettings() {
    return this.adminPluginSettings;
  }
};
```

Multi-language support configuration

```typescript
const languageSettings: ISettingsPlugin = {
  adminPluginSettings: new Map([
    ["language", {
      key: "language",
      label: "Language Settings",
      icon: "language-icon.svg",
      onClick: async () => {
        try {
          await loadLanguageOptions();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Language Options",
              message: "Languages loaded | List ready | Choose option"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Options Failed",
              message: "Unable to load languages | Check connection"
            }]
          };
        }
      }
    }]
  ]),
  setAdminPluginSettings(settings) {
    this.adminPluginSettings = settings;
  },
  setAdminPluginSettingsValue(settings) {
    try {
      this.adminPluginSettings.set("language", settings);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Language Changed",
          message: "Language updated | UI translated | Ready to use"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Change Failed",
          message: "Unable to change language | Try again"
        }]
      };
    }
  },
  getAdminPluginSettings() {
    return this.adminPluginSettings;
  }
};
```

