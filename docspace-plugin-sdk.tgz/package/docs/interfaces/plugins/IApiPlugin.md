---
toc_max_heading_level: 3
hide_title: true
---

# IApiPlugin

Defined in: [interfaces/plugins/IApiPlugin.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L112)

The plugin that is provided with the origin, proxy, and prefix to make requests to the portal server.

### Methods

#### setOrigin()

```ts
setOrigin(origin: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L126)

Update the origin parameter of the DocSpace portal.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `origin` | `string` | The new origin parameter |

##### Returns

`void`

#### setProxy()

```ts
setProxy(proxy: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L132)

Update the proxy parameter of the DocSpace portal.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `proxy` | `string` | The new proxy parameter |

##### Returns

`void`

#### setPrefix()

```ts
setPrefix(prefix: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L138)

Update the prefix parameter of the DocSpace portal.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `prefix` | `string` | The new prefix parameter |

##### Returns

`void`

#### getOrigin()

```ts
getOrigin(): string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L144)

Get the origin parameter of the DocSpace portal.

##### Returns

`string`

The current origin parameter

#### getProxy()

```ts
getProxy(): string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:150](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L150)

Get the proxy parameter of the DocSpace portal.

##### Returns

`string`

The current proxy parameter

#### getPrefix()

```ts
getPrefix(): string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:156](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L156)

Get the prefix parameter of the DocSpace portal to access the server side.

##### Returns

`string`

The current prefix parameter

#### setAPI()

```ts
setAPI(
   origin: string, 
   proxy: string, 
   prefix: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L164)

Update all the API parameters of the DocSpace portal in one request.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `origin` | `string` | The new origin parameter |
| `proxy` | `string` | The new proxy parameter |
| `prefix` | `string` | The new prefix parameter |

##### Returns

`void`

#### getAPI()

```ts
getAPI(): {
  origin: string;
  proxy: string;
  prefix: string;
};
```

Defined in: [interfaces/plugins/IApiPlugin.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L170)

Get all the API parameters of the DocSpace portal in one request.

##### Returns

```ts
{
  origin: string;
  proxy: string;
  prefix: string;
}
```

An object containing the current origin, proxy, and prefix parameters

| Name | Type | Defined in |
| ------ | ------ | ------ |
| `origin` | `string` | [interfaces/plugins/IApiPlugin.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L170) |
| `proxy` | `string` | [interfaces/plugins/IApiPlugin.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L170) |
| `prefix` | `string` | [interfaces/plugins/IApiPlugin.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L170) |

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="origin"></a> `origin` | `string` | Stores the origin parameter of the DocSpace portal | [interfaces/plugins/IApiPlugin.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L114) |
| <a id="proxy"></a> `proxy` | `string` | Stores the proxy parameter of the DocSpace portal | [interfaces/plugins/IApiPlugin.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L117) |
| <a id="prefix"></a> `prefix` | `string` | Stores the prefix parameter of the DocSpace portal to access the server side | [interfaces/plugins/IApiPlugin.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L120) |
### Example

API configuration manager with endpoint validation

```typescript
const documentApi: IApiPlugin = {
  origin: "https://docspace.example.com",
  proxy: "/api/proxy",
  prefix: "/api/v1",

  setOrigin(origin) {
    try {
      this.origin = origin;
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "Origin Updated",
          message: "API endpoint changed | Config saved | Ready to use"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Update Failed",
          message: "Unable to update origin | Check URL format"
        }]
      };
    }
  },

  setProxy(proxy) {
    this.proxy = proxy;
  },

  setPrefix(prefix) {
    this.prefix = prefix;
  },

  getOrigin() {
    return this.origin;
  },

  getProxy() {
    return this.proxy;
  },

  getPrefix() {
    return this.prefix;
  },

  setAPI(origin, proxy, prefix) {
    try {
      this.origin = origin;
      this.proxy = proxy;
      this.prefix = prefix;
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "success",
          title: "API Updated",
          message: "Configuration saved | Endpoints updated | Ready to use"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: "error",
          title: "Update Failed",
          message: "Unable to update API | Check configuration"
        }]
      };
    }
  },

  getAPI() {
    return {
      origin: this.origin,
      proxy: this.proxy,
      prefix: this.prefix
    };
  }
};
```

