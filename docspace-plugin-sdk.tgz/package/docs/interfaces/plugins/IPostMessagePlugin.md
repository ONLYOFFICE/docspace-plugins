---
toc_max_heading_level: 3
hide_title: true
---

# IPostMessagePlugin

Defined in: [interfaces/plugins/IPostMessagePlugin.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPostMessagePlugin.ts#L88)

The plugin that is given the access to handle postMessage events from iframe components.
The plugin listens for window.postMessage events from embedded iframes
and triggers portal-side actions (such as showing toasts, modals, or updating items)
by calling the postMessageCallback with an [IPostMessageCallbackMessage](../utils.md#ipostmessagecallbackmessage).

### Methods

#### setPostMessageCallback()

```ts
setPostMessageCallback(callback: (message: IPostMessageCallbackMessage) => void): void;
```

Defined in: [interfaces/plugins/IPostMessagePlugin.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPostMessagePlugin.ts#L104)

Sets the postMessage callback function.
This method is called by the portal to register the callback that the plugin
will use to communicate actions back to the portal.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `callback` | (`message`: [`IPostMessageCallbackMessage`](../utils.md#ipostmessagecallbackmessage)) => `void` | The callback function provided by the portal for the plugin to invoke |

##### Returns

`void`

#### getPostMessageCallback()

```ts
getPostMessageCallback(): (message: IPostMessageCallbackMessage) => void;
```

Defined in: [interfaces/plugins/IPostMessagePlugin.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPostMessagePlugin.ts#L112)

Gets the current postMessage callback function.

##### Returns

The currently registered postMessage callback function

```ts
(message: IPostMessageCallbackMessage): void;
```

###### Parameters

| Parameter | Type |
| ------ | ------ |
| `message` | [`IPostMessageCallbackMessage`](../utils.md#ipostmessagecallbackmessage) |

###### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="postmessagecallback"></a> `postMessageCallback` | (`message`: [`IPostMessageCallbackMessage`](../utils.md#ipostmessagecallbackmessage)) => `void` | A callback function that is called by the plugin to trigger portal-side actions in response to postMessage events received from embedded iframes. The portal sets this callback via [setPostMessageCallback](#setpostmessagecallback). The plugin invokes it with an [IPostMessageCallbackMessage](../utils.md#ipostmessagecallbackmessage) containing the desired actions and their properties. | [interfaces/plugins/IPostMessagePlugin.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPostMessagePlugin.ts#L96) |
### Examples

PostMessage handler with toast notification

```typescript
class MyPlugin implements IPlugin, IInfoPanelPlugin, IPostMessagePlugin {
  postMessageCallback: (message: IPostMessageCallbackMessage) => void = () => {};

  setPostMessageCallback = (callback: (message: IPostMessageCallbackMessage) => void): void => {
    this.postMessageCallback = callback;
  };

  getPostMessageCallback = (): ((message: IPostMessageCallbackMessage) => void) => {
    return this.postMessageCallback;
  };
}

const plugin = new MyPlugin();

window.parent.addEventListener("message", (event) => {
  try {
    const data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
    if (data?.source !== "my-plugin") return;

    plugin.postMessageCallback({
      actions: [Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Message Received",
      }],
    });
  } catch {
    // ignore non-JSON messages
  }
});
```

PostMessage handler with modal dialog

```typescript
window.parent.addEventListener("message", (event) => {
  try {
    const data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
    if (data?.source !== "my-plugin") return;

    plugin.postMessageCallback({
      actions: [Actions.showModal],
      modalDialogProps: {
        dialogHeader: "Frame Response",
        dialogBody: body,
        displayType: ModalDisplayType.modal,
      },
    });
  } catch {
    // ignore non-JSON messages
  }
});
```

