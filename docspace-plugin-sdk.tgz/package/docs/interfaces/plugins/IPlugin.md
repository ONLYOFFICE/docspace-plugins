---
toc_max_heading_level: 3
hide_title: true
---

# IPlugin

Defined in: [interfaces/plugins/IPlugin.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L97)

The default plugin.
This interface must be implemented in each plugin because without the plugin status it will not be built in.

### Methods

#### updateStatus()

```ts
updateStatus(status: PluginStatus): void;
```

Defined in: [interfaces/plugins/IPlugin.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L114)

Update the plugin status

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `status` | [`PluginStatus`](../../enums/Plugins.md#pluginstatus) |

##### Returns

`void`

#### getStatus()

```ts
getStatus(): PluginStatus;
```

Defined in: [interfaces/plugins/IPlugin.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L117)

Get the current plugin status

##### Returns

[`PluginStatus`](../../enums/Plugins.md#pluginstatus)

#### setOnLoadCallback()

```ts
setOnLoadCallback(callback: () => Promise<void>): void;
```

Defined in: [interfaces/plugins/IPlugin.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L120)

Sets the onLoadCallback variable to the plugin

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `callback` | () => `Promise`\<`void`\> |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="status"></a> `status` | [`PluginStatus`](../../enums/Plugins.md#pluginstatus) | The plugin status (active or hide) | [interfaces/plugins/IPlugin.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L99) |
| <a id="language"></a> `language?` | [`PluginLocale`](../../enums/Plugins.md#pluginlocale) | The plugin language | [interfaces/plugins/IPlugin.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L102) |
| <a id="setlanguage"></a> `setLanguage?` | (`language`: [`PluginLocale`](../../enums/Plugins.md#pluginlocale)) => `void` | The method is called on the portal side when the portal language is changed. | [interfaces/plugins/IPlugin.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L105) |
| <a id="getlanguage"></a> `getLanguage?` | () => [`PluginLocale`](../../enums/Plugins.md#pluginlocale) | The method is called on the portal side to get the plugin language. | [interfaces/plugins/IPlugin.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L108) |
| <a id="onloadcallback"></a> `onLoadCallback` | () => `Promise`\<`void`\> | Callback which will be executed when uploading the plugin to the portal | [interfaces/plugins/IPlugin.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L111) |
### Examples

Document analyzer plugin with lifecycle management

```typescript
const documentAnalyzer: IPlugin = {
  status: PluginStatus.Active,

  async onLoadCallback() {
    try {
      await initializeAnalyzer();
      console.log("Document analyzer initialized successfully");
    } catch (error) {
      console.error("Failed to initialize document analyzer:", error);
      this.status = PluginStatus.Hide;
    }
  },

  updateStatus(status) {
    this.status = status;
    console.log(`Plugin status updated to: ${status}`);
  },

  getStatus() {
    return this.status;
  },

  setOnLoadCallback(callback) {
    this.onLoadCallback = callback;
  }
};
```

Auto-backup plugin with error recovery

```typescript
const backupPlugin: IPlugin = {
  status: PluginStatus.Active,

  async onLoadCallback() {
    try {
      await validateBackupConfig();
      await initializeBackupService();
      console.log("Backup service started successfully");
    } catch (error) {
      console.error("Backup service initialization failed:", error);
      this.status = PluginStatus.Hide;
    }
  },

  updateStatus(status) {
    const prevStatus = this.status;
    this.status = status;

    if (prevStatus !== status) {
      console.log(`Backup service transitioned from ${prevStatus} to ${status}`);
    }
  },

  getStatus() {
    return this.status;
  },

  setOnLoadCallback(callback) {
    this.onLoadCallback = callback;
  }
};
```

