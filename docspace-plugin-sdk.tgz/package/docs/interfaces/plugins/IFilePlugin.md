---
toc_max_heading_level: 3
hide_title: true
---

# IFilePlugin

Defined in: [interfaces/plugins/IFilePlugin.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IFilePlugin.ts#L120)

The plugin that can interact with the file list.

### Methods

#### addFileItem()

```ts
addFileItem(item: IFileItem): void;
```

Defined in: [interfaces/plugins/IFilePlugin.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IFilePlugin.ts#L131)

Add a new item for interactions with files.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IFileItem`](../items/IFileItem.md#ifileitem) | The file item to add, containing key, label, icon, and onClick handler |

##### Returns

`void`

#### getFileItems()

```ts
getFileItems(): Map<string, IFileItem>;
```

Defined in: [interfaces/plugins/IFilePlugin.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IFilePlugin.ts#L137)

Get all the items for interactions with files.

##### Returns

`Map`\<`string`, [`IFileItem`](../items/IFileItem.md#ifileitem)\>

A Map containing all registered file items, where keys are item identifiers

#### updateFileItem()

```ts
updateFileItem(item: IFileItem): void;
```

Defined in: [interfaces/plugins/IFilePlugin.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IFilePlugin.ts#L143)

Update an existing file interaction item.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IFileItem`](../items/IFileItem.md#ifileitem) | The file item to update with new properties |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="fileitems"></a> `fileItems` | `Map`\<`string`, [`IFileItem`](../items/IFileItem.md#ifileitem)\> | Stores a collection of elements where the keys are the key parameters from the FileItem objects. A list for hooking interactions with files is generated based on this collection. | [interfaces/plugins/IFilePlugin.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IFilePlugin.ts#L125) |
### Examples

File compression utility with size validation

```typescript
const compressionPlugin: IFilePlugin = {
  fileItems: new Map([
    ["compress", {
      key: "compress",
      label: "Compress File",
      icon: "compress-icon.svg",
      onClick: async () => {
        try {
          await compressSelectedFile();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "File Compressed",
              message: "Compression complete | Space saved | Ready to use"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Compression Failed",
              message: "Unable to compress file | Check file size"
            }]
          };
        }
      }
    }]
  ]),
  getFileItems() {
    return this.fileItems;
  },
  addFileItem(item) {
    this.fileItems.set(item.key, item);
  },
  updateFileItem(item) {
    this.fileItems.set(item.key, item);
  }
};
```

File encryption manager with key validation

```typescript
const encryptionPlugin: IFilePlugin = {
  fileItems: new Map([
    ["encrypt", {
      key: "encrypt",
      label: "Encrypt File",
      icon: "encrypt-icon.svg",
      onClick: async () => {
        try {
          await encryptSelectedFile();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "File Encrypted",
              message: "Encryption complete | Security applied | Ready to store"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Encryption Failed",
              message: "Unable to encrypt file | Check key status"
            }]
          };
        }
      }
    }]
  ]),
  getFileItems() {
    return this.fileItems;
  },
  addFileItem(item) {
    this.fileItems.set(item.key, item);
  },
  updateFileItem(item) {
    this.fileItems.set(item.key, item);
  }
};
```

