---
toc_max_heading_level: 3
hide_title: true
---

# IContextMenuPlugin

Defined in: [interfaces/plugins/IContextMenuPlugin.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IContextMenuPlugin.ts#L184)

The plugin that is embedded in the context menu of files, folders, rooms, images, video (audio).

### Methods

#### addContextMenuItem()

```ts
addContextMenuItem(item: IContextMenuItem): void;
```

Defined in: [interfaces/plugins/IContextMenuPlugin.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IContextMenuPlugin.ts#L195)

Add a new context menu item.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IContextMenuItem`](../items/IContextMenuItem.md#icontextmenuitem) | The context menu item to add, containing key, label, icon, and onClick handler |

##### Returns

`void`

#### getContextMenuItems()

```ts
getContextMenuItems(): Map<string, IContextMenuItem>;
```

Defined in: [interfaces/plugins/IContextMenuPlugin.ts:201](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IContextMenuPlugin.ts#L201)

Get all the context menu items.

##### Returns

`Map`\<`string`, [`IContextMenuItem`](../items/IContextMenuItem.md#icontextmenuitem)\>

A Map containing all registered context menu items, where keys are item identifiers

#### getContextMenuItemsKeys()

```ts
getContextMenuItemsKeys(): string[];
```

Defined in: [interfaces/plugins/IContextMenuPlugin.ts:207](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IContextMenuPlugin.ts#L207)

Get all the keys of the context menu items.

##### Returns

`string`[]

An array containing all registered context menu item keys

#### updateContextMenuItem()

```ts
updateContextMenuItem(item: IContextMenuItem): void;
```

Defined in: [interfaces/plugins/IContextMenuPlugin.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IContextMenuPlugin.ts#L213)

Update an existing context menu item.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IContextMenuItem`](../items/IContextMenuItem.md#icontextmenuitem) | The context menu item to update with new properties |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="contextmenuitems"></a> `contextMenuItems` | `Map`\<`string`, [`IContextMenuItem`](../items/IContextMenuItem.md#icontextmenuitem)\> | Stores a collection of elements where the keys are the key parameters from the ContextMenuItem objects. A list for embedding into the context menu is generated based on this collection. | [interfaces/plugins/IContextMenuPlugin.ts:189](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IContextMenuPlugin.ts#L189) |
### Examples

Document sharing and export menu with status feedback

```typescript
const documentActions: IContextMenuPlugin = {
  contextMenuItems: new Map([
    ["doc-share", {
      key: "doc-share",
      label: "Share Document",
      icon: "share-icon.svg",
      onClick: async () => {
        try {
          await initiateDocumentSharing();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Share Ready",
              message: "Share dialog opened | Recipients ready | Set permissions"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Share Failed",
              message: "Unable to share | Check document status"
            }]
          };
        }
      }
    }],
    ["doc-export", {
      key: "doc-export",
      label: "Export Document",
      icon: "export-icon.svg",
      onClick: async () => {
        try {
          await prepareDocumentExport();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Export Ready",
              message: "Format selected | Options set | Choose destination"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Export Failed",
              message: "Unable to export | Verify format support"
            }]
          };
        }
      }
    }]
  ]),
  addContextMenuItem(item) {
    this.contextMenuItems.set(item.key, item);
  },
  getContextMenuItems() {
    return this.contextMenuItems;
  },
  getContextMenuItemsKeys() {
    return Array.from(this.contextMenuItems.keys());
  },
  updateContextMenuItem(item) {
    if (this.contextMenuItems.has(item.key)) {
      this.contextMenuItems.set(item.key, item);
    }
  }
};
```

File compression and encryption tools

```typescript
const fileOperations: IContextMenuPlugin = {
  contextMenuItems: new Map([
    ["file-compress", {
      key: "file-compress",
      label: "Compress File",
      icon: "compress-icon.svg",
      onClick: async () => {
        try {
          await initiateFileCompression();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Compression Started",
              message: "File processing | Size reducing | Please wait"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Compression Failed",
              message: "Unable to compress | Check file size"
            }]
          };
        }
      }
    }],
    ["file-encrypt", {
      key: "file-encrypt",
      label: "Encrypt File",
      icon: "encrypt-icon.svg",
      onClick: async () => {
        try {
          await initiateFileEncryption();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Encryption Ready",
              message: "Key generated | File secured | Access protected"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Encryption Failed",
              message: "Unable to encrypt | Check key management"
            }]
          };
        }
      }
    }]
  ]),
  addContextMenuItem(item) {
    this.contextMenuItems.set(item.key, item);
  },
  getContextMenuItems() {
    return this.contextMenuItems;
  },
  getContextMenuItemsKeys() {
    return Array.from(this.contextMenuItems.keys());
  },
  updateContextMenuItem(item) {
    if (this.contextMenuItems.has(item.key)) {
      this.contextMenuItems.set(item.key, item);
    }
  }
};
```

