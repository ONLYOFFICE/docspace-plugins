---
toc_max_heading_level: 3
hide_title: true
---

# IMainButtonPlugin

Defined in: [interfaces/plugins/IMainButtonPlugin.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IMainButtonPlugin.ts#L120)

The plugin that can add items to the main button menu.

### Methods

#### addMainButtonItem()

```ts
addMainButtonItem(item: IMainButtonItem): void;
```

Defined in: [interfaces/plugins/IMainButtonPlugin.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IMainButtonPlugin.ts#L131)

Add a new item to the main button menu.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IMainButtonItem`](../items/IMainButtonItem.md#imainbuttonitem) | The main button item to add, containing key, label, icon, and onClick handler |

##### Returns

`void`

#### getMainButtonItems()

```ts
getMainButtonItems(): Map<string, IMainButtonItem>;
```

Defined in: [interfaces/plugins/IMainButtonPlugin.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IMainButtonPlugin.ts#L137)

Get all registered main button menu items.

##### Returns

`Map`\<`string`, [`IMainButtonItem`](../items/IMainButtonItem.md#imainbuttonitem)\>

A Map containing all registered main button items, where keys are item identifiers

#### updateMainButtonItem()

```ts
updateMainButtonItem(item: IMainButtonItem): void;
```

Defined in: [interfaces/plugins/IMainButtonPlugin.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IMainButtonPlugin.ts#L143)

Update an existing main button menu item.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IMainButtonItem`](../items/IMainButtonItem.md#imainbuttonitem) | The main button item to update with new properties |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="mainbuttonitems"></a> `mainButtonItems` | `Map`\<`string`, [`IMainButtonItem`](../items/IMainButtonItem.md#imainbuttonitem)\> | Stores a collection of elements where the keys are the key parameters from the MainButtonItem objects. A list of main button menu items is generated based on this collection. | [interfaces/plugins/IMainButtonPlugin.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IMainButtonPlugin.ts#L125) |
### Examples

PDF export functionality with progress feedback

```typescript
const exportPlugin: IMainButtonPlugin = {
  mainButtonItems: new Map([
    ["export-pdf", {
      key: "export-pdf",
      label: "Export to PDF",
      icon: "pdf-icon.svg",
      onClick: async () => {
        try {
          await exportToPdf();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Export Complete",
              message: "PDF created | File saved | Ready to download"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Export Failed",
              message: "Unable to export | Check document status"
            }]
          };
        }
      }
    }]
  ]),
  addMainButtonItem(item) {
    this.mainButtonItems.set(item.key, item);
  },
  getMainButtonItems() {
    return this.mainButtonItems;
  },
  updateMainButtonItem(item) {
    this.mainButtonItems.set(item.key, item);
  }
};
```

Batch document processor with status notifications

```typescript
const batchPlugin: IMainButtonPlugin = {
  mainButtonItems: new Map([
    ["batch-process", {
      key: "batch-process",
      label: "Batch Process",
      icon: "batch-icon.svg",
      onClick: async () => {
        try {
          await processBatch();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Batch Complete",
              message: "Files processed | Results saved | View summary"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Batch Failed",
              message: "Processing error | Check file list"
            }]
          };
        }
      }
    }]
  ]),
  addMainButtonItem(item) {
    this.mainButtonItems.set(item.key, item);
  },
  getMainButtonItems() {
    return this.mainButtonItems;
  },
  updateMainButtonItem(item) {
    this.mainButtonItems.set(item.key, item);
  }
};
```

