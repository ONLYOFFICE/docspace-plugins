---
toc_max_heading_level: 3
hide_title: true
---

# IProfileMenuPlugin

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L115)

Plugin for embedding items in the profile menu.
This interface must be implemented in each plugin that adds items to the profile menu.

### Methods

#### addProfileMenuItem()

```ts
addProfileMenuItem(item: IProfileMenuItem): void;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L123)

Add a new profile menu item

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `item` | [`IProfileMenuItem`](../items/IProfileMenuItem.md#iprofilemenuitem) |

##### Returns

`void`

#### getProfileMenuItems()

```ts
getProfileMenuItems(): Map<string, IProfileMenuItem>;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L126)

Get all the profile menu items

##### Returns

`Map`\<`string`, [`IProfileMenuItem`](../items/IProfileMenuItem.md#iprofilemenuitem)\>

#### updateProfileMenuItem()

```ts
updateProfileMenuItem(item: IProfileMenuItem): void;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L129)

Updates an existing profile menu item

##### Parameters

| Parameter | Type |
| ------ | ------ |
| `item` | [`IProfileMenuItem`](../items/IProfileMenuItem.md#iprofilemenuitem) |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="profilemenuitems"></a> `profileMenuItems` | `Map`\<`string`, [`IProfileMenuItem`](../items/IProfileMenuItem.md#iprofilemenuitem)\> | Stores a collection of elements where the keys are the key parameters from the ProfileMenuItem objects. A list for hooking interactions with profile menu is generated based on this collection. | [interfaces/plugins/IProfileMenuPlugin.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L120) |
### Examples

User preferences manager with error handling

```typescript
const settingsPlugin: IProfileMenuPlugin = {
  profileMenuItems: new Map([
    ["user-settings", {
      key: "user-settings",
      label: "User Settings",
      icon: "settings-icon.svg",
      onClick: async () => {
        try {
          await loadUserSettings();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Settings Loaded",
              message: "Preferences loaded | Options ready | Panel opened"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Settings Failed",
              message: "Unable to load settings | Check permissions"
            }]
          };
        }
      }
    }]
  ]),
  addProfileMenuItem(item) {
    this.profileMenuItems.set(item.key, item);
  },
  getProfileMenuItems() {
    return this.profileMenuItems;
  }
};
```

Interactive user profile viewer

```typescript
const profilePlugin: IProfileMenuPlugin = {
  profileMenuItems: new Map([
    ["user-profile", {
      key: "user-profile",
      label: "View Profile",
      icon: "profile-icon.svg",
      onClick: async () => {
        try {
          await loadUserProfile();
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "success",
              title: "Profile Loaded",
              message: "Data retrieved | Profile ready | View updated"
            }]
          };
        } catch (error) {
          return {
            actions: [Actions.showToast],
            toastProps: [{
              type: "error",
              title: "Profile Failed",
              message: "Unable to load profile | Check connection"
            }]
          };
        }
      }
    }]
  ]),
  addProfileMenuItem(item) {
    this.profileMenuItems.set(item.key, item);
  },
  getProfileMenuItems() {
    return this.profileMenuItems;
  }
};
```

