---
toc_max_heading_level: 3
hide_title: true
---

# IArticleButtonPlugin

Defined in: [interfaces/plugins/IArticleButtonPlugin.ts:49](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IArticleButtonPlugin.ts#L49)

Describes a plugin that adds custom button items to the article sidebar.
Article button items appear as custom plugin components above the DevTools section.
Maximum 5 items can be displayed across all plugins.

### Methods

#### addArticleButtonItem()

```ts
addArticleButtonItem(item: IArticleButtonItem): void;
```

Defined in: [interfaces/plugins/IArticleButtonPlugin.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IArticleButtonPlugin.ts#L60)

Add a new article button item to the plugin's collection.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IArticleButtonItem`](../items/IArticleButtonItem.md#iarticlebuttonitem) | The article button item to add |

##### Returns

`void`

#### getArticleButtonItems()

```ts
getArticleButtonItems(): Map<string, IArticleButtonItem>;
```

Defined in: [interfaces/plugins/IArticleButtonPlugin.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IArticleButtonPlugin.ts#L67)

Get all the article button items provided by the plugin.
Each item will be displayed as a custom component in the article sidebar.

##### Returns

`Map`\<`string`, [`IArticleButtonItem`](../items/IArticleButtonItem.md#iarticlebuttonitem)\>

A Map containing all registered article button items, where keys are item identifiers

#### updateArticleButtonItem()

```ts
updateArticleButtonItem(item: IArticleButtonItem): void;
```

Defined in: [interfaces/plugins/IArticleButtonPlugin.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IArticleButtonPlugin.ts#L73)

Update an existing article button item in the plugin's collection.

##### Parameters

| Parameter | Type | Description |
| ------ | ------ | ------ |
| `item` | [`IArticleButtonItem`](../items/IArticleButtonItem.md#iarticlebuttonitem) | The article button item to update with new properties |

##### Returns

`void`

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="articlebuttonitems"></a> `articleButtonItems` | `Map`\<`string`, [`IArticleButtonItem`](../items/IArticleButtonItem.md#iarticlebuttonitem)\> | Stores a collection of elements where the keys are the key parameters from the ArticleButtonItem objects. A list for article button items is generated based on this collection. | [interfaces/plugins/IArticleButtonPlugin.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IArticleButtonPlugin.ts#L54) |
### Example

Plugin with article button items

```typescript
class MyPlugin implements IPlugin, IArticleButtonPlugin {
  articleButtonItems: Map<string, IArticleButtonItem> = new Map();

  addArticleButtonItem = (item: IArticleButtonItem): void => {
    this.articleButtonItems.set(item.key, item);
  };

  getArticleButtonItems = () => {
    return this.articleButtonItems;
  };

  updateArticleButtonItem = (item: IArticleButtonItem): void => {
    this.articleButtonItems.set(item.key, item);
  };
}
```

