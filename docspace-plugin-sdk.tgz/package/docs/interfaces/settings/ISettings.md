---
toc_max_heading_level: 3
hide_title: true
---

# ISettings

Defined in: [interfaces/settings/ISettings.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/settings/ISettings.ts#L190)

Defines the administrator or owner settings block that is embedded in the modal window with the plugin description.

<img alt="settings-block" src="/assets/images/docspace/settings-block.png" style={{width: "400px"}} />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="settings"></a> `settings` | [`IBox`](../components/IBox.md#ibox) | Defines the administrator or owner settings | [interfaces/settings/ISettings.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/settings/ISettings.ts#L192) |
| <a id="savebutton"></a> `saveButton` | [`ButtonGroup`](../components/Component.md#buttongroup) | Defines the button to save the settings | [interfaces/settings/ISettings.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/settings/ISettings.ts#L195) |
| <a id="isloading"></a> `isLoading?` | `boolean` | Specifies if the settings block will be displayed as a loader icon or not | [interfaces/settings/ISettings.ts:198](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/settings/ISettings.ts#L198) |
| <a id="onload"></a> `onLoad?` | () => `Promise`\<\{ `settings`: [`IBox`](../components/IBox.md#ibox); `saveButton?`: [`ButtonGroup`](../components/Component.md#buttongroup); \}\> | Defines a function that is triggered whenever the settings block is loaded. Returns a promise with the updated settings box and optional save button. | [interfaces/settings/ISettings.ts:204](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/settings/ISettings.ts#L204) |
### Examples

Theme customization settings with color picker

```typescript
const themeSettings: ISettings = {
  settings: {
    type: "box",
    children: [
      {
        type: "colorPicker",
        id: "primary-color",
        label: "Primary Color",
        value: "#007BFF",
        onChange: (color) => updateThemeColor(color)
      },
      {
        type: "toggle",
        id: "dark-mode",
        label: "Dark Mode",
        value: false,
        onChange: (enabled) => toggleDarkMode(enabled)
      }
    ]
  },
  saveButton: {
    type: "button",
    label: "Save Theme",
    onClick: async () => {
      try {
        await saveThemeSettings();
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: "success",
            title: "Theme Updated",
            message: "Theme settings saved | Changes applied | Refresh to see updates"
          }]
        };
      } catch (error) {
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: "error",
            title: "Save Failed",
            message: "Unable to save theme | Check your changes"
          }]
        };
      }
    }
  },
  isLoading: false,
  onLoad: async () => {
    const savedSettings = await loadThemeSettings();
    return {
      settings: {
        type: "box",
        children: [
          {
            type: "colorPicker",
            id: "primary-color",
            label: "Primary Color",
            value: savedSettings.primaryColor
          },
          {
            type: "toggle",
            id: "dark-mode",
            label: "Dark Mode",
            value: savedSettings.darkMode
          }
        ]
      }
    };
  }
};
```

Language configuration settings with validation

```typescript
const languageSettings: ISettings = {
  settings: {
    type: "box",
    children: [
      {
        type: "select",
        id: "default-language",
        label: "Default Language",
        options: [
          { value: "en", label: "English" },
          { value: "es", label: "Spanish" },
          { value: "fr", label: "French" }
        ],
        value: "en",
        onChange: (lang) => updateDefaultLanguage(lang)
      },
      {
        type: "toggle",
        id: "auto-detect",
        label: "Auto-detect User Language",
        value: true,
        onChange: (enabled) => toggleAutoDetect(enabled)
      }
    ]
  },
  saveButton: {
    type: "button",
    label: "Save Language Settings",
    onClick: async () => {
      try {
        await saveLanguageSettings();
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: "success",
            title: "Language Updated",
            message: "Language settings saved | Changes applied | Refresh to see updates"
          }]
        };
      } catch (error) {
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: "error",
            title: "Save Failed",
            message: "Unable to save language settings | Check your changes"
          }]
        };
      }
    }
  },
  isLoading: false,
  onLoad: async () => {
    const savedSettings = await loadLanguageSettings();
    return {
      settings: {
        type: "box",
        children: [
          {
            type: "select",
            id: "default-language",
            label: "Default Language",
            options: [
              { value: "en", label: "English" },
              { value: "es", label: "Spanish" },
              { value: "fr", label: "French" }
            ],
            value: savedSettings.defaultLanguage
          },
          {
            type: "toggle",
            id: "auto-detect",
            label: "Auto-detect User Language",
            value: savedSettings.autoDetect
          }
        ]
      }
    };
  }
};
```

