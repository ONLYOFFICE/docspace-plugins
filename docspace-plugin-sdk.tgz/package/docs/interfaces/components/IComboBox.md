---
toc_max_heading_level: 3
hide_title: true
---

# IComboBox

Defined in: [interfaces/components/IComboBox.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L83)

Custom combo box input.

<img alt="combobox" src="/assets/images/docspace/combobox.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="options"></a> `options` | [`IComboBoxItem`](#icomboboxitem)[] | Defines the combo box options | [interfaces/components/IComboBox.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L89) |
| <a id="selectedoption"></a> `selectedOption` | [`IComboBoxItem`](#icomboboxitem) | Defines the combo box selected option | [interfaces/components/IComboBox.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L96) |
| <a id="onselect"></a> `onSelect?` | (`item`: [`IComboBoxItem`](#icomboboxitem)) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the combo box is selected | [interfaces/components/IComboBox.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L103) |
| <a id="scaled"></a> `scaled?` | `boolean` | Specifies that the combo box is scaled by its parent | [interfaces/components/IComboBox.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L110) |
| <a id="directionx"></a> `directionX?` | `"left"` \| `"right"` | Defines the position of the combo box in the X direction | [interfaces/components/IComboBox.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L117) |
| <a id="directiony"></a> `directionY?` | `"both"` \| `"top"` \| `"bottom"` | Defines the position of the combo box in the Y direction | [interfaces/components/IComboBox.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L124) |
| <a id="displaytype"></a> `displayType?` | `"default"` \| `"toggle"` | Defines the combo box display type | [interfaces/components/IComboBox.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L131) |
| <a id="modernview"></a> `modernView?` | `boolean` | Specifies whether to display the combo box in the modern view | [interfaces/components/IComboBox.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L138) |
| <a id="isdisabled"></a> `isDisabled?` | `boolean` | Specifies if the combo box is disabled or not | [interfaces/components/IComboBox.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L145) |
| <a id="showdisableditems"></a> `showDisabledItems?` | `boolean` | Whether to show disabled combo box options | [interfaces/components/IComboBox.ts:152](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L152) |
| <a id="opened"></a> `opened?` | `boolean` | Specifies whether to open the combo box | [interfaces/components/IComboBox.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L159) |
| <a id="scaledoptions"></a> `scaledOptions?` | `boolean` | Specifies whether the combo box options are scaled by the combo box button | [interfaces/components/IComboBox.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L166) |
| <a id="ontoggle"></a> `onToggle?` | () => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the combo box is clicked when "displayType == toggle" | [interfaces/components/IComboBox.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L173) |
| <a id="noborder"></a> `noBorder?` | `boolean` | Specifies whether to display the combo box without borders | [interfaces/components/IComboBox.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L180) |
| <a id="withbackdrop"></a> `withBackdrop?` | `boolean` | Specifies whether the combo box contains a backdrop | [interfaces/components/IComboBox.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L187) |
| <a id="dropdownmaxheight"></a> `dropDownMaxHeight?` | `number` | Defines the maximum height of the dropdown list | [interfaces/components/IComboBox.ts:194](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L194) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IComboBox.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L202) |

***

### Example

Multi-language selector with toast notifications

```typescript
const languageSelector: IComboBox = {
  options: [
    {
      key: "en-US",
      label: "English (US)",
      icon: "language-en.svg"
    },
    {
      key: "es-ES",
      label: "Español",
      icon: "language-es.svg"
    },
    {
      key: "fr-FR",
      label: "Français",
      icon: "language-fr.svg",
      disabled: true
    }
  ],
  selectedOption: {
    key: "en-US",
    label: "English (US)",
    icon: "language-en.svg"
  },
  onSelect: (item) => {
    return {
      actions: [Actions.updateProps, Actions.showToast],
      newProps: {
        selectedOption: item
      },
      toastProps: [{
        title: "Language Changed",
        type: "success",
        message: `Interface language changed to ${item.label}`
      }]
    };
  },
  scaled: true,
  directionX: "right",
  directionY: "bottom",
  displayType: "default",
  dropDownMaxHeight: 300,
  showDisabledItems: true,
  withBackdrop: true,
  isDisabled: false,
  noBorder: false,
  opened: false,
  scaledOptions: true,
  modernView: true
}
```

## IComboBoxItem

Defined in: [interfaces/components/IComboBox.ts:223](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L223)

Custom combo box option.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="key"></a> `key` | `string` | Unique identifier for the option | [interfaces/components/IComboBox.ts:229](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L229) |
| <a id="label"></a> `label` | `string` | Display text for the option | [interfaces/components/IComboBox.ts:236](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L236) |
| <a id="icon"></a> `icon?` | `string` | Optional icon for the option | [interfaces/components/IComboBox.ts:243](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L243) |
| <a id="disabled"></a> `disabled?` | `boolean` | Specifies if the combo box option is disabled or not | [interfaces/components/IComboBox.ts:250](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L250) |
### Example

Basic language option with icon

```typescript
const languageOption: IComboBoxItem = {
  key: "en-US",
  label: "English (US)",
  icon: "language-en.svg",
  disabled: false
}
```

