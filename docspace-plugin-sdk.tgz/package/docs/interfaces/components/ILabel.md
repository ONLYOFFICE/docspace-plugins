---
toc_max_heading_level: 3
hide_title: true
---

# ILabel

Defined in: [interfaces/components/ILabel.ts:56](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L56)

Field name in the form.

<img alt="label" src="/assets/images/docspace/label.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="text"></a> `text` | `string` | Defines the element text | [interfaces/components/ILabel.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L60) |
| <a id="isrequired"></a> `isRequired?` | `boolean` | Specifies whether the field to which the label is attached is required | [interfaces/components/ILabel.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L65) |
| <a id="error"></a> `error?` | `boolean` | Specifies whether the field to which the label is attached is incorrect | [interfaces/components/ILabel.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L70) |
| <a id="title"></a> `title?` | `string` | Defines the label title | [interfaces/components/ILabel.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L75) |
| <a id="truncate"></a> `truncate?` | `boolean` | Specifies whether the word wrapping is disabled | [interfaces/components/ILabel.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L81) |
| <a id="htmlfor"></a> `htmlFor?` | `string` | Defines the field ID to which the label is attached | [interfaces/components/ILabel.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L87) |
| <a id="display"></a> `display?` | `string` | Specifies whether the "display" property is set | [interfaces/components/ILabel.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L93) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/ILabel.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L101) |
### Examples

Required field label with inline display

```typescript
const emailLabel: ILabel = {
  text: "Email Address",
  isRequired: true,
  error: false,
  isInline: true,
  title: "Enter your email address",
  htmlFor: "email-input",
  display: "flex"
}
```

Error state label with truncation and block display

```typescript
const longFieldLabel: ILabel = {
  text: "Document Processing Configuration Settings",
  isRequired: false,
  error: true,
  truncate: true,
  title: "Configure document processing settings",
  htmlFor: "doc-settings",
  display: "block"
}
```

