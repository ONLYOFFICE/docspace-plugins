---
sidebar_position: 1
---

# Components

UI components for building plugin interfaces — dialogs, buttons, inputs, and other visual elements rendered inside DocSpace modals and panels.

Use these interfaces when constructing custom plugin UI with `IModalDialog`, `IBox`, or other layout containers.

## Overview

The following components are available:

| Interface | Description |
| --- | --- |
| [`Component`](Component.md) | A component that is used to add components into Box. |
| [`IBox`](IBox.md) | A container that lays out its contents in one direction. |
| [`IButton`](IButton.md) | Defines button size options |
| [`ICheckbox`](ICheckbox.md) | Custom checkbox. |
| [`IComboBox`](IComboBox.md) | Custom combo box input. |
| [`ICreateDialog`](ICreateDialog.md) | Modal dialog for creating certain item (file, folder, etc. |
| [`IFloatingOperationsButton`](IFloatingOperationsButton.md) | Determines the icon and visual representation of the operation. |
| [`IFrame`](IFrame.md) | A component that is used to embed a third-party website into a modal window or the settings page. |
| [`IIconButton`](IIconButton.md) | A component that displays an interactive icon button with hover and click states. |
| [`IImage`](IImage.md) | A component that is used to embed an image not from the assets folder into a modal window or the settings page. |
| [`IInput`](IInput.md) | The supported input sizes. |
| [`ILabel`](ILabel.md) | Field name in the form. |
| [`ILink`](ILink.md) | Defines the link type. |
| [`IMediaViewer`](IMediaViewer.md) | Properties for the Media Viewer component that allows plugins to display custom content. |
| [`IModalDialog`](IModalDialog.md) | The supported modal dialog types. |
| [`ISkeleton`](ISkeleton.md) | A component that is used to hide components during uploading. |
| [`IText`](IText.md) | Plain text. |
| [`ITextArea`](ITextArea.md) | Custom textarea. |
| [`IToast`](IToast.md) | The supported toast types. |
| [`IToggleButton`](IToggleButton.md) | Custom toggle button input for binary state controls. |
| [`Selector`](Selector.md) | Defines the base properties for all selector components. |