---
toc_max_heading_level: 2
hide_title: true
---

# IMediaViewer

Defined in: [interfaces/components/IMediaViewer.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L115)

Properties for the Media Viewer component that allows plugins to display custom content.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="fileid"></a> `fileId?` | `string` \| `number` | The ID of the file to display in the media viewer. If not specified, the first file in the playlist will be displayed. | [interfaces/components/IMediaViewer.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L120) |
| <a id="content"></a> `content` | [`IBox`](IBox.md#ibox) | The custom content to render inside the media viewer. This should be a Box component that contains your custom UI elements. | [interfaces/components/IMediaViewer.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L125) |
| <a id="title"></a> `title?` | `string` | Optional title to display in the media viewer header. If not provided, the default file name will be used. | [interfaces/components/IMediaViewer.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L131) |
| <a id="onclose"></a> `onClose?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | Callback function that is called when the media viewer should be closed. This is triggered when the user clicks the close button, background, or presses ESC. Can return a TReturnMessage with Actions.closeMediaViewer to close the viewer. | [interfaces/components/IMediaViewer.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L139) |
| <a id="playlistfilter"></a> `playlistFilter?` | [`IMediaViewerPlaylistFilter`](#imediaviewerplaylistfilter-1) | Filter configuration for playlist. Only applies when enablePlaylist is true. | [interfaces/components/IMediaViewer.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L145) |
| <a id="navigation"></a> `navigation?` | [`IMediaViewerNavigation`](#imediaviewernavigation-1) | Navigation callbacks. Only applies when enablePlaylist is true. | [interfaces/components/IMediaViewer.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L151) |
| <a id="onload"></a> `onLoad?` | (`data`: \{ `fileId`: `string` \| `number`; \}) => [`TReturnMessage`](../utils.md#treturnmessage) | A function that is executed when the plugin viewer is mounted. It is called once when the viewer is first displayed. | [interfaces/components/IMediaViewer.ts:158](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L158) |

***

### Examples

Display custom video player in Media Viewer

```typescript
const mediaViewerProps: IMediaViewer = {
  title: "Custom Video Player",
  content: {
    component: "box",
    props: {
      widthProp: "100%",
      heightProp: "100%",
      displayProp: "flex",
      children: [
        {
          component: "iframe",
          props: {
            id: "video-player-frame",
            src: "https://player.example.com/video/12345",
            width: "100%",
            height: "100%",
            frameBorder: "0",
            allowFullScreen: true
          }
        }
      ]
    }
  },
  onClose: () => {
    return {
      actions: [Actions.closeMediaViewer]
    };
  },
  onLoad: (data) => {
    console.log("Media viewer loaded with fileId:", data.fileId);
    return { actions: [] };
  }
};
```

Display custom image viewer with playlist navigation

```typescript
const mediaViewerProps: IMediaViewer = {
  title: "Image with Annotations",
  content: {
    component: "box",
    props: {
      widthProp: "100%",
      heightProp: "100%",
      children: [
        {
          component: "iframe",
          props: {
            id: "annotation-viewer",
            src: "https://annotator.example.com/image/67890",
            width: "100%",
            height: "100%"
          }
        }
      ]
    }
  },
  playlistFilter: {
    filesExsts: [FilesExst.jpg, FilesExst.png, ".svg"],
    filesSecurity: [FilesSecurity.read],
    usersTypes: [UsersType.user, UsersType.collaborator],
    devices: [Devices.desktop, Devices.tablet]
  },
  navigation: {
    onNext: () => {
      console.log("Next file");
      return { actions: [] };
    },
    onPrevious: () => {
      console.log("Previous file");
      return { actions: [] };
    },
    onFileChange: (data) => {
      console.log("File changed to:", data.fileId);
      return { actions: [] };
    }
  }
};
```

## IMediaViewerPlaylistFilter

Defined in: [interfaces/components/IMediaViewer.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L166)

Filter configuration for media viewer playlist.
Defines which files should be included in the playlist.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="filesexsts"></a> `filesExsts?` | `string`[] | Allowed file extensions (e.g., [FilesExst.doc, ".drawio", ".md"]). If not specified, all extensions are allowed. | [interfaces/components/IMediaViewer.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L171) |
| <a id="filessecurity"></a> `filesSecurity?` | [`FilesSecurity`](../../enums/Files.md#filessecurity)[] | Required security permissions for files. If not specified, all security permissions are allowed. | [interfaces/components/IMediaViewer.ts:177](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L177) |
| <a id="userstypes"></a> `usersTypes?` | [`UsersType`](../../enums/UsersType.md#userstype)[] | The types of users who will see the media viewer. Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user. If this parameter is not specified, then the media viewer will be displayed for all user types. | [interfaces/components/IMediaViewer.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L184) |
| <a id="devices"></a> `devices?` | [`Devices`](../../enums/Devices.md#devices)[] | The types of devices where the media viewer will be displayed. At the moment the following device types are available: mobile, tablet, desktop. If this parameter is not specified, then the media viewer will be displayed in any device types. | [interfaces/components/IMediaViewer.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L191) |

***

## IMediaViewerNavigation

Defined in: [interfaces/components/IMediaViewer.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L199)

Navigation callbacks for media viewer.
Called when user navigates through the playlist.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="onnext"></a> `onNext?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | Called when navigating to next file. | [interfaces/components/IMediaViewer.ts:203](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L203) |
| <a id="onprevious"></a> `onPrevious?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | Called when navigating to previous file. | [interfaces/components/IMediaViewer.ts:208](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L208) |
| <a id="onfilechange"></a> `onFileChange?` | (`data`: \{ `fileId`: `string` \| `number`; \}) => [`TReturnMessage`](../utils.md#treturnmessage) | Called when file changes. | [interfaces/components/IMediaViewer.ts:214](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L214) |
