---
toc_max_heading_level: 3
hide_title: true
---

# IIconButton

Defined in: [interfaces/components/IIconButton.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L76)

A component that displays an interactive icon button with hover and click states.

### Appearance

Controls the visual presentation of the icon button including size, colors, and icon states.

#### iconName?

```ts
optional iconName: string;
```

Defined in: [interfaces/components/IIconButton.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L82)

Icon name with extension

#### iconHoverName?

```ts
optional iconHoverName: string;
```

Defined in: [interfaces/components/IIconButton.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L89)

Icon name with extension for hover state

#### iconClickName?

```ts
optional iconClickName: string;
```

Defined in: [interfaces/components/IIconButton.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L96)

Icon name with extension for click state

#### color?

```ts
optional color: string;
```

Defined in: [interfaces/components/IIconButton.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L103)

Icon color. Can be "accent" or any CSS color value

#### hoverColor?

```ts
optional hoverColor: string;
```

Defined in: [interfaces/components/IIconButton.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L110)

Icon color on hover action

#### clickColor?

```ts
optional clickColor: string;
```

Defined in: [interfaces/components/IIconButton.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L117)

Icon color on click action

#### size?

```ts
optional size: number;
```

Defined in: [interfaces/components/IIconButton.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L124)

Button height and width value. Can be a number (pixels)

#### isFill?

```ts
optional isFill: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L131)

Determines if icon fill is needed

#### isStroke?

```ts
optional isStroke: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L138)

Determines if icon stroke is needed

#### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/IIconButton.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L166)

Sets component id

#### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/IIconButton.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L173)

Data when user hover on icon (tooltip text)

#### tooltipId?

```ts
optional tooltipId: string;
```

Defined in: [interfaces/components/IIconButton.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L180)

Tooltip id for advanced tooltip configuration

#### tooltipContent?

```ts
optional tooltipContent: string;
```

Defined in: [interfaces/components/IIconButton.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L187)

Tooltip content text

#### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IIconButton.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L195)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

### Behavior

Defines the interactive behavior and event handling of the icon button.

#### onClick()?

```ts
optional onClick: () => TReturnMessage;
```

Defined in: [interfaces/components/IIconButton.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L159)

Sets a button callback function triggered when the button is clicked

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### State Management

Manages the button's state including disabled, loading, and clickable states.

#### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L145)

Sets the button to present a disabled state

#### isClickable?

```ts
optional isClickable: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:152](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L152)

Sets cursor value to indicate clickability
### Example

Simple icon button with click handler

```typescript
const deleteButton: IIconButton = {
  iconName: delete.svg",
  size: 20,
  color: "#333333",
  hoverColor: "#FF0000",
  onClick: async () => {
    try {
      await deleteItem();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Success",
          type: "success",
          message: "Item deleted successfully"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Error",
          type: "error",
          message: "Failed to delete item"
        }]
      };
    }
  },
  isDisabled: false,
  title: "Delete item"
}
```

