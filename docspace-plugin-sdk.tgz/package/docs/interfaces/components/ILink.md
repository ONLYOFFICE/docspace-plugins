---
toc_max_heading_level: 3
hide_title: true
---

# ILink

Defined in: [interfaces/components/ILink.ts:43](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L43)

Defines the link component properties.

### Extends

- [`IText`](IText.md#itext)

### Properties

| Property | Type | Description | Inherited from | Defined in |
| ------ | ------ | ------ | ------ | ------ |
| <a id="href"></a> `href?` | `string` | URL for the link | - | [interfaces/components/ILink.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L45) |
| <a id="id"></a> `id?` | `string` | Link identifier | - | [interfaces/components/ILink.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L48) |
| <a id="ishovered"></a> `isHovered?` | `boolean` | Sets hovered state and link effects | - | [interfaces/components/ILink.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L51) |
| <a id="istextoverflow"></a> `isTextOverflow?` | `boolean` | Activates text-overflow with ellipsis | - | [interfaces/components/ILink.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L54) |
| <a id="nohover"></a> `noHover?` | `boolean` | Disables hover effect | - | [interfaces/components/ILink.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L57) |
| <a id="enableuserselect"></a> `enableUserSelect?` | `boolean` | Enables user selection | - | [interfaces/components/ILink.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L60) |
| <a id="type"></a> `type?` | [`LinkType`](#linktype) | Link type (page or action) | - | [interfaces/components/ILink.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L63) |
| <a id="target"></a> `target?` | [`LinkTarget`](#linktarget) | Target attribute for link | - | [interfaces/components/ILink.ts:66](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L66) |
| <a id="textdecoration"></a> `textDecoration?` | \| `"none"` \| `"underline"` \| `"line-through"` \| `"overline"` \| `"underline dotted"` \| `"underline dashed"` | Text decoration style | - | [interfaces/components/ILink.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L69) |
| <a id="onclick"></a> `onClick?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | Click handler (for action type links) | - | [interfaces/components/ILink.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L78) |
| <a id="text"></a> `text` | `string` | Defines the text | [`IText`](IText.md#itext).[`text`](IText.md#text) | [interfaces/components/IText.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L78) |
| <a id="title"></a> `title?` | `string` | Defines the text title | [`IText`](IText.md#itext).[`title`](IText.md#title) | [interfaces/components/IText.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L84) |
| <a id="fontsize"></a> `fontSize?` | `string` | Defines the text font size | [`IText`](IText.md#itext).[`fontSize`](IText.md#fontsize) | [interfaces/components/IText.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L90) |
| <a id="fontweight"></a> `fontWeight?` | `string` \| `number` | Defines the text font weight | [`IText`](IText.md#itext).[`fontWeight`](IText.md#fontweight) | [interfaces/components/IText.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L96) |
| <a id="truncate"></a> `truncate?` | `boolean` | Specifies whether the word wrapping is set | [`IText`](IText.md#itext).[`truncate`](IText.md#truncate) | [interfaces/components/IText.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L102) |
| <a id="isbold"></a> `isBold?` | `boolean` | Specifies whether the text font weight is set to bold | [`IText`](IText.md#itext).[`isBold`](IText.md#isbold) | [interfaces/components/IText.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L108) |
| <a id="isitalic"></a> `isItalic?` | `boolean` | Specifies whether the text style is set to italic | [`IText`](IText.md#itext).[`isItalic`](IText.md#isitalic) | [interfaces/components/IText.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L114) |
| <a id="isinline"></a> `isInline?` | `boolean` | Specifies whether the "display: inline-block" property is set | [`IText`](IText.md#itext).[`isInline`](IText.md#isinline) | [interfaces/components/IText.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L120) |
| <a id="textalign"></a> `textAlign?` | `string` | Specifies whether the "text-align" property is set | [`IText`](IText.md#itext).[`textAlign`](IText.md#textalign) | [interfaces/components/IText.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L126) |
| <a id="noselect"></a> `noSelect?` | `boolean` | Specifies whether the text selection is disabled | [`IText`](IText.md#itext).[`noSelect`](IText.md#noselect) | [interfaces/components/IText.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L132) |
| <a id="display"></a> `display?` | `string` | Specifies whether the "display" property is set | [`IText`](IText.md#itext).[`display`](IText.md#display) | [interfaces/components/IText.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L138) |
| <a id="lineheight"></a> `lineHeight?` | `string` | Defines the text line height | [`IText`](IText.md#itext).[`lineHeight`](IText.md#lineheight) | [interfaces/components/IText.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L144) |
| <a id="color"></a> `color?` | `string` | Defines the text color | [`IText`](IText.md#itext).[`color`](IText.md#color) | [interfaces/components/IText.ts:150](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L150) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [`IText`](IText.md#itext).[`className`](IText.md#classname) | [interfaces/components/IText.ts:158](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L158) |
### Example

```typescript
import { ILink, LinkType, LinkTarget } from "@onlyoffice/docspace-plugin-sdk";

const link: ILink = {
  href: "https://example.com",
  children: "Visit Example",
  type: LinkType.page,
  target: LinkTarget.blank,
  isBold: false,
  color: "accent",
  fontSize: "14px",
  onClick: () => {
    console.log("Link clicked");
  }
};
```

## LinkType

Defined in: [interfaces/components/ILink.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L84)

Defines the link type.

### Enumeration Members

#### page

```ts
page: "page";
```

Defined in: [interfaces/components/ILink.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L86)

Regular page link

#### action

```ts
action: "action";
```

Defined in: [interfaces/components/ILink.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L88)

Action link (clickable but not navigating)

***

## LinkTarget

Defined in: [interfaces/components/ILink.ts:94](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L94)

Defines the link target attribute.

### Enumeration Members

#### blank

```ts
blank: "_blank";
```

Defined in: [interfaces/components/ILink.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L96)

Opens in a new tab

#### self

```ts
self: "_self";
```

Defined in: [interfaces/components/ILink.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L98)

Opens in the same frame

#### parent

```ts
parent: "_parent";
```

Defined in: [interfaces/components/ILink.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L100)

Opens in the parent frame

#### top

```ts
top: "_top";
```

Defined in: [interfaces/components/ILink.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L102)

Opens in the full body of the window

***

