---
toc_max_heading_level: 3
hide_title: true
---

# IToast

Defined in: [interfaces/components/IToast.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L76)

A brief notification that appears on the screen.

<img alt="toast" src="/assets/images/docspace/toast.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="type"></a> `type` | [`ToastType`](#toasttype) | Defines the toast type, which determines the toast color and icon | [interfaces/components/IToast.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L80) |
| <a id="title"></a> `title` | `string` | Defines the toast title | [interfaces/components/IToast.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L85) |
| <a id="withcross"></a> `withCross?` | `boolean` | Specifies whether the "Close" button will be displayed in the toast to close it (true). Otherwise, the toast will disappear after clicking on any toast area (false). | [interfaces/components/IToast.ts:92](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L92) |
| <a id="timeout"></a> `timeout?` | `number` | Defines the time (in milliseconds) for showing the toast. Setting the value to 0 allows the toast to be displayed continuously until clicking on it. | [interfaces/components/IToast.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L99) |
### Examples

Auto-dismissing success notification

```typescript
const saveSuccess: IToast = {
  type: ToastType.success,
  title: "Changes saved successfully",
  withCross: false,
  timeout: 3000 // Dismiss after 3 seconds
}
```

Persistent error notification with manual dismiss

```typescript
const errorToast: IToast = {
  type: ToastType.error,
  title: "Failed to upload file. Please try again.",
  withCross: true,
  timeout: 0 // Stay until manually dismissed
}
```

Session expiration warning with medium duration

```typescript
const warningToast: IToast = {
  type: ToastType.warning,
  title: "Your session will expire in 5 minutes",
  withCross: true,
  timeout: 5000
}
```

Temporary update notification

```typescript
const infoToast: IToast = {
  type: ToastType.info,
  title: "New updates are available",
  withCross: false,
  timeout: 4000
}
```

## ToastType

Defined in: [interfaces/components/IToast.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L107)

The supported toast types.

### Enumeration Members

#### success

```ts
success: "success";
```

Defined in: [interfaces/components/IToast.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L109)

Success toast with green color scheme

#### error

```ts
error: "error";
```

Defined in: [interfaces/components/IToast.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L111)

Error toast with red color scheme

#### warning

```ts
warning: "warning";
```

Defined in: [interfaces/components/IToast.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L113)

Warning toast with yellow color scheme

#### info

```ts
info: "info";
```

Defined in: [interfaces/components/IToast.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L115)

Info toast with blue color scheme

***

