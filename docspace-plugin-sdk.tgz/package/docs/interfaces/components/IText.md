---
toc_max_heading_level: 3
hide_title: true
---

# IText

Defined in: [interfaces/components/IText.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L73)

Plain text.

<img alt="text" src="/assets/images/docspace/text.png" />

### Extended by

- [`ILink`](ILink.md#ilink)

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="text"></a> `text` | `string` | Defines the text | [interfaces/components/IText.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L78) |
| <a id="title"></a> `title?` | `string` | Defines the text title | [interfaces/components/IText.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L84) |
| <a id="fontsize"></a> `fontSize?` | `string` | Defines the text font size | [interfaces/components/IText.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L90) |
| <a id="fontweight"></a> `fontWeight?` | `string` \| `number` | Defines the text font weight | [interfaces/components/IText.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L96) |
| <a id="truncate"></a> `truncate?` | `boolean` | Specifies whether the word wrapping is set | [interfaces/components/IText.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L102) |
| <a id="isbold"></a> `isBold?` | `boolean` | Specifies whether the text font weight is set to bold | [interfaces/components/IText.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L108) |
| <a id="isitalic"></a> `isItalic?` | `boolean` | Specifies whether the text style is set to italic | [interfaces/components/IText.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L114) |
| <a id="isinline"></a> `isInline?` | `boolean` | Specifies whether the "display: inline-block" property is set | [interfaces/components/IText.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L120) |
| <a id="textalign"></a> `textAlign?` | `string` | Specifies whether the "text-align" property is set | [interfaces/components/IText.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L126) |
| <a id="noselect"></a> `noSelect?` | `boolean` | Specifies whether the text selection is disabled | [interfaces/components/IText.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L132) |
| <a id="display"></a> `display?` | `string` | Specifies whether the "display" property is set | [interfaces/components/IText.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L138) |
| <a id="lineheight"></a> `lineHeight?` | `string` | Defines the text line height | [interfaces/components/IText.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L144) |
| <a id="color"></a> `color?` | `string` | Defines the text color | [interfaces/components/IText.ts:150](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L150) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IText.ts:158](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L158) |
### Examples

Bold centered heading with custom typography

```typescript
const heading: IText = {
  text: "Document Management",
  fontSize: "24px",
  fontWeight: 600,
  lineHeight: "32px",
  color: "#333333",
  isBold: true,
  noSelect: true,
  textAlign: "center"
}
```

Truncated description with hover tooltip

```typescript
const description: IText = {
  text: "This is a long description that will be truncated if it exceeds the container width...",
  fontSize: "14px",
  lineHeight: "20px",
  color: "#666666",
  truncate: true,
  title: "Full description shown on hover"
}
```

Inline processing status with custom styling

```typescript
const status: IText = {
  text: "Processing",
  fontSize: "12px",
  isInline: true,
  isItalic: true,
  color: "#0066cc",
  display: "inline-flex",
  fontWeight: 500
}
```

