---
toc_max_heading_level: 3
hide_title: true
---

# IButton

Defined in: [interfaces/components/IButton.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L65)

A component that is used for an action on a page.

<img alt="button" src="/assets/images/docspace/button.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="label"></a> `label` | `string` | Defines the button text | [interfaces/components/IButton.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L70) |
| <a id="size"></a> `size` | [`ButtonSize`](#buttonsize) | Defines the button size. The normal size is equal to 36x40 px on the Desktop and Touchscreen devices. Can be: "extraSmall", "small", "normal", "medium". The default value is "extraSmall" | [interfaces/components/IButton.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L77) |
| <a id="onclick"></a> `onClick` | () => \| `void` \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Sets a function which specifies an action initiated upon clicking the button | [interfaces/components/IButton.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L83) |
| <a id="primary"></a> `primary?` | `boolean` | Specifies if the button is primary or not. If the button is primary, it is colored blue | [interfaces/components/IButton.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L89) |
| <a id="scale"></a> `scale?` | `boolean` | Specifies if the button width will be scaled to 100% or not | [interfaces/components/IButton.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L95) |
| <a id="isloading"></a> `isLoading?` | `boolean` | Specifies if the button will be displayed as a loader icon or not | [interfaces/components/IButton.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L101) |
| <a id="isdisabled"></a> `isDisabled?` | `boolean` | Specifies if the button is disabled or not. The disabled button is blurred | [interfaces/components/IButton.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L107) |
| <a id="withloadingafterclick"></a> `withLoadingAfterClick?` | `boolean` | Specifies whether to set the "isLoading" state to the button after it is clicked until the action is completed | [interfaces/components/IButton.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L113) |
| <a id="disablewhilerequestrunning"></a> `disableWhileRequestRunning?` | `boolean` | Specifies whether to set the "isDisabled" state for the button when the "withLoadingAfterClick" parameter is set to true, and it is clicked either on the page or in the dialog box | [interfaces/components/IButton.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L120) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IButton.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L127) |
### Example

Primary save button with loading state and error handling

```typescript
const saveButton: IButton = {
  label: "Save Changes",
  size: ButtonSize.normal,
  onClick: async () => {
    try {
      await saveChanges();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Success",
          type: "success",
          message: "Changes saved successfully"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Error",
          type: "error",
          message: "Failed to save changes"
        }]
      };
    }
  },
  primary: true,
  scale: false,
  isLoading: false,
  isDisabled: false,
  withLoadingAfterClick: true,
  disableWhileRequestRunning: true
}
```

## ButtonSize

Defined in: [interfaces/components/IButton.ts:135](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L135)

Defines button size options

### Enumeration Members

#### extraSmall

```ts
extraSmall: "extra-small";
```

Defined in: [interfaces/components/IButton.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L137)

Extra small button size

#### small

```ts
small: "small";
```

Defined in: [interfaces/components/IButton.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L139)

Small button size

#### normal

```ts
normal: "normal";
```

Defined in: [interfaces/components/IButton.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L141)

Normal button size

#### medium

```ts
medium: "medium";
```

Defined in: [interfaces/components/IButton.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L143)

Medium button size

***

