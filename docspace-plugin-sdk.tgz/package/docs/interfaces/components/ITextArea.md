---
toc_max_heading_level: 3
hide_title: true
---

# ITextArea

Defined in: [interfaces/components/ITextArea.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L101)

Custom textarea.

<img alt="textarea" src="/assets/images/docspace/textarea.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="value"></a> `value` | `string` | Defines the textarea value. | [interfaces/components/ITextArea.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L107) |
| <a id="onchange"></a> `onChange` | (`value`: `string`) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the textarea is changed. | [interfaces/components/ITextArea.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L114) |
| <a id="placeholder"></a> `placeholder?` | `string` | Defines the textarea placeholder. | [interfaces/components/ITextArea.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L121) |
| <a id="isdisabled"></a> `isDisabled?` | `boolean` | Specifies whether the textarea is disabled. | [interfaces/components/ITextArea.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L128) |
| <a id="isreadonly"></a> `isReadOnly?` | `boolean` | Specifies whether the textarea displays the read-only content. | [interfaces/components/ITextArea.ts:135](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L135) |
| <a id="haserror"></a> `hasError?` | `boolean` | Specifies whether to indicate that there is an error in the textarea. | [interfaces/components/ITextArea.ts:142](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L142) |
| <a id="maxlength"></a> `maxLength?` | `number` | Defines the maximum value length in the textarea. | [interfaces/components/ITextArea.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L149) |
| <a id="name"></a> `name?` | `string` | Defines the textarea HTML "name" property. | [interfaces/components/ITextArea.ts:156](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L156) |
| <a id="tabindex"></a> `tabIndex?` | `number` | Defines the textarea HTML "tabindex" property. | [interfaces/components/ITextArea.ts:163](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L163) |
| <a id="fontsize"></a> `fontSize?` | `number` | Defines the textarea font size. | [interfaces/components/ITextArea.ts:170](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L170) |
| <a id="heighttextarea"></a> `heightTextArea?` | `string` \| `number` | Defines the textarea height. | [interfaces/components/ITextArea.ts:177](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L177) |
| <a id="isjsonfield"></a> `isJSONField?` | `boolean` | Specifies whether the textarea is prettified for JSON and the line numeration is added. | [interfaces/components/ITextArea.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L184) |
| <a id="enablecopy"></a> `enableCopy?` | `boolean` | Specifies whether the "Copy" icon is displayed in the textarea. | [interfaces/components/ITextArea.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L191) |
| <a id="hasnumeration"></a> `hasNumeration?` | `boolean` | Specifies whether the numeration is inserted into the textarea. | [interfaces/components/ITextArea.ts:198](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L198) |
| <a id="isfullheight"></a> `isFullHeight?` | `boolean` | Specifies whether the height of the textarea content is calculated depending on the number of lines. | [interfaces/components/ITextArea.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L205) |
| <a id="heightscale"></a> `heightScale?` | `boolean` | Specifies whether the textarea has a height scale. | [interfaces/components/ITextArea.ts:212](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L212) |
| <a id="copyinfotext"></a> `copyInfoText?` | `boolean` | Specifies whether the toast / information text will be displayed when copying. | [interfaces/components/ITextArea.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L219) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/ITextArea.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L227) |
### Examples

JSON configuration editor with syntax validation

```typescript
const configEditor: ITextArea = {
  value: JSON.stringify({
    apiKey: "your-api-key",
    endpoint: "https://api.example.com",
    timeout: 5000
  }, null, 2),
  onChange: (value) => {
    try {
      JSON.parse(value);
      return {
        actions: [Actions.updateProps],
        newProps: {
          value,
          hasError: false
        }
      };
    } catch (error) {
      return {
        actions: [Actions.updateProps, Actions.showToast],
        newProps: {
          value,
          hasError: true
        },
        toastProps: [{
          title: "Invalid JSON",
          type: "error",
          message: "Please check your JSON syntax"
        }]
      };
    }
  },
  placeholder: "Enter JSON configuration...",
  isJSONField: true,
  enableCopy: true,
  hasNumeration: true,
  heightTextArea: 300,
  fontSize: 14,
  copyInfoText: true
}
```

Character-limited comment box with dynamic validation

```typescript
const commentBox: ITextArea = {
  value: "",
  onChange: (value) => {
    const hasError = value.length > 500;
    return {
      actions: [Actions.updateProps],
      newProps: {
        value,
        hasError
      }
    };
  },
  placeholder: "Add your comment (max 500 characters)",
  maxLength: 500,
  heightTextArea: "120px",
  isFullHeight: true,
  heightScale: true,
  fontSize: 16,
  name: "comment",
  tabIndex: 1
}
```

