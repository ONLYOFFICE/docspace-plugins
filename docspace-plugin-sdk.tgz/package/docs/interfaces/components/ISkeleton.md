---
toc_max_heading_level: 3
hide_title: true
---

# ISkeleton

Defined in: [interfaces/components/ISkeleton.ts:59](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L59)

A component that is used to hide components during uploading.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="width"></a> `width` | `string` | Defines the skeleton width | [interfaces/components/ISkeleton.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L64) |
| <a id="height"></a> `height` | `string` | Defines the skeleton height | [interfaces/components/ISkeleton.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L70) |
| <a id="borderradius"></a> `borderRadius?` | `string` | Defines the skeleton border radius | [interfaces/components/ISkeleton.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L76) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/ISkeleton.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L84) |
### Examples

Circular avatar placeholder for loading states

```typescript
const avatarSkeleton: ISkeleton = {
  width: "40px",
  height: "40px",
  borderRadius: "50%"
}
```

Responsive content card loading placeholder

```typescript
const cardSkeleton: ISkeleton = {
  width: "100%",
  height: "120px",
  borderRadius: "8px"
}
```

Text line loading animation

```typescript
const textSkeleton: ISkeleton = {
  width: "80%",
  height: "16px",
  borderRadius: "4px"
}
```

