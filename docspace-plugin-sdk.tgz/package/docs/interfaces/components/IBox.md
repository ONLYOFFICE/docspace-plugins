---
toc_max_heading_level: 3
hide_title: true
---

# IBox

Defined in: [interfaces/components/IBox.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L70)

A container that lays out its contents in one direction.
Box provides general CSS capabilities like flexbox layout, paddings, background color, border, and animation.

<img alt="box" src="/assets/images/docspace/box.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="widthprop"></a> `widthProp?` | `string` | Defines the border width of the element area | [interfaces/components/IBox.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L76) |
| <a id="paddingprop"></a> `paddingProp?` | `string` | Defines the padding area of all four sides of the element. This is a shorthand for "padding-top", "padding-right", "padding-bottom", and "padding-left" | [interfaces/components/IBox.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L84) |
| <a id="displayprop"></a> `displayProp?` | `string` | Specifies whether the element is treated as a block or inline element and also determines the layout used for its children, such as flow layout, grid or flex | [interfaces/components/IBox.ts:92](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L92) |
| <a id="flexdirection"></a> `flexDirection?` | `string` | Sets how the flex items are placed in the flex container defining the main axis (column or row) and the direction (normal or reversed) | [interfaces/components/IBox.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L100) |
| <a id="alignitems"></a> `alignItems?` | `string` | Sets the "alignSelf" value on all direct children as a group. In flexbox, it controls the alignment of items on the cross-axis. In grid layout, it controls the alignment of items on the block axis within their grid area | [interfaces/components/IBox.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L109) |
| <a id="borderprop"></a> `borderProp?` | `string` \| [`IBorderProp`](#iborderprop) | Defines the element border. It sets the values of border width, border style, and border color | [interfaces/components/IBox.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L115) |
| <a id="aligncontent"></a> `alignContent?` | `string` | Defines the distribution of space between and around content items along the flexbox cross-axis or the grid block axis | [interfaces/components/IBox.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L123) |
| <a id="alignself"></a> `alignSelf?` | `string` | Overrides a grid or flex item "alignItems" value. In grid, it aligns the item inside the grid area. In flexbox, it aligns the item on the cross-axis | [interfaces/components/IBox.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L131) |
| <a id="backgroundprop"></a> `backgroundProp?` | `string` | Defines all background style properties at once, such as color, image, origin and size, or repeat method | [interfaces/components/IBox.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L138) |
| <a id="flexbasis"></a> `flexBasis?` | `string` | Defines the initial main size of the flex item. It sets the size of the content box unless otherwise set with "box-sizing" | [interfaces/components/IBox.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L146) |
| <a id="flexprop"></a> `flexProp?` | `string` | Defines how the flex item will grow or shrink to fit the space available in its flex container. It is a shorthand for "flex-grow", "flex-shrink", and "flex-basis" | [interfaces/components/IBox.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L154) |
| <a id="flexwrap"></a> `flexWrap?` | `string` | Defines whether flex items are forced onto one line or can wrap onto multiple lines. If wrapping is allowed, it sets the direction that lines are stacked | [interfaces/components/IBox.ts:162](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L162) |
| <a id="gridarea"></a> `gridArea?` | `string` | Defines a shorthand property for "grid-row-start", "grid-column-start", "grid-row-end", and "grid-column-end", specifying the size of the grid item and location within the grid by contributing a line, a span, or nothing (automatic) to its grid placement, thereby specifying the edges of its grid area. | [interfaces/components/IBox.ts:172](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L172) |
| <a id="heightprop"></a> `heightProp?` | `string` | Defines the border height of the element area | [interfaces/components/IBox.ts:179](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L179) |
| <a id="justifycontent"></a> `justifyContent?` | `string` | Defines how the browser distributes space between and around content items along the main axis of a flex container, and the inline axis of a grid container | [interfaces/components/IBox.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L187) |
| <a id="justifyitems"></a> `justifyItems?` | `string` | Defines the default "justifySelf" for all items of the box, giving them all a default way of justifying each box along the appropriate axis | [interfaces/components/IBox.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L195) |
| <a id="justifyself"></a> `justifySelf?` | `string` | Defines the way the box is justified inside its alignment container along the appropriate axis | [interfaces/components/IBox.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L202) |
| <a id="marginprop"></a> `marginProp?` | `string` | Defines the margin area on all four sides of an element. It is a shorthand for "margin-top", "margin-right", "margin-bottom", and "margin-left" | [interfaces/components/IBox.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L210) |
| <a id="overflowprop"></a> `overflowProp?` | `string` | Specifies what to do when the element content is too big to fit in its block formatting context | [interfaces/components/IBox.ts:217](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L217) |
| <a id="textalign"></a> `textAlign?` | `string` | Defines the horizontal alignment of a block element or table-cell box | [interfaces/components/IBox.ts:224](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L224) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IBox.ts:232](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L232) |
| <a id="id"></a> `id?` | `string` | Unique identifier. | [interfaces/components/IBox.ts:239](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L239) |
| <a id="children"></a> `children?` | [`Component`](Component.md#component)[] | The child components to render within this box | [interfaces/components/IBox.ts:246](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L246) |

***

### Example

Flexible input container with gradient background

```typescript
const newInputProps: IInput = {
  value: "",
  onChange: () => {},
  scale: true,
  placeholder: "",
}

const inputComponent: InputGroup = {
  component: Components.input,
  props: newInputProps,
}

const inputBox: IBox = {
  widthProp: "100px",
  paddingProp: "10px",
  displayProp: "flex",
  flexDirection: "row",
  alignItems: "center",
  borderProp: {
    color: "blue",
    radius: "10px",
    style: "solid",
    width: "2px"
  },
  alignContent: "center",
  alignSelf: "center",
  backgroundProp: "linear-gradient(to right, #ff0000, #00ff00)",
  flexBasis: "50%",
  flexProp: "1",
  flexWrap: "wrap",
  children: inputComponent
}
```

## IBorderProp

Defined in: [interfaces/components/IBox.ts:267](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L267)

Defines the border properties for a box element.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="color"></a> `color` | `string` | Defines the border color of the element area | [interfaces/components/IBox.ts:269](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L269) |
| <a id="radius"></a> `radius` | `string` | Defines the border radius of the element area | [interfaces/components/IBox.ts:272](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L272) |
| <a id="style"></a> `style` | `string` | Defines the border style of the element area | [interfaces/components/IBox.ts:275](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L275) |
| <a id="width"></a> `width` | `string` | Defines the border width of the element area | [interfaces/components/IBox.ts:278](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L278) |
### Example

Border properties with custom styling

```typescript
const borderProps: IBorderProp = {
  color: "blue",
  radius: "10px",
  style: "solid",
  width: "2px"
}
```

