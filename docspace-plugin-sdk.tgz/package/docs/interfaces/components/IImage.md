---
toc_max_heading_level: 3
hide_title: true
---

# IImage

Defined in: [interfaces/components/IImage.ts:61](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L61)

A component that is used to embed an image not from the assets folder into a modal window or the settings page.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="src"></a> `src` | `string` | Defines the full path to the image | [interfaces/components/IImage.ts:66](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L66) |
| <a id="alt"></a> `alt` | `string` | Defines the image alt attribute | [interfaces/components/IImage.ts:72](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L72) |
| <a id="width"></a> `width?` | `string` | Defines the image width | [interfaces/components/IImage.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L78) |
| <a id="height"></a> `height?` | `string` | Defines the image height | [interfaces/components/IImage.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L84) |
| <a id="name"></a> `name?` | `string` | Defines the image name | [interfaces/components/IImage.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L90) |
| <a id="id"></a> `id?` | `string` | Defines the image ID | [interfaces/components/IImage.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L96) |
| <a id="style"></a> `style?` | \{ \[`key`: `string`\]: `string`; \} | Defines the image style | [interfaces/components/IImage.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L102) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IImage.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L110) |
### Examples

Plugin logo with fixed dimensions and spacing

```typescript
const pluginLogo: IImage = {
  src: "https://example.com/plugin-logo.png",
  alt: "Plugin Logo",
  width: "120px",
  height: "40px",
  name: "plugin-logo",
  id: "settings-logo",
  style: {
    objectFit: "contain",
    marginBottom: "16px"
  }
}
```

Responsive document preview with modern styling

```typescript
const documentPreview: IImage = {
  src: "https://example.com/document-preview.jpg",
  alt: "Document Preview",
  width: "100%",
  height: "auto",
  name: "doc-preview",
  style: {
    borderRadius: "4px",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    maxWidth: "800px"
  }
}
```

