---
toc_max_heading_level: 3
hide_title: true
---

# ICheckbox

Defined in: [interfaces/components/ICheckbox.ts:59](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L59)

Custom checkbox.

<img alt="checkbox" src="/assets/images/docspace/checkbox.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="ischecked"></a> `isChecked` | `boolean` | Sets the checked state of the checkbox | [interfaces/components/ICheckbox.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L65) |
| <a id="label"></a> `label?` | `string` | Defines the checkbox label | [interfaces/components/ICheckbox.ts:72](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L72) |
| <a id="onchange"></a> `onChange` | () => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the checkbox input is clicked | [interfaces/components/ICheckbox.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L79) |
| <a id="truncate"></a> `truncate?` | `boolean` | Specifies if the word wrapping is disabled or not | [interfaces/components/ICheckbox.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L86) |
| <a id="tabindex"></a> `tabIndex?` | `number` | Defines the checkbox tab index | [interfaces/components/ICheckbox.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L93) |
| <a id="haserror"></a> `hasError?` | `boolean` | Specifies whether a notification will be sent if an error occurs | [interfaces/components/ICheckbox.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L100) |
| <a id="name"></a> `name?` | `string` | Defines the HTML "name" property | [interfaces/components/ICheckbox.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L107) |
| <a id="value"></a> `value?` | `string` | Defines the checkbox input value | [interfaces/components/ICheckbox.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L114) |
| <a id="isindeterminate"></a> `isIndeterminate?` | `boolean` | Specifies whether the checkbox state will be displayed as a black rectangle in the checkbox when it is set to true | [interfaces/components/ICheckbox.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L121) |
| <a id="isdisabled"></a> `isDisabled?` | `boolean` | Specifies if the checkbox input is disabled | [interfaces/components/ICheckbox.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L128) |
| <a id="title"></a> `title?` | `string` | Defines the checkbox input title | [interfaces/components/ICheckbox.ts:135](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L135) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/ICheckbox.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L143) |
### Example

Privacy policy checkbox with submit button state control

```typescript
const privacyCheckbox: ICheckbox = {
  isChecked: false,
  label: "I agree to the Privacy Policy",
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.updateContext],
      newProps: {
        isChecked: !privacyCheckbox.isChecked
      },
      contextProps: [{
        name: "submitButton",
        props: {
          isDisabled: !privacyCheckbox.isChecked
        }
      }]
    };
  },
  truncate: false,
  tabIndex: 1,
  hasError: false,
  name: "privacy-policy",
  value: "accepted",
  isIndeterminate: false,
  isDisabled: false,
  title: "Privacy Policy Agreement"
}
```

