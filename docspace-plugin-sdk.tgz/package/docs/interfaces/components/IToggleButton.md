---
toc_max_heading_level: 3
hide_title: true
---

# IToggleButton

Defined in: [interfaces/components/IToggleButton.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L99)

Custom toggle button input for binary state controls.

<img alt="toggle-button" src="/assets/images/docspace/toggle-button.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="label"></a> `label?` | `string` | Defines the toggle button label | [interfaces/components/IToggleButton.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L104) |
| <a id="ischecked"></a> `isChecked` | `boolean` | Specifies whether the toggle button is enabled | [interfaces/components/IToggleButton.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L110) |
| <a id="onchange"></a> `onChange` | () => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the toggle button is clicked | [interfaces/components/IToggleButton.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L116) |
| <a id="isdisabled"></a> `isDisabled?` | `boolean` | Specifies whether the toggle button is disabled | [interfaces/components/IToggleButton.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L122) |
| <a id="style"></a> `style?` | `any` | Defines the toggle button CSS style | [interfaces/components/IToggleButton.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L128) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IToggleButton.ts:136](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L136) |
### Examples

Theme switcher with custom margin

```typescript
const darkModeToggle: IToggleButton = {
  label: "Dark Mode",
  isChecked: false,
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.updateTheme],
      newProps: {
        isChecked: true
      },
      theme: "dark"
    };
  },
  style: {
    marginLeft: "16px"
  }
}
```

Permission-aware notification settings

```typescript
const notificationsToggle: IToggleButton = {
  label: "Enable Notifications",
  isChecked: true,
  isDisabled: !hasNotificationPermission,
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.showToast],
      newProps: {
        isChecked: false
      },
      toastProps: [{
        type: "info",
        title: "Notifications disabled",
        timeout: 3000
      }]
    };
  }
}
```

Styled auto-save control with custom background

```typescript
const autoSaveToggle: IToggleButton = {
  label: "Auto-save",
  isChecked: true,
  onChange: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        isChecked: false
      }
    };
  },
  style: {
    backgroundColor: "#f5f5f5",
    padding: "8px",
    borderRadius: "4px"
  }
}
```

