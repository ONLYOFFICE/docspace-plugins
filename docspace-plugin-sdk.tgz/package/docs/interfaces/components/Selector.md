---
toc_max_heading_level: 2
hide_title: true
---

# TSelector

```ts
type TSelector = 
  | {
  type: Base;
  props: TBaseSelector;
}
  | {
  type: Files;
  props: TFilesSelector;
}
  | {
  type: Groups;
  props: TGroupsSelector;
}
  | {
  type: People;
  props: TPeopleSelector;
}
  | {
  type: Room;
  props: TRoomSelector;
};
```

Defined in: [interfaces/components/Selector/index.ts:50](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/index.ts#L50)

Provides selector components for choosing files, rooms, users, and groups within DocSpace.

Set `type` to the desired [SelectorType](../../enums/Selector.md#selectortype) value and `props` to the matching
selector props interface ([TBaseSelector](#tbaseselector), [TFilesSelector](#tfilesselector),
[TGroupsSelector](#tgroupsselector), [TPeopleSelector](#tpeopleselector), or [TRoomSelector](#troomselector)).

### Example

```typescript
import { TSelector, TBaseSelector, SelectorType, Actions, ToastType } from "@onlyoffice/docspace-plugin-sdk";

const selector: TSelector = {
  type: SelectorType.Base,
  props: {
    submitButtonLabel: "Select",
    items: [{ id: "item-1", label: "First Item" }],
    onSubmit: ({ selectedIds }) => ({
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{ type: ToastType.success, title: `Selected ${selectedIds.length} items` }],
    }),
  },
};
```
## TBaseSelector

```ts
type TBaseSelector = TSelectorBreadCrumbs & TSelectorPagination & TSelectorHeader & TSelectorCancelButton & TSelectorSubmitButton & TSelectorCheckbox & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorEmptyScreen & {
  isLoading?: boolean;
  isMultiSelect?: boolean;
  maxSelectedItems?: number;
  selectedItems?: TSelectorItem[];
  descriptionText?: string;
  searchEmptyScreenHeader?: string;
  searchEmptyScreenDescription?: string;
  onSelect?: (params: {
     selectedId?: string | number;
     isDoubleClick: boolean;
  }) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L101)

Defines the base properties for all selector components.

This type combines multiple selector-related types:

### Type Declaration

| Name | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| `isLoading?` | `boolean` | If true, shows a loading indicator for the entire selector. | [interfaces/components/Selector/IBaseSelector.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L116) |
| `isMultiSelect?` | `boolean` | If true, allows multiple items to be selected. | [interfaces/components/Selector/IBaseSelector.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L122) |
| `maxSelectedItems?` | `number` | The maximum number of items that can be selected. | [interfaces/components/Selector/IBaseSelector.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L128) |
| `selectedItems?` | [`TSelectorItem`](#tselectoritem)[] | An array of initially selected items. | [interfaces/components/Selector/IBaseSelector.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L134) |
| `descriptionText?` | `string` | A descriptive text displayed within the selector. | [interfaces/components/Selector/IBaseSelector.ts:140](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L140) |
| `searchEmptyScreenHeader?` | `string` | The header text to display when a search yields no results. | [interfaces/components/Selector/IBaseSelector.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L146) |
| `searchEmptyScreenDescription?` | `string` | The description text to display when a search yields no results. | [interfaces/components/Selector/IBaseSelector.ts:152](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L152) |
| `onSelect()?` | (`params`: \{ `selectedId?`: `string` \| `number`; `isDoubleClick`: `boolean`; \}) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when an item is selected. | [interfaces/components/Selector/IBaseSelector.ts:158](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L158) |

### See

 - [TSelectorBreadCrumbs](#tselectorbreadcrumbs) - Breadcrumb navigation properties
 - [TSelectorPagination](#tselectorpagination) - Pagination and item loading properties
 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties
 - [TSelectorCheckbox](#tselectorcheckbox) - Footer checkbox properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorEmptyScreen](#tselectoremptyscreen) - Empty state messages

### Example

```typescript
// This example demonstrates how to create a basic selector with a list of items,
// a header, and a submit button. It also includes an item that, when clicked,
// dynamically adds a new input item to the list.

const selectorProps: TBaseSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Plugin Base Selector",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Submit",

  // An array of items to display in the selector.
  items: [
    {
      id: "create-new",
      label: "Create new item",
      isCreateNewItem: true, // Renders this item as a button for creating new entries.
      onCreateClick: () => {
        // When clicked, this function returns a message to the host application
        // with an `updateSelector` action. This action provides new props to
        // re-render the selector, in this case, adding a new item to the list.
        const updatedItems = [...selectorProps.items, { id: "new-item", label: "Newly Added Item" }];

        return {
          actions: [Actions.updateSelector], // Specifies the action to perform.
          selectorProps: { // Provides the new properties for the selector.
             type: SelectorType.Base,
             props: { ...selectorProps, items: updatedItems }
          }
        };

      },
    },
    {
      id: "item-1",
      label: "First Item",
      icon: "your-icon-url.svg", // Specify an icon for the item.
    },
  ],

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: ({ selectedIds }) => {
    // The `selectedIds` parameter contains an array of the IDs of the selected items.
    console.log("Items submitted:", selectedIds);

    // After submission, you can perform actions like closing the selector
    // and showing a success message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `Selected ${selectedIds.length} items`,
      }],
    };
  },
};
```

***

## TSelectorItem

```ts
type TSelectorItem = {
  label: string;
  id?: string | number;
} & Partial<TSelectorItemFile> & Partial<TSelectorItemInput> & Partial<TSelectorItemNew>;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L169)

Represents a single item within a selector component.

### Type Declaration

| Name | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| `label` | `string` | The display text for the item. | [interfaces/components/Selector/IBaseSelector.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L174) |
| `id?` | `string` \| `number` | A unique identifier for the item. | [interfaces/components/Selector/IBaseSelector.ts:179](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L179) |

### See

 - [TSelectorItemFile](#tselectoritemfile) - File item properties
 - [TSelectorItemInput](#tselectoriteminput) - Input item properties
 - [TSelectorItemNew](#tselectoritemnew) - New item properties

***

## TSelectorItemFile

```ts
type TSelectorItemFile = {
  icon: string;
  fileExst: FilesExst | string;
  fileType: FilesType;
  security: FilesSecurity;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L187)

Defines properties for an item that represents a file.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="icon"></a> `icon` | `string` | The URL or identifier for the item's icon. | [interfaces/components/Selector/IBaseSelector.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L192) |
| <a id="fileexst"></a> `fileExst` | [`FilesExst`](../../enums/Files.md#filesexst) \| `string` | The file extension (e.g., 'docx', 'pdf'). | [interfaces/components/Selector/IBaseSelector.ts:197](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L197) |
| <a id="filetype"></a> `fileType` | [`FilesType`](../../enums/Files.md#filestype) | The general type of the file (e.g., 'text', 'spreadsheet'). | [interfaces/components/Selector/IBaseSelector.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L202) |
| <a id="security"></a> `security` | [`FilesSecurity`](../../enums/Files.md#filessecurity) | The security or access level of the file. | [interfaces/components/Selector/IBaseSelector.ts:207](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L207) |

***

## TSelectorItemInput

```ts
type TSelectorItemInput = {
  isInputItem: boolean;
  defaultInputValue: string;
  onAcceptInput: (value: string) => TReturnMessage;
  onCancelInput: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L213)

Defines properties for an item that functions as an input field.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="isinputitem"></a> `isInputItem` | `boolean` | If true, this item will be rendered as an input field. | [interfaces/components/Selector/IBaseSelector.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L219) |
| <a id="defaultinputvalue"></a> `defaultInputValue` | `string` | The default value to display in the input field. | [interfaces/components/Selector/IBaseSelector.ts:224](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L224) |
| <a id="onacceptinput"></a> `onAcceptInput` | (`value`: `string`) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the user accepts the input value. | [interfaces/components/Selector/IBaseSelector.ts:229](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L229) |
| <a id="oncancelinput"></a> `onCancelInput` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the user cancels the input. | [interfaces/components/Selector/IBaseSelector.ts:234](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L234) |

***

## TSelectorItemNew

```ts
type TSelectorItemNew = {
  isCreateNewItem: boolean;
  onCreateClick: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:240](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L240)

Defines properties for an item that allows creating a new entity.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="iscreatenewitem"></a> `isCreateNewItem` | `boolean` | If true, this item will be rendered as a 'create new' button. | [interfaces/components/Selector/IBaseSelector.ts:245](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L245) |
| <a id="oncreateclick"></a> `onCreateClick` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the user clicks the 'create new' button. | [interfaces/components/Selector/IBaseSelector.ts:250](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L250) |

***

## TBreadCrumbItem

```ts
type TBreadCrumbItem = {
  label: string;
  id: string | number;
  isRoom?: boolean;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:257](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L257)

Represents a single item in a breadcrumb trail.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="label"></a> `label` | `string` | The display text for the breadcrumb item. | [interfaces/components/Selector/IBaseSelector.ts:262](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L262) |
| <a id="id"></a> `id` | `string` \| `number` | A unique identifier for the breadcrumb item. | [interfaces/components/Selector/IBaseSelector.ts:268](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L268) |
| <a id="isroom"></a> `isRoom?` | `boolean` | If true, indicates that the breadcrumb item represents a room. | [interfaces/components/Selector/IBaseSelector.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L274) |

***

## TSelectorBreadCrumbs

```ts
type TSelectorBreadCrumbs = {
  withBreadCrumbs?: boolean;
  isBreadCrumbsLoading?: boolean;
  breadCrumbs?: TBreadCrumbItem[];
  onSelectBreadCrumb?: (id: string | number) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:293](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L293)

Defines properties for configuring breadcrumbs in a selector.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="withbreadcrumbs"></a> `withBreadCrumbs?` | `boolean` | If true, displays the breadcrumb navigation. | [interfaces/components/Selector/IBaseSelector.ts:298](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L298) |
| <a id="isbreadcrumbsloading"></a> `isBreadCrumbsLoading?` | `boolean` | If true, shows a loading indicator for the breadcrumbs. | [interfaces/components/Selector/IBaseSelector.ts:303](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L303) |
| <a id="breadcrumbs"></a> `breadCrumbs?` | [`TBreadCrumbItem`](#tbreadcrumbitem)[] | An array of breadcrumb items to display. | [interfaces/components/Selector/IBaseSelector.ts:308](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L308) |
| <a id="onselectbreadcrumb"></a> `onSelectBreadCrumb?` | (`id`: `string` \| `number`) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when a breadcrumb item is selected. | [interfaces/components/Selector/IBaseSelector.ts:313](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L313) |

***

## TSelectorPagination

```ts
type TSelectorPagination = {
  items: TSelectorItem[];
  hasNextPage?: boolean;
  isNextPageLoading?: boolean;
  onLoadNextPage?: () => TReturnMessage;
  totalItems?: number;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:320](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L320)

Defines properties for pagination within a selector.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="items"></a> `items` | [`TSelectorItem`](#tselectoritem)[] | The list of items to display on the current page. | [interfaces/components/Selector/IBaseSelector.ts:325](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L325) |
| <a id="hasnextpage"></a> `hasNextPage?` | `boolean` | If true, indicates that more items are available on subsequent pages. | [interfaces/components/Selector/IBaseSelector.ts:330](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L330) |
| <a id="isnextpageloading"></a> `isNextPageLoading?` | `boolean` | If true, shows a loading indicator while the next page is being loaded. | [interfaces/components/Selector/IBaseSelector.ts:335](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L335) |
| <a id="onloadnextpage"></a> `onLoadNextPage?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered to load the next page of items. | [interfaces/components/Selector/IBaseSelector.ts:340](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L340) |
| <a id="totalitems"></a> `totalItems?` | `number` | The total number of items available. | [interfaces/components/Selector/IBaseSelector.ts:345](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L345) |

***

## TSelectorHeader

```ts
type TSelectorHeader = {
  withHeader?: boolean;
  headerProps?: {
     label: string;
     isCloseable?: boolean;
     onCloseClick?: () => TReturnMessage;
     withBackButton?: boolean;
     onBackClick?: () => TReturnMessage;
  };
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:352](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L352)

Defines properties for the selector's header.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="withheader"></a> `withHeader?` | `boolean` | If true, displays the header. | [interfaces/components/Selector/IBaseSelector.ts:357](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L357) |
| <a id="headerprops"></a> `headerProps?` | \{ `label`: `string`; `isCloseable?`: `boolean`; `onCloseClick?`: () => [`TReturnMessage`](../utils.md#treturnmessage); `withBackButton?`: `boolean`; `onBackClick?`: () => [`TReturnMessage`](../utils.md#treturnmessage); \} | An object containing properties for the header. | [interfaces/components/Selector/IBaseSelector.ts:362](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L362) |
| `headerProps.label` | `string` | The title text to display in the header. | [interfaces/components/Selector/IBaseSelector.ts:367](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L367) |
| `headerProps.isCloseable?` | `boolean` | If true, displays a close button in the header. | [interfaces/components/Selector/IBaseSelector.ts:372](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L372) |
| `headerProps.onCloseClick?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the close button is clicked. | [interfaces/components/Selector/IBaseSelector.ts:377](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L377) |
| `headerProps.withBackButton?` | `boolean` | If true, displays a back button in the header. | [interfaces/components/Selector/IBaseSelector.ts:382](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L382) |
| `headerProps.onBackClick?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the back button is clicked. | [interfaces/components/Selector/IBaseSelector.ts:387](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L387) |

***

## TSelectorCheckbox

```ts
type TSelectorCheckbox = {
  withCheckbox?: boolean;
  footerCheckboxLabel?: string;
  isChecked?: boolean;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:395](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L395)

Defines properties for a checkbox in the selector's footer.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="withcheckbox"></a> `withCheckbox?` | `boolean` | If true, displays a checkbox in the footer. | [interfaces/components/Selector/IBaseSelector.ts:400](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L400) |
| <a id="footercheckboxlabel"></a> `footerCheckboxLabel?` | `string` | The label for the footer checkbox. | [interfaces/components/Selector/IBaseSelector.ts:405](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L405) |
| <a id="ischecked"></a> `isChecked?` | `boolean` | The initial checked state of the footer checkbox. | [interfaces/components/Selector/IBaseSelector.ts:410](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L410) |

***

## TSelectorCancelButton

```ts
type TSelectorCancelButton = {
  withCancelButton?: boolean;
  cancelButtonLabel?: string;
  onCancel?: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:417](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L417)

Defines properties for the cancel button in the selector.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="withcancelbutton"></a> `withCancelButton?` | `boolean` | If true, displays the cancel button. | [interfaces/components/Selector/IBaseSelector.ts:423](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L423) |
| <a id="cancelbuttonlabel"></a> `cancelButtonLabel?` | `string` | The text label for the cancel button. | [interfaces/components/Selector/IBaseSelector.ts:429](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L429) |
| <a id="oncancel"></a> `onCancel?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the cancel button is clicked. | [interfaces/components/Selector/IBaseSelector.ts:434](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L434) |

***

## TSelectorBaseProps

```ts
type TSelectorBaseProps = {
  id?: string;
  className?: string;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:441](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L441)

Common base properties shared across all selector types.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="id-1"></a> `id?` | `string` | A unique identifier for the selector component. | [interfaces/components/Selector/IBaseSelector.ts:446](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L446) |
| <a id="classname"></a> `className?` | `string` | A CSS class name to apply to the selector component. | [interfaces/components/Selector/IBaseSelector.ts:451](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L451) |

***

## TSelectorLifecycleEvents

```ts
type TSelectorLifecycleEvents = {
  onLoad?: () => TReturnMessage;
  onClose?: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:458](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L458)

Lifecycle callback properties for selectors.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="onload"></a> `onLoad?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the selector is loaded. | [interfaces/components/Selector/IBaseSelector.ts:463](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L463) |
| <a id="onclose"></a> `onClose?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the selector is closed. | [interfaces/components/Selector/IBaseSelector.ts:468](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L468) |

***

## TSelectorEmptyScreen

```ts
type TSelectorEmptyScreen = {
  emptyScreenHeader?: string;
  emptyScreenDescription?: string;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:475](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L475)

Empty screen message properties for selectors.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="emptyscreenheader"></a> `emptyScreenHeader?` | `string` | The header text to display when there are no items to show. | [interfaces/components/Selector/IBaseSelector.ts:480](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L480) |
| <a id="emptyscreendescription"></a> `emptyScreenDescription?` | `string` | The description text to display when there are no items to show. | [interfaces/components/Selector/IBaseSelector.ts:485](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L485) |

***

## TSelectorSearchCreate

```ts
type TSelectorSearchCreate = {
  withSearch?: boolean;
  withCreate?: boolean;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:492](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L492)

Search and create functionality properties for selectors.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="withsearch"></a> `withSearch?` | `boolean` | If true, displays a search input field. | [interfaces/components/Selector/IBaseSelector.ts:497](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L497) |
| <a id="withcreate"></a> `withCreate?` | `boolean` | If true, allows users to create new items. | [interfaces/components/Selector/IBaseSelector.ts:502](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L502) |

***

## TSelectorSubmitButton

```ts
type TSelectorSubmitButton = {
  submitButtonLabel: string;
  disabledSubmitButton?: boolean;
  onSubmit: (params: {
     selectedIds: (string | number)[];
     fileName: string;
     isFooterCheckboxChecked: boolean;
  }) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:531](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L531)

Defines properties for the submit button in the selector.

#### TOnSubmitParams parameters

| Property | Type | Description |
|----------|------|-------------|
| `selectedIds` | `(string \| number)[]` | An array of IDs of the selected items. |
| `fileName` | `"string"` | The name of the file, if applicable. |
| `isFooterCheckboxChecked` | `"boolean"` | The checked state of the footer checkbox. |

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="submitbuttonlabel"></a> `submitButtonLabel` | `string` | The text label for the submit button. | [interfaces/components/Selector/IBaseSelector.ts:536](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L536) |
| <a id="disabledsubmitbutton"></a> `disabledSubmitButton?` | `boolean` | If true, the submit button will be disabled. | [interfaces/components/Selector/IBaseSelector.ts:541](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L541) |
| <a id="onsubmit"></a> `onSubmit` | (`params`: \{ `selectedIds`: (`string` \| `number`)[]; `fileName`: `string`; `isFooterCheckboxChecked`: `boolean`; \}) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the submit button is clicked. | [interfaces/components/Selector/IBaseSelector.ts:546](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L546) |

***

## TFilesSelector

```ts
type TFilesSelector = TSelectorHeader & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorSearchCreate & TSelectorCancelButton & Pick<TSelectorSubmitButton, "submitButtonLabel"> & {
  isMultiSelect?: boolean;
  withBreadCrumbs?: boolean;
  currentFolderId?: string | number;
  isRoomsOnly?: boolean;
  openRoot?: boolean;
  descriptionText?: string;
  withFooterInput?: boolean;
  footerInputHeader?: string;
  currentFooterInputValue?: string;
  withFooterCheckbox?: boolean;
  footerCheckboxLabel?: string;
  filterParam?: FilterType;
  getIsDisabled: (params: {
     selectedItemId: string | number | undefined;
     selectedItemType?: "rooms" | "files";
     selectedItemSecurity?:   | FilesSecurity
        | Security;
     selectedFileInfo:   | {
        id: string | number;
        title: string;
        fileExst?: FilesExst | string;
      }
        | null;
     isFirstLoad: boolean;
     isDisabledFolder?: boolean;
     isRoot: boolean;
  }) => boolean;
  onSubmit?: (params: {
     selectedItemId: string | number | undefined;
     folderTitle: string;
     fileName: string;
     isChecked: boolean;
     selectedFileInfo:   | {
        id: string | number;
        title: string;
        fileExst?: FilesExst | string;
      }
        | null;
     breadCrumbs?: TBreadCrumbItem[];
  }) => TReturnMessage;
  onSelect?: (id: string | number | undefined) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IFilesSelector.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L108)

Defines the properties for a file and folder selector component.

This type combines multiple selector-related types:

#### TSelectedFileInfo

| Property | Type | Description |
|----------|------|-------------|
| `id` | `string \| number` | The unique identifier of the file |
| `title` | `string` | The title or name of the file |
| `fileExst` | `FilesExst \| string` | The file extension (e.g., 'docx', 'pdf') |

### Type Declaration

| Name | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| `isMultiSelect?` | `boolean` | If true, allows multiple items to be selected. | [interfaces/components/Selector/IFilesSelector.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L115) |
| `withBreadCrumbs?` | `boolean` | If true, displays breadcrumb navigation. | [interfaces/components/Selector/IFilesSelector.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L117) |
| `currentFolderId?` | `string` \| `number` | The ID of the folder to open by default. | [interfaces/components/Selector/IFilesSelector.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L119) |
| `isRoomsOnly?` | `boolean` | If true, displays only rooms at the root level. | [interfaces/components/Selector/IFilesSelector.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L121) |
| `openRoot?` | `boolean` | If true, opens the root directory by default. | [interfaces/components/Selector/IFilesSelector.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L123) |
| `descriptionText?` | `string` | A descriptive text displayed within the selector. | [interfaces/components/Selector/IFilesSelector.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L125) |
| `withFooterInput?` | `boolean` | If true, displays an input field in the footer. | [interfaces/components/Selector/IFilesSelector.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L127) |
| `footerInputHeader?` | `string` | The header text for the footer input. | [interfaces/components/Selector/IFilesSelector.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L129) |
| `currentFooterInputValue?` | `string` | The initial value for the footer input. | [interfaces/components/Selector/IFilesSelector.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L131) |
| `withFooterCheckbox?` | `boolean` | If true, displays a checkbox in the footer. | [interfaces/components/Selector/IFilesSelector.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L133) |
| `footerCheckboxLabel?` | `string` | The label for the footer checkbox. | [interfaces/components/Selector/IFilesSelector.ts:135](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L135) |
| `filterParam?` | [`FilterType`](../../enums/Utility.md#filtertype) | File type filter. | [interfaces/components/Selector/IFilesSelector.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L137) |
| `getIsDisabled()` | (`params`: \{ `selectedItemId`: `string` \| `number` \| `undefined`; `selectedItemType?`: `"rooms"` \| `"files"`; `selectedItemSecurity?`: \| [`FilesSecurity`](../../enums/Files.md#filessecurity) \| [`Security`](../../enums/Security.md#security); `selectedFileInfo`: \| \{ `id`: `string` \| `number`; `title`: `string`; `fileExst?`: [`FilesExst`](../../enums/Files.md#filesexst) \| `string`; \} \| `null`; `isFirstLoad`: `boolean`; `isDisabledFolder?`: `boolean`; `isRoot`: `boolean`; \}) => `boolean` | A callback function to determine if the submit button should be disabled. | [interfaces/components/Selector/IFilesSelector.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L139) |
| `onSubmit()?` | (`params`: \{ `selectedItemId`: `string` \| `number` \| `undefined`; `folderTitle`: `string`; `fileName`: `string`; `isChecked`: `boolean`; `selectedFileInfo`: \| \{ `id`: `string` \| `number`; `title`: `string`; `fileExst?`: [`FilesExst`](../../enums/Files.md#filesexst) \| `string`; \} \| `null`; `breadCrumbs?`: [`TBreadCrumbItem`](#tbreadcrumbitem)[]; \}) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the submit button is clicked. | [interfaces/components/Selector/IFilesSelector.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L141) |
| `onSelect()?` | (`id`: `string` \| `number` \| `undefined`) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when an item is selected. | [interfaces/components/Selector/IFilesSelector.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L143) |

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorSearchCreate](#tselectorsearchcreate) - Search and create functionality
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties (partial)

### Example

```typescript
// This example demonstrates a file selector for choosing a location to save a file.
// It includes a footer input for the filename, breadcrumbs for navigation, and
// custom logic to disable the submit button in the root directory.

const filesSelectorProps: TFilesSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Save File As",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Save",
  // Enables and sets the text for the cancel button.
  withCancelButton: true,
  cancelButtonLabel: "Cancel",

  // Enables breadcrumbs for easy navigation through folders.
  withBreadCrumbs: true,
  // Enables the search functionality.
  withSearch: true,
  // Allows users to create new folders within the selector.
  withCreate: true,

  // Adds an input field in the footer, typically for a filename.
  withFooterInput: true,
  footerInputHeader: "File name",
  currentFooterInputValue: "Untitled Document",

  // A callback function to determine if the submit button should be disabled.
  getIsDisabled: ({ isRoot }) => {
    // In this case, disable the submit button if the user is in the root directory.
    return isRoot;
  },

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains information about the selected location and filename.
    console.log("File save details:", payload);

    // After submission, close the selector and show a confirmation message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `File saved as ${payload.fileName}`,
      }],
    };
  },
};
```

***

## TGroupsSelector

```ts
type TGroupsSelector = TSelectorHeader & TSelectorBaseProps & TSelectorLifecycleEvents & {
  onSubmit: (params: {
     selectedIds: (string | number)[];
     fileName?: string;
     isFooterCheckboxChecked?: boolean;
  }) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IGroupsSelector.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IGroupsSelector.ts#L69)

Defines the properties for a group selector component.

This type combines multiple selector-related types:

#### onSubmit parameters

| Property | Type | Description |
|----------|------|-------------|
| `selectedIds` | `(string \| number)[]` | An array of IDs of the selected groups |
| `fileName` | `string` | The name of the file, if applicable |
| `isFooterCheckboxChecked` | `boolean` | The checked state of the footer checkbox |

### Type Declaration

| Name | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| `onSubmit()` | (`params`: \{ `selectedIds`: (`string` \| `number`)[]; `fileName?`: `string`; `isFooterCheckboxChecked?`: `boolean`; \}) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the submit button is clicked. | [interfaces/components/Selector/IGroupsSelector.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IGroupsSelector.ts#L77) |

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)

### Example

```typescript
// This example shows how to set up a group selector with a custom header and submit logic.

const groupsSelectorProps: TGroupsSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Select Groups",
  },

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains the `selectedIds` of the chosen groups.
    console.log("Selected groups:", payload.selectedIds);

    // After submission, close the selector and display a toast notification.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Groups selected successfully",
      }],
    };
  },
};
```

***

## TPeopleSelector

```ts
type TPeopleSelector = TSelectorHeader & TSelectorCancelButton & TSelectorSubmitButton & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorEmptyScreen & {
  targetEntityType?: "file" | "folder" | "room";
  withGroups?: boolean;
  isGroupsOnly?: boolean;
  withGuests?: boolean;
  isGuestsOnly?: boolean;
  isMultiSelect?: boolean;
  currentUserId?: string;
  excludeItems?: string[];
  disableInvitedUsers?: string[];
  disableDisabledUsers?: boolean;
  roomId?: string | number;
  alwaysShowFooter?: boolean;
  onlyRoomMembers?: boolean;
};
```

Defined in: [interfaces/components/Selector/IPeopleSelector.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L90)

Defines the properties for a user and group selector component.

This type combines multiple selector-related types:

### Type Declaration

| Name | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| `targetEntityType?` | `"file"` \| `"folder"` \| `"room"` | The type of entity for which the user is being selected (e.g., for sharing a file). **Example** `"file" | "folder" | "room"` | [interfaces/components/Selector/IPeopleSelector.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L102) |
| `withGroups?` | `boolean` | If true, allows the selection of groups. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L109) |
| `isGroupsOnly?` | `boolean` | If true, displays only groups in the selector. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L116) |
| `withGuests?` | `boolean` | If true, includes guest users in the selector. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L123) |
| `isGuestsOnly?` | `boolean` | If true, displays only guest users in the selector. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:130](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L130) |
| `isMultiSelect?` | `boolean` | If true, allows multiple users and/or groups to be selected. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L137) |
| `currentUserId?` | `string` | The ID of the current user, to be excluded from the list. **Example** `"user-1234"` | [interfaces/components/Selector/IPeopleSelector.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L144) |
| `excludeItems?` | `string`[] | An array of user or group IDs to exclude from the list. **Example** `["user-1234", "group-5678"]` | [interfaces/components/Selector/IPeopleSelector.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L151) |
| `disableInvitedUsers?` | `string`[] | An array of user IDs that are already invited and should be disabled. **Example** `["user-1234", "user-5678"]` | [interfaces/components/Selector/IPeopleSelector.ts:158](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L158) |
| `disableDisabledUsers?` | `boolean` | If true, users with a 'disabled' status will not be displayed. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:165](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L165) |
| `roomId?` | `string` \| `number` | The ID of the room to which the selector is related. **Example** `"room-1234"` | [interfaces/components/Selector/IPeopleSelector.ts:172](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L172) |
| `alwaysShowFooter?` | `boolean` | If true, the footer will always be visible, even if no users are selected. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L180) |
| `onlyRoomMembers?` | `boolean` | If true, displays only the members of the current room. **Default** `false` | [interfaces/components/Selector/IPeopleSelector.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L187) |

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorEmptyScreen](#tselectoremptyscreen) - Empty state messages

### Example

```typescript
// This example demonstrates how to configure a selector for choosing users and groups.
// It allows multi-selection, includes groups, and provides clear labels and descriptions.

const peopleSelectorProps: TPeopleSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Share Document",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Share",
  // The text for the cancel button.
  cancelButtonLabel: "Cancel",

  // If true, the footer with action buttons is always visible.
  alwaysShowFooter: true,

  // Custom text to display when no users or groups are found.
  emptyScreenHeader: "No users found",
  emptyScreenDescription: "There are no users or groups matching your search.",

  // Allows the selection of multiple users and groups.
  isMultiSelect: true,
  // Includes groups in the selection list.
  withGroups: true,

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains the `selectedIds` of the chosen users and groups.
    console.log("Selected users and groups:", payload.selectedIds);

    // After submission, close the selector and show a confirmation toast.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Document shared successfully",
      }],
    };
  },
};
```

***

## TRoomSelector

```ts
type TRoomSelector = TSelectorHeader & TSelectorCancelButton & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorEmptyScreen & TSelectorSearchCreate & Pick<TSelectorSubmitButton, "submitButtonLabel"> & {
  isMultiSelect?: boolean;
  roomType?:   | RoomsType
     | RoomsType[];
  searchArea?: RoomSearchArea;
  excludeItems?: (number | string | undefined)[];
  createDefineRoomLabel?: string;
  createDefineRoomType?: RoomsType;
  onSubmit?: (selectedIds: (string | number)[]) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IRoomSelector.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L99)

Defines the properties for a room selector component.

This type combines multiple selector-related types:

### Type Declaration

| Name | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| `isMultiSelect?` | `boolean` | If true, allows multiple rooms to be selected. | [interfaces/components/Selector/IRoomSelector.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L109) |
| `roomType?` | \| [`RoomsType`](../../enums/Rooms.md#roomstype) \| [`RoomsType`](../../enums/Rooms.md#roomstype)[] | The type of rooms to display (e.g., 'collaboration', 'custom'). Can be a single type or an array of types. | [interfaces/components/Selector/IRoomSelector.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L113) |
| `searchArea?` | [`RoomSearchArea`](../../enums/Rooms.md#roomsearcharea) | The area to search for rooms within (e.g., 'myRooms', 'allRooms'). | [interfaces/components/Selector/IRoomSelector.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L117) |
| `excludeItems?` | (`number` \| `string` \| `undefined`)[] | An array of room IDs to exclude from the list. | [interfaces/components/Selector/IRoomSelector.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L121) |
| `createDefineRoomLabel?` | `string` | The label for the 'create new room' option. | [interfaces/components/Selector/IRoomSelector.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L125) |
| `createDefineRoomType?` | [`RoomsType`](../../enums/Rooms.md#roomstype) | The default type for newly created rooms. | [interfaces/components/Selector/IRoomSelector.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L129) |
| `onSubmit()?` | (`selectedIds`: (`string` \| `number`)[]) => [`TReturnMessage`](../utils.md#treturnmessage) | A callback function that is triggered when the submit button is clicked. | [interfaces/components/Selector/IRoomSelector.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L133) |

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorEmptyScreen](#tselectoremptyscreen) - Empty state messages
 - [TSelectorSearchCreate](#tselectorsearchcreate) - Search and create functionality
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties (partial)

### Example

```typescript
// This example demonstrates how to create a room selector that allows users to
// select multiple public or custom rooms. It includes search and create functionalities.

const roomSelectorProps: TRoomSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Select a Room",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Open Rooms",
  // Enables and sets the text for the cancel button.
  withCancelButton: true,
  cancelButtonLabel: "Close",

  // Custom text to display when no rooms are found.
  emptyScreenHeader: "No Rooms Available",
  emptyScreenDescription: "You can create a new room or try a different search.",

  // Allows the selection of multiple rooms.
  isMultiSelect: true,
  // Filters the list to show only public and custom rooms.
  roomType: [RoomsType.PublicRoom, RoomsType.CustomRoom],
  // Sets the search scope to active rooms.
  searchArea: RoomSearchArea.Active,

  // Enables the search bar and the create room button.
  withCreate: true,
  withSearch: true,
  // Label for the create room button.
  createDefineRoomLabel: "Create a new collaboration room",
  // Default type for a newly created room.
  createDefineRoomType: RoomsType.Collaboration,

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (selectedIds) => {
    // The `selectedIds` parameter is an array of the selected room IDs.
    console.log("Selected rooms:", selectedIds);

    // After submission, close the selector and show a success message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `${selectedIds.length} rooms selected`,
      }],
    };
  },
};
```

***

