---
toc_max_heading_level: 3
hide_title: true
---

# IInput

Defined in: [interfaces/components/IInput.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L91)

Input field for single-line strings.

<img alt="input" src="/assets/images/docspace/input.png" />

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="value"></a> `value` | `string` | Defines the input value. | [interfaces/components/IInput.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L97) |
| <a id="onchange"></a> `onChange` | (`value`: `string`) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the input value is changed. It is required when the input is not read-only. The changed input value is passed to the function, which passes it back in the "value" parameter. | [interfaces/components/IInput.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L106) |
| <a id="name"></a> `name?` | `string` | Defines the input HTML "name" property. | [interfaces/components/IInput.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L113) |
| <a id="placeholder"></a> `placeholder?` | `string` | Defines the input placeholder text. | [interfaces/components/IInput.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L120) |
| <a id="maxlength"></a> `maxLength?` | `string` | Defines the default maximum length of the input value. | [interfaces/components/IInput.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L127) |
| <a id="size"></a> `size?` | [`InputSize`](#inputsize) | Defines the input size. | [interfaces/components/IInput.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L134) |
| <a id="isautofocused"></a> `isAutoFocused?` | `boolean` | Specifies whether to focus the input field when initially rendered. | [interfaces/components/IInput.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L141) |
| <a id="isreadonly"></a> `isReadOnly?` | `boolean` | Specifies whether the input field displays the read-only content. | [interfaces/components/IInput.ts:148](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L148) |
| <a id="haserror"></a> `hasError?` | `boolean` | Specifies whether to indicate that there is an error in the input field. | [interfaces/components/IInput.ts:155](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L155) |
| <a id="haswarning"></a> `hasWarning?` | `boolean` | Specifies whether to indicate that there is a warning in the input field. | [interfaces/components/IInput.ts:162](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L162) |
| <a id="scale"></a> `scale?` | `boolean` | Specifies if the input field is scaled or not. | [interfaces/components/IInput.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L169) |
| <a id="autocomplete"></a> `autoComplete?` | [`InputAutocomplete`](#inputautocomplete) | Defines the input HTML "autocomplete" property. | [interfaces/components/IInput.ts:176](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L176) |
| <a id="tabindex"></a> `tabIndex?` | `number` | Defines the input HTML "tabindex" property. | [interfaces/components/IInput.ts:183](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L183) |
| <a id="mask"></a> `mask?` | \[\] | Defines the input text mask. | [interfaces/components/IInput.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L190) |
| <a id="isdisabled"></a> `isDisabled?` | `boolean` | Specifies that the field cannot be used (e.g the user is not authorized, or the changes are not saved). | [interfaces/components/IInput.ts:197](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L197) |
| <a id="type"></a> `type?` | [`InputType`](#inputtype) | The input field type. | [interfaces/components/IInput.ts:204](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L204) |
| <a id="keepcharpositions"></a> `keepCharPositions?` | `boolean` | Specifies whether the characters are allowed to be added or deleted without changing the positions of the existing characters. | [interfaces/components/IInput.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L211) |
| <a id="onblur"></a> `onBlur?` | (`value`: `string`) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the input field is blurred. | [interfaces/components/IInput.ts:218](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L218) |
| <a id="onfocus"></a> `onFocus?` | (`value`: `string`) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the input field is focused. | [interfaces/components/IInput.ts:225](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L225) |
| <a id="children"></a> `children?` | `Node` \| `Node`[] | Defines the input field components. | [interfaces/components/IInput.ts:232](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L232) |
| <a id="iconsize"></a> `iconSize?` | `number` | Defines the input icon size. | [interfaces/components/IInput.ts:239](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L239) |
| <a id="iconname"></a> `iconName?` | `string` | Defines the path to the input icon. | [interfaces/components/IInput.ts:246](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L246) |
| <a id="isiconfill"></a> `isIconFill?` | `boolean` | Specifies if the icon fill is needed or not. | [interfaces/components/IInput.ts:253](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L253) |
| <a id="iconcolor"></a> `iconColor?` | `string` | Defines the input icon color. | [interfaces/components/IInput.ts:260](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L260) |
| <a id="hovercolor"></a> `hoverColor?` | `string` | Defines the icon color on hover action. | [interfaces/components/IInput.ts:267](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L267) |
| <a id="iconbuttonclassname"></a> `iconButtonClassName?` | `string` | Defines the class name of the icon button. | [interfaces/components/IInput.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L274) |
| <a id="oniconclick"></a> `onIconClick?` | () => `void` | Sets a function which is triggered whenever the input icon is clicked. | [interfaces/components/IInput.ts:281](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L281) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IInput.ts:289](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L289) |
### Examples

Search input with icon and hover effects

```typescript
const searchInput: IInput = {
  value: "",
  onChange: (value) => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        value
      }
    };
  },
  placeholder: "Search documents...",
  size: InputSize.middle,
  iconName: "search",
  iconSize: 16,
  iconColor: "#666666",
  hoverColor: "#333333",
  isIconFill: true,
}
```

Password input with validation and error handling

```typescript
const passwordInput: IInput = {
  value: "",
  type: InputType.password,
  onChange: (value) => {
    const hasError = value.length < 8;
    return {
      actions: [Actions.updateProps],
      newProps: {
        value,
        hasError
      }
    };
  },
  onBlur: (value) => {
    if (value.length < 8) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Validation Error",
          type: "error",
          message: "Password must be at least 8 characters long"
        }]
      };
    }
  },
  placeholder: "Enter password",
  name: "password",
  autoComplete: InputAutocomplete.off,
  size: InputSize.big,
  isAutoFocused: true,
  hasError: false,
  maxLength: "32"
}
```

## InputSize

Defined in: [interfaces/components/IInput.ts:297](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L297)

The supported input sizes.

### Enumeration Members

#### base

```ts
base: "base";
```

Defined in: [interfaces/components/IInput.ts:301](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L301)

Base size of the input field.

#### middle

```ts
middle: "middle";
```

Defined in: [interfaces/components/IInput.ts:305](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L305)

Middle size of the input field.

#### big

```ts
big: "big";
```

Defined in: [interfaces/components/IInput.ts:309](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L309)

Big size of the input field.

#### huge

```ts
huge: "huge";
```

Defined in: [interfaces/components/IInput.ts:313](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L313)

Huge size of the input field.

#### large

```ts
large: "large";
```

Defined in: [interfaces/components/IInput.ts:317](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L317)

Large size of the input field.

***

## InputAutocomplete

Defined in: [interfaces/components/IInput.ts:325](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L325)

The input autocomplete feature.

### Enumeration Members

#### on

```ts
on: "on";
```

Defined in: [interfaces/components/IInput.ts:329](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L329)

Autocomplete is enabled.

#### off

```ts
off: "off";
```

Defined in: [interfaces/components/IInput.ts:333](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L333)

Autocomplete is disabled.

***

## InputType

Defined in: [interfaces/components/IInput.ts:341](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L341)

The supported input types.

### Enumeration Members

#### text

```ts
text: "text";
```

Defined in: [interfaces/components/IInput.ts:345](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L345)

Text input type.

#### password

```ts
password: "password";
```

Defined in: [interfaces/components/IInput.ts:349](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L349)

Password input type.

***

