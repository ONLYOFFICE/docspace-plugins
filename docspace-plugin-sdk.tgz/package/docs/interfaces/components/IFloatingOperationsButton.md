---
toc_max_heading_level: 3
hide_title: true
---

# IFloatingOperationsButton

Defined in: [interfaces/components/IFloatingOperationsButton.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L166)

Configuration for the floating operations button.
Used to display progress of long-running operations (upload, conversion, backup, etc.)
The button appears as a floating action button in the bottom-right corner of DocSpace.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="id"></a> `id` | `string` | Unique identifier for floating operations. Used to track and update operations from the same plugin. When Actions.addFloatingOperationsButton is called again with the same identifier, operations in the button will not be replaced as long as there are operations in the button. Use Actions.updateFloatingOperationsButton to update the state. | [interfaces/components/IFloatingOperationsButton.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L174) |
| <a id="operations"></a> `operations?` | [`IFloatingOperation`](#ifloatingoperation)[] | Array of operations to display in the floating button. Each operation shows as a row with icon, label, and progress indicator. Operations from multiple plugins are aggregated and displayed together. | [interfaces/components/IFloatingOperationsButton.ts:182](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L182) |
| <a id="operationscompleted"></a> `operationsCompleted?` | `boolean` | Flag indicating all operations are completed. When true, the button shows a green checkmark and "completed" status. User can then dismiss the button or review completed operations. | [interfaces/components/IFloatingOperationsButton.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L191) |
| <a id="operationsalert"></a> `operationsAlert?` | `boolean` | Flag indicating at least one operation has an error. When true, the button shows a red warning indicator. | [interfaces/components/IFloatingOperationsButton.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L199) |
| <a id="showcancelbutton"></a> `showCancelButton?` | `boolean` | Controls the visibility of the cancel button. Cancel button is displayed only if the floating button contains only one operation from the plugin and this flag is set to true. | [interfaces/components/IFloatingOperationsButton.ts:208](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L208) |
| <a id="canceloperation"></a> `cancelOperation?` | () => [`TReturnMessage`](../utils.md#treturnmessage) | Callback executed when user clicks the cancel button in the floating button. | [interfaces/components/IFloatingOperationsButton.ts:215](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L215) |
| <a id="oncanceloperationfromlist"></a> `onCancelOperationFromList?` | (`operationId`: `string`) => [`TReturnMessage`](../utils.md#treturnmessage) | Callback executed when user closes a specific operation from the operations list. Receives the operation ID. Typically returns Actions.updateFloatingOperationsButton with the updated operations list. | [interfaces/components/IFloatingOperationsButton.ts:224](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L224) |
| <a id="onload"></a> `onLoad?` | (`dispatchMessage`: (`message`: [`IMessage`](../utils.md#imessage)) => `void`) => [`TReturnMessage`](../utils.md#treturnmessage) | Lifecycle callback executed once when floating operations button with given id is displayed for the first time. Receives a dispatchMessage function to send updates back to DocSpace. Use this to initialize progress tracking or update. | [interfaces/components/IFloatingOperationsButton.ts:234](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L234) |

***

### Example

Demonstrates a floating operations in button with simulated upload progress,
allowing users to cancel the process or remove individual operations while
preventing a new upload until the current one finishes.

```typescript
import {
  IFloatingOperationsButton,
  FloatingOperationType,
  Actions,
  IContextMenuItem,
  FilesType,
} from "@onlyoffice/docspace-plugin-sdk";

const operations = [
  {
      id: "upload-document",
      label: "Uploading document.pdf",
      operation: FloatingOperationType.Upload,
      alert: false,
      completed: false,
      percent: 0,
      // custom icon from assets
      icon: "upload.svg",
  },
  {
      id: "convert-image",
      label: "Converting image.jpg",
      operation: FloatingOperationType.Convert,
      alert: false,
      completed: false,
      percent: 0,
  }
]

// flag to check if upload is in progress
let isUpload = false;
let intervalId: NodeJS.Timeout | null = null;

export const uploadButton: IFloatingOperationsButton = {
  id: "upload-button",
  operationsCompleted: false,
  operationsAlert: false,
  // show cancel button when there is only one operation left
  showCancelButton: true,

  cancelOperation: () => {
      // reset interval and flags
      intervalId && clearInterval(intervalId);
      isUpload = false;
      intervalId = null;
      // send message to remove floating operations from button
      return {
          actions: [Actions.removeFloatingOperationsButton],
          floatingOperationsButtonPropsId: uploadButton.id,
      };
  },

  onCancelOperationFromList: (id) => {
      // remove operation from list
      const filteredOps = uploadButton.operations?.filter(
          (op) => op.id !== id
      ) ?? [];

      // update operations
      uploadButton.operations = filteredOps;

      // send message to update floating operations button
      return {
          actions: [Actions.updateFloatingOperationsButton],
          floatingOperationsButtonProps: uploadButton,
      };
  },

  // event on add floating operations in button
  onLoad: (dispatchMessage) => {
      let progress = 0;
      isUpload = true;

      // update progress every 400ms
      intervalId = setInterval(() => {
          progress += 5;

          // update progress for each operation
          const operations = uploadButton.operations?.map((op) => ({
              ...op,
              percent: progress,
              completed: progress >= 100,
          })) ?? [];

          uploadButton.operations = operations;

          // update operations completed
          uploadButton.operationsCompleted = progress >= 100;

          // send message to update floating operations button
          dispatchMessage({
              actions: [Actions.updateFloatingOperationsButton],
              floatingOperationsButtonProps: uploadButton,
          });

          // stop interval if progress is 100
          if (progress >= 100) {
              // reset interval and flags
              intervalId && clearInterval(intervalId);
              isUpload = false;
              intervalId = null;
          }
      }, 400);
  },
};

export const uploadMenuItem: IContextMenuItem = {
  key: "upload-files",
  label: "Upload with progress",
  icon: "upload.svg",
  fileType: [FilesType.file],
  onClick: () => {
      // if upload is in progress, do not allow to start new upload
      if (isUpload) {
          return;
      }

      // Reset operations from previous upload
      uploadButton.operations = structuredClone(operations);
      uploadButton.operationsCompleted = false;
      uploadButton.operationsAlert = false;

      // send message to add floating operations in button
      return {
          actions: [Actions.addFloatingOperationsButton],
          floatingOperationsButtonProps: uploadButton,
      };
  },
};
```

## FloatingOperationType

Defined in: [interfaces/components/IFloatingOperationsButton.ts:243](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L243)

Determines the icon and visual representation of the operation.

### Enumeration Members

#### Download

```ts
Download: "download";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:245](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L245)

File download operation

#### Convert

```ts
Convert: "convert";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:247](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L247)

File conversion operation

#### Copy

```ts
Copy: "copy";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:249](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L249)

File copy operation

#### Duplicate

```ts
Duplicate: "duplicate";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:251](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L251)

File duplication operation

#### MarkAsRead

```ts
MarkAsRead: "markAsRead";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:253](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L253)

Mark as read operation

#### DeletePermanently

```ts
DeletePermanently: "deletePermanently";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:255](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L255)

Permanent deletion operation

#### ExportIndex

```ts
ExportIndex: "exportIndex";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:257](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L257)

Export index operation

#### Move

```ts
Move: "move";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:259](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L259)

File move operation

#### Trash

```ts
Trash: "trash";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:261](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L261)

Move to trash operation

#### Other

```ts
Other: "other";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:263](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L263)

Other custom operation

#### Upload

```ts
Upload: "upload";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:265](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L265)

File upload operation

#### DeleteVersionFile

```ts
DeleteVersionFile: "deleteVersionFile";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:267](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L267)

Delete file version operation

#### Backup

```ts
Backup: "backup";
```

Defined in: [interfaces/components/IFloatingOperationsButton.ts:269](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L269)

Backup operation

***

## IFloatingOperation

Defined in: [interfaces/components/IFloatingOperationsButton.ts:279](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L279)

Represents a single operation in the floating operations button.
Each operation displays as a row with icon, label, and progress indicator.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="id-1"></a> `id` | `string` | Unique identifier for the operation. | [interfaces/components/IFloatingOperationsButton.ts:283](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L283) |
| <a id="label"></a> `label` | `string` | Text label displayed to the user describing the operation. Example: "Uploading document.pdf" or "Converting 5 files" | [interfaces/components/IFloatingOperationsButton.ts:291](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L291) |
| <a id="operation"></a> `operation` | [`FloatingOperationType`](#floatingoperationtype) | Type of operation - determines the default icon and visual representation. Use predefined types (Upload, Convert, etc.). | [interfaces/components/IFloatingOperationsButton.ts:299](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L299) |
| <a id="alert"></a> `alert` | `boolean` | Error flag - if true, the operation is displayed with a warning/error state. Shows red icon and allows user to see what went wrong. Shows red icon. | [interfaces/components/IFloatingOperationsButton.ts:308](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L308) |
| <a id="completed"></a> `completed` | `boolean` | Completion flag - if true, the operation is marked as completed. Shows checkmark icon and allows user to dismiss the operation. | [interfaces/components/IFloatingOperationsButton.ts:316](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L316) |
| <a id="percent"></a> `percent?` | `number` | Progress percentage of the operation (0-100). If undefined, displays an infinite loader animation instead of percentage. | [interfaces/components/IFloatingOperationsButton.ts:324](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L324) |
| <a id="icon"></a> `icon?` | `string` | Custom icon for the operation (overrides default operation icon). The icon image must be uploaded to the "assets" folder. Only specify the filename here, e.g., "upload.svg" or "custom-icon.png". | [interfaces/components/IFloatingOperationsButton.ts:333](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L333) |
