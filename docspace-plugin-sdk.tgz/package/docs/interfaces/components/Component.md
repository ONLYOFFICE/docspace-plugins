---
toc_max_heading_level: 2
hide_title: true
---

# Component

```ts
type Component = 
  | BoxGroup
  | ButtonGroup
  | CheckboxGroup
  | ComboBoxGroup
  | IFrameGroup
  | ImageGroup
  | InputGroup
  | LabelGroup
  | SkeletonGroup
  | TextGroup
  | TextAreaGroup
  | ToggleButtonGroup
  | IconButtonGroup
  | LinkGroup;
```

Defined in: [interfaces/components/Component.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L106)

A component that is used to add components into Box.
Only components that are embedded into DOM can be wrapped (toast, modal dialog, etc. cannot be wrapped).

### Example

```typescript
import {
  IBox,
  IText,
  IButton,
  ButtonSize,
  Components,
  Component,
  Actions
  IToast,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

const title: IText = {
  text: "Plugin Settings",
  fontSize: "18px",
  fontWeight: 600,
};

const button: IButton = {
  label: "Save Changes",
  onClick: () => {
    return {
      actions: [Actions.showToast],
      toastProps: [{
        title: "Success",
        type: ToastType.success,
      }]
    };
  },
  size: ButtonSize.normal,
  primary: true
};

// Create a settings panel with text and button
const container: IBox = {
  paddingProp: "16px",
  backgroundProp: "#f8f9f9",
  children: [
    {
      component: Components.text,
      props: title
    },
    {
      component: Components.button,
      props: button
    }
  ]
};

// Combine components into a layout
const settingsPanel: Component = {
  component: Components.box,
  props: container
};
```

***

## BoxGroup

```ts
type BoxGroup = {
  component: box;
  props: IBox;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L153)

Defines the box component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-1"></a> `component` | [`box`](../../enums/Components.md#box) | Defines the "box" component type | [interfaces/components/Component.ts:155](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L155) |
| <a id="props"></a> `props` | [`IBox`](IBox.md#ibox) | Defines the box component properties | [interfaces/components/Component.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L157) |
| <a id="contextname"></a> `contextName?` | `string` | Defines the box component context name that updates the component via React context | [interfaces/components/Component.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L159) |

***

### Example

```typescript
import { IBox, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const box: IBox = {
  widthProp: "200px",
  paddingProp: "16px",
  displayProp: "flex",
  flexDirection: "column",
  alignItems: "center",
  borderProp: {
    color: "#333333",
    radius: "8px",
    style: "solid",
    width: "1px"
  },
  backgroundProp: "#f8f9f9"
};

const boxGroup: Component = {
  component: Components.box,
  props: box,
  contextName: "container"
};
```

## ButtonGroup

```ts
type ButtonGroup = {
  component: button;
  props: IButton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L186)

Defines the button component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-2"></a> `component` | [`button`](../../enums/Components.md#button) | Defines the "button" component type | [interfaces/components/Component.ts:188](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L188) |
| <a id="props-1"></a> `props` | [`IButton`](IButton.md#ibutton) | Defines the button component properties | [interfaces/components/Component.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L190) |
| <a id="contextname-1"></a> `contextName?` | `string` | Defines the button component context name that updates the component via React context | [interfaces/components/Component.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L192) |

***

### Example

```typescript
import { IButton, Components, Components, ButtonSize } from "@onlyoffice/docspace-plugin-sdk";

const button: IButton = {
  size: ButtonSize.normal,
  label: "Click me!",
  onClick: () => {
    console.log("Button clicked!");
  },
};

const buttonGroup: Component = {
  component: Components.button,
  props: button,
  contextName: "button",
};
```

## CheckboxGroup

```ts
type CheckboxGroup = {
  component: checkbox;
  props: ICheckbox;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:231](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L231)

Defines the checkbox component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-3"></a> `component` | [`checkbox`](../../enums/Components.md#checkbox) | Defines the "checkbox" component type | [interfaces/components/Component.ts:233](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L233) |
| <a id="props-2"></a> `props` | [`ICheckbox`](ICheckbox.md#icheckbox) | Defines the checkbox component properties | [interfaces/components/Component.ts:235](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L235) |
| <a id="contextname-2"></a> `contextName?` | `string` | Defines the checkbox component context name that updates the component via React context | [interfaces/components/Component.ts:237](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L237) |

***

### Example

```typescript
import { ICheckbox, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const checkbox: ICheckbox = {
  isChecked: false,
  label: "Enable notifications",
  onChange: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        isChecked: !checkbox.isChecked
      }
    };
  },
  truncate: false,
  tabIndex: 1,
  hasError: false,
  name: "notifications",
  value: "enabled",
  isDisabled: false,
  title: "Notification preferences"
};

const checkboxGroup: Component = {
  component: Components.checkbox,
  props: checkbox,
  contextName: "notificationToggle"
};
```

## ComboBoxGroup

```ts
type ComboBoxGroup = {
  component: comboBox;
  props: IComboBox;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:271](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L271)

Defines the combo box component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-4"></a> `component` | [`comboBox`](../../enums/Components.md#combobox) | Defines the "comboBox" component type | [interfaces/components/Component.ts:273](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L273) |
| <a id="props-3"></a> `props` | [`IComboBox`](IComboBox.md#icombobox) | Defines the combo box component properties | [interfaces/components/Component.ts:275](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L275) |
| <a id="contextname-3"></a> `contextName?` | `string` | Defines the combo box component context name that updates the component via React context | [interfaces/components/Component.ts:277](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L277) |

***

### Example

```typescript
import { IComboBox, IComboBoxItem, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const comboBox: IComboBox = {
  options: [
    { key: "light", label: "Light Theme", icon: "theme-light.svg" },
    { key: "dark", label: "Dark Theme", icon: "theme-dark.svg" },
    { key: "system", label: "System Theme", icon: "theme-auto.svg" }
  ],
  selectedOption: { key: "light", label: "Light Theme", icon: "theme-light.svg" },
  onSelect: (item) => {},
  scaled: true,
  directionX: "right",
  directionY: "bottom",
  displayType: "default",
  modernView: true
};

const comboBoxGroup: Component = {
  component: Components.comboBox,
  props: comboBox,
  contextName: "themeSelector"
};
```

## IFrameGroup

```ts
type IFrameGroup = {
  component: iFrame;
  props: IFrame;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:310](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L310)

Defines the iframe component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-5"></a> `component` | [`iFrame`](../../enums/Components.md#iframe) | Defines the "iFrame" component type | [interfaces/components/Component.ts:312](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L312) |
| <a id="props-4"></a> `props` | [`IFrame`](IFrame.md#iframe) | Defines the iFrame component properties | [interfaces/components/Component.ts:314](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L314) |
| <a id="contextname-4"></a> `contextName?` | `string` | Defines the iFrame component context name that updates the component via React context | [interfaces/components/Component.ts:316](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L316) |

***

### Example

```typescript
import { IFrame, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const iframe: IFrame = {
  src: "https://example.com/embedded-content",
  width: "100%",
  height: "500px",
  name: "content-frame",
  sandbox: "allow-scripts allow-same-origin",
  id: "content-iframe",
  style: {
    border: "1px solid #eceef1",
    borderRadius: "4px",
    backgroundColor: "#ffffff"
  }
};

const iframeGroup: Component = {
  component: Components.iFrame,
  props: iframe,
  contextName: "embeddedContent"
};
```

## ImageGroup

```ts
type ImageGroup = {
  component: img;
  props: IImage;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:349](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L349)

Defines the image component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-6"></a> `component` | [`img`](../../enums/Components.md#img) | Defines the "img" component type | [interfaces/components/Component.ts:351](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L351) |
| <a id="props-5"></a> `props` | [`IImage`](IImage.md#iimage) | Defines the image component properties | [interfaces/components/Component.ts:353](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L353) |
| <a id="contextname-5"></a> `contextName?` | `string` | Defines the image component context name that updates the component via React context | [interfaces/components/Component.ts:355](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L355) |

***

### Example

```typescript
import { IImage, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const image: IImage = {
  src: "https://example.com/plugin-banner.png",
  alt: "Plugin Banner",
  width: "100%",
  height: "auto",
  name: "plugin-banner",
  id: "banner-image",
  style: {
    borderRadius: "8px",
    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px"
  }
};

const imageGroup: Component = {
  component: Components.img,
  props: image,
  contextName: "bannerImage"
};
```

## InputGroup

```ts
type InputGroup = {
  component: input;
  props: IInput;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:389](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L389)

Defines the input component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-7"></a> `component` | [`input`](../../enums/Components.md#input) | Defines the "input" component type | [interfaces/components/Component.ts:391](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L391) |
| <a id="props-6"></a> `props` | [`IInput`](IInput.md#iinput) | Defines the input component properties | [interfaces/components/Component.ts:393](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L393) |
| <a id="contextname-6"></a> `contextName?` | `string` | Defines the input component context name that updates the component via React context | [interfaces/components/Component.ts:395](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L395) |

***

### Example

```typescript
import { IInput, Components, Component, Actions, InputSize } from "@onlyoffice/docspace-plugin-sdk";

const input: IInput = {
  value: "",
  onChange: (value) => {},
  placeholder: "Enter text...",
  size: InputSize.middle,
  name: "search-input",
  isAutoFocused: true,
  iconName: "search",
  iconSize: 16,
  scale: true,
  onIconClick: () => {
    console.log("Search icon clicked");
  }
};

const inputGroup: Component = {
  component: Components.input,
  props: input,
  contextName: "searchInput"
};
```

## LabelGroup

```ts
type LabelGroup = {
  component: label;
  props: ILabel;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:425](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L425)

Defines the label component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-8"></a> `component` | [`label`](../../enums/Components.md#label) | Defines the "label" component type | [interfaces/components/Component.ts:427](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L427) |
| <a id="props-7"></a> `props` | [`ILabel`](ILabel.md#ilabel) | Defines the label component properties | [interfaces/components/Component.ts:429](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L429) |
| <a id="contextname-7"></a> `contextName?` | `string` | Defines the label component context name that updates the component via React context | [interfaces/components/Component.ts:431](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L431) |

***

### Example

```typescript
import { ILabel, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const label: ILabel = {
  text: "Plugin Settings",
  isRequired: true,
  error: false,
  isInline: false,
  title: "Configure plugin settings",
  htmlFor: "settings-form",
  display: "block",
  truncate: true
};

const labelGroup: Component = {
  component: Components.label,
  props: label,
  contextName: "settingsLabel"
};
```

## SkeletonGroup

```ts
type SkeletonGroup = {
  component: skeleton;
  props: ISkeleton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:456](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L456)

Defines the skeleton component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-9"></a> `component` | [`skeleton`](../../enums/Components.md#skeleton) | Defines the "skeleton" component type | [interfaces/components/Component.ts:458](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L458) |
| <a id="props-8"></a> `props` | [`ISkeleton`](ISkeleton.md#iskeleton) | Defines the skeleton component properties | [interfaces/components/Component.ts:460](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L460) |
| <a id="contextname-8"></a> `contextName?` | `string` | Defines the skeleton component context name that updates the component via React context | [interfaces/components/Component.ts:462](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L462) |

***

### Example

```typescript
import { ISkeleton, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const skeleton: ISkeleton = {
  width: "100%",
  height: "200px",
  borderRadius: "8px"
};

const skeletonGroup: Component = {
  component: Components.skeleton,
  props: skeleton,
  contextName: "loadingState"
};
```

## TextGroup

```ts
type TextGroup = {
  component: text;
  props: IText;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:493](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L493)

Defines the text component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-10"></a> `component` | [`text`](../../enums/Components.md#text) | Defines the "text" component type | [interfaces/components/Component.ts:495](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L495) |
| <a id="props-9"></a> `props` | [`IText`](IText.md#itext) | Defines the text component properties | [interfaces/components/Component.ts:497](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L497) |
| <a id="contextname-9"></a> `contextName?` | `string` | Defines the text component context name that updates the component via React context | [interfaces/components/Component.ts:499](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L499) |

***

### Example

```typescript
import { IText, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const text: IText = {
  text: "Welcome to DocSpace Plugin",
  fontSize: "18px",
  fontWeight: 500,
  lineHeight: "24px",
  color: "#333333",
  isBold: false,
  textAlign: "left",
  truncate: true,
  title: "Welcome to DocSpace Plugin"
};

const textGroup: Component = {
  component: Components.text,
  props: text,
  contextName: "welcomeText"
};
```

## TextAreaGroup

```ts
type TextAreaGroup = {
  component: textArea;
  props: ITextArea;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:530](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L530)

Defines the textarea component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-11"></a> `component` | [`textArea`](../../enums/Components.md#textarea) | Defines the "textArea" component type | [interfaces/components/Component.ts:532](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L532) |
| <a id="props-10"></a> `props` | [`ITextArea`](ITextArea.md#itextarea) | Defines the textarea component properties | [interfaces/components/Component.ts:534](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L534) |
| <a id="contextname-10"></a> `contextName?` | `string` | Defines the textarea component context name that updates the component via React context | [interfaces/components/Component.ts:536](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L536) |

***

### Example

```typescript
import { ITextArea, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const textarea: ITextArea = {
  value: "",
  onChange: (value) => {},
  placeholder: "Enter description...",
  heightTextArea: 150,
  fontSize: 14,
  isFullHeight: true,
  heightScale: true,
  maxLength: 1000,
  hasNumeration: false
};

const textAreaGroup: Component = {
  component: Components.textArea,
  props: textarea,
  contextName: "descriptionEditor"
};
```

## ToggleButtonGroup

```ts
type ToggleButtonGroup = {
  component: toggleButton;
  props: IToggleButton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:566](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L566)

Defines the toggle button component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-12"></a> `component` | [`toggleButton`](../../enums/Components.md#togglebutton) | Defines the "toggleButton" component type | [interfaces/components/Component.ts:568](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L568) |
| <a id="props-11"></a> `props` | [`IToggleButton`](IToggleButton.md#itogglebutton) | Defines the toggle button component properties | [interfaces/components/Component.ts:570](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L570) |
| <a id="contextname-11"></a> `contextName?` | `string` | Defines the toggle button component context name that updates the component via React context | [interfaces/components/Component.ts:572](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L572) |

***

### Example

```typescript
import { IToggleButton, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const toggleButton: IToggleButton = {
  label: "Auto-sync",
  isChecked: true,
  onChange: () => {},
  style: {
    backgroundColor: "#f8f9f9",
    padding: "8px 12px",
    borderRadius: "4px"
  }
};

const toggleButtonGroup: Component = {
  component: Components.toggleButton,
  props: toggleButton,
  contextName: "syncToggle"
};
```

## IconButtonGroup

```ts
type IconButtonGroup = {
  component: iconButton;
  props: IIconButton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:602](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L602)

Defines the icon button component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-13"></a> `component` | [`iconButton`](../../enums/Components.md#iconbutton) | Defines the "iconButton" component type | [interfaces/components/Component.ts:604](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L604) |
| <a id="props-12"></a> `props` | [`IIconButton`](IIconButton.md#iiconbutton) | Defines the icon button component properties | [interfaces/components/Component.ts:606](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L606) |
| <a id="contextname-12"></a> `contextName?` | `string` | Defines the icon button component context name that updates the component via React context | [interfaces/components/Component.ts:608](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L608) |

***

### Example

```typescript
import { IIconButton, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const iconButton: IIconButton = {
  iconName: "settings.svg",
  size: 32,
  color: "#333333",
  hoverColor: "accent",
  onClick: () => {
    console.log("Settings clicked");
  },
  title: "Open settings",
  isDisabled: false
};

const iconButtonGroup: Component = {
  component: Components.iconButton,
  props: iconButton,
  contextName: "settingsButton"
};
```

## LinkGroup

```ts
type LinkGroup = {
  component: link;
  props: ILink;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:636](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L636)

Defines the link component.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="component-14"></a> `component` | [`link`](../../enums/Components.md#link) | Defines the "link" component type | [interfaces/components/Component.ts:638](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L638) |
| <a id="props-13"></a> `props` | [`ILink`](ILink.md#ilink) | Defines the link component properties | [interfaces/components/Component.ts:640](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L640) |
| <a id="contextname-13"></a> `contextName?` | `string` | Defines the link component context name that updates the component via React context | [interfaces/components/Component.ts:642](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L642) |
### Example

```typescript
import { ILink, Components, Component, LinkType, LinkTarget } from "@onlyoffice/docspace-plugin-sdk";

const link: ILink = {
  href: "https://example.com",
  text: "Visit Example",
  type: LinkType.page,
  target: LinkTarget.blank,
  color: "accent",
  fontSize: "14px",
  isBold: false
};

const linkGroup: Component = {
  component: Components.link,
  props: link,
  contextName: "exampleLink"
};
```

