---
toc_max_heading_level: 3
hide_title: true
---

# IFrame

Defined in: [interfaces/components/IFrame.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L63)

A component that is used to embed a third-party website into a modal window or the settings page.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="src"></a> `src` | `string` | Defines the base URL to a modal window or the settings page. It is used to generate links | [interfaces/components/IFrame.ts:68](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L68) |
| <a id="width"></a> `width?` | `string` | Defines the frame width measured in percent | [interfaces/components/IFrame.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L74) |
| <a id="height"></a> `height?` | `string` | Defines the frame height measured in percent | [interfaces/components/IFrame.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L80) |
| <a id="name"></a> `name?` | `string` | Defines the name of the object inserted into the page | [interfaces/components/IFrame.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L86) |
| <a id="sandbox"></a> `sandbox?` | `string` | Defines the frame sandbox | [interfaces/components/IFrame.ts:92](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L92) |
| <a id="id"></a> `id?` | `string` | Defines the element ID | [interfaces/components/IFrame.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L98) |
| <a id="style"></a> `style?` | \{ \[`key`: `string`\]: `string`; \} | Defines the frame style | [interfaces/components/IFrame.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L104) |
| <a id="classname"></a> `className?` | `string` | Defines the CSS class for styling the component. Can be used to override or extend the default component styles. | [interfaces/components/IFrame.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L112) |
### Examples

Embedding a PDF viewer in a modal window

```typescript
const pdfViewer: IFrame = {
  src: "https://example.com/pdf-viewer",
  width: "100%",
  height: "80%",
  name: "pdf-viewer-frame",
  sandbox: "allow-scripts allow-same-origin allow-forms",
  id: "pdf-viewer-iframe",
  style: {
    border: "none",
    borderRadius: "8px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)"
  }
}
```

Embedding a settings configuration page

```typescript
const settingsConfig: IFrame = {
  src: "https://example.com/plugin-settings",
  width: "100%",
  height: "100%",
  name: "plugin-settings",
  sandbox: "allow-scripts allow-same-origin allow-forms allow-popups",
  id: "settings-iframe",
  style: {
    border: "1px solid #eceef1",
    backgroundColor: "#ffffff",
    padding: "16px"
  }
}
```

