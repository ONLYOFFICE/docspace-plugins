---
toc_max_heading_level: 3
hide_title: true
---

# IModalDialog

Defined in: [interfaces/components/IModalDialog.ts:182](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L182)

Modal dialog.

<img alt="modal-dialog" src="/assets/images/docspace/modal-dialog.png" />

### Remarks

**Important:** `dialogBody` and `dialogFooter` are rendered in separate contexts.
Components in `dialogFooter` cannot update components in `dialogBody` using
`Actions.updateContext`, and vice versa.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="displaytype"></a> `displayType` | [`ModalDisplayType`](#modaldisplaytype) | Defines the modal dialog display type | [interfaces/components/IModalDialog.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L187) |
| <a id="dialogheader"></a> `dialogHeader?` | `string` | Defines the modal dialog header | [interfaces/components/IModalDialog.ts:193](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L193) |
| <a id="dialogbody"></a> `dialogBody` | [`IBox`](IBox.md#ibox) | Defines the modal dialog body | [interfaces/components/IModalDialog.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L199) |
| <a id="dialogfooter"></a> `dialogFooter?` | [`IBox`](IBox.md#ibox) | Defines the modal dialog footer | [interfaces/components/IModalDialog.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L205) |
| <a id="automaxwidth"></a> `autoMaxWidth?` | `boolean` | Specifies whether the "max-width: auto" property is set | [interfaces/components/IModalDialog.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L211) |
| <a id="automaxheight"></a> `autoMaxHeight?` | `boolean` | Specifies whether the "max-height: auto" property is set | [interfaces/components/IModalDialog.ts:217](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L217) |
| <a id="withoutbodypadding"></a> `withoutBodyPadding?` | `boolean` | Specifies whether the modal dialog body has no paddings | [interfaces/components/IModalDialog.ts:223](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L223) |
| <a id="withoutheadermargin"></a> `withoutHeaderMargin?` | `boolean` | Specifies whether the modal dialog header has no bottom margins | [interfaces/components/IModalDialog.ts:229](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L229) |
| <a id="withfooterborder"></a> `withFooterBorder?` | `boolean` | Specifies whether the border betweeen the body and footer is displayed | [interfaces/components/IModalDialog.ts:235](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L235) |
| <a id="fullscreen"></a> `fullScreen?` | `boolean` | Specifies whether to display the modal dialog body in the full screen mode without paddings | [interfaces/components/IModalDialog.ts:241](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L241) |
| <a id="eventlisteners"></a> `eventListeners?` | \{ `name`: `string`; `onAction`: () => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\>; \}[] | Defines the event listeners. | [interfaces/components/IModalDialog.ts:248](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L248) |
| <a id="onclose"></a> `onClose` | () => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Sets a function which is triggered whenever the "Close" button in the modal dialog is clicked | [interfaces/components/IModalDialog.ts:263](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L263) |
| <a id="onload"></a> `onLoad` | () => `Promise`\<\{ `newDialogHeader?`: `string`; `newDialogBody`: [`IBox`](IBox.md#ibox); `newDialogFooter?`: [`IBox`](IBox.md#ibox); \}\> | Sets a function which is triggered whenever the modal dialog is loaded. | [interfaces/components/IModalDialog.ts:270](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L270) |
### Examples

Interactive document preview modal with dynamic content loading

```typescript
const filePreviewModal: IModalDialog = {
  displayType: ModalDisplayType.modal,
  dialogHeader: "Document Preview",
  dialogBody: {
    children: [
      {
        component: "iframe",
        props: {
          src: "https://example.com/preview/doc.pdf",
          width: "100%",
          height: "600px"
        }
      }
    ]
  },
  dialogFooter: {
    children: [
      {
        component: "button",
        props: {
          label: "Download",
          onClick: () => {
            return {
              actions: [Actions.downloadFile],
              fileUrl: "https://example.com/download/doc.pdf"
            };
          }
        }
      }
    ]
  },
  autoMaxWidth: true,
  autoMaxHeight: true,
  withFooterBorder: true,
  fullScreen: false,
  eventListeners: [
    {
      name: "documentLoaded",
      onAction: async () => {
        return {
          actions: [Actions.showToast],
          toastProps: [{
            title: "Success",
            type: "success",
            message: "Document loaded successfully"
          }]
        };
      }
    }
  ],
  onClose: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        visible: false
      }
    };
  },
  onLoad: async () => {
    const documentDetails = await fetchDocumentDetails();
    return {
      newDialogHeader: `Preview: ${documentDetails.name}`,
      newDialogBody: {
        children: [
          {
            component: "iframe",
            props: {
              src: documentDetails.previewUrl,
              width: "100%",
              height: "600px"
            }
          }
        ]
      },
      newDialogFooter: {
        children: [
          {
            component: "button",
            props: {
              label: "Download",
              onClick: () => ({
                actions: [Actions.downloadFile],
                fileUrl: documentDetails.downloadUrl
              })
            }
          }
        ]
      }
    };
  }
}
```

Side panel settings dialog with API key configuration

```typescript
const settingsPanel: IModalDialog = {
  displayType: ModalDisplayType.aside,
  dialogHeader: "Plugin Settings",
  dialogBody: {
    children: [
      {
        component: "input",
        props: {
          label: "API Key",
          type: "password",
          value: "",
          onChange: (value) => ({
            actions: [Actions.updateProps],
            newProps: { value }
          })
        }
      }
    ]
  },
  autoMaxWidth: false,
  autoMaxHeight: true,
  withFooterBorder: true,
  fullScreen: false,
  onClose: () => ({
    actions: [Actions.updateProps],
    newProps: { visible: false }
  }),
  onLoad: async () => {
    const settings = await loadSettings();
    return {
      newDialogBody: {
        children: [
          {
            component: "input",
            props: {
              label: "API Key",
              type: "password",
              value: settings.apiKey
            }
          }
        ]
      }
    };
  }
}
```

## ModalDisplayType

Defined in: [interfaces/components/IModalDialog.ts:291](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L291)

The supported modal dialog types.

### Enumeration Members

#### modal

```ts
modal: "modal";
```

Defined in: [interfaces/components/IModalDialog.ts:293](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L293)

Modal dialog displayed in the center of the screen

#### aside

```ts
aside: "aside";
```

Defined in: [interfaces/components/IModalDialog.ts:295](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L295)

Modal dialog displayed as a side panel

***

