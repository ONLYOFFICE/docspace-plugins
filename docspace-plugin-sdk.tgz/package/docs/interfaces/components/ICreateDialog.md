---
toc_max_heading_level: 3
hide_title: true
---

# ICreateDialog

Defined in: [interfaces/components/ICreateDialog.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L105)

Modal dialog for creating certain item (file, folder, etc.).
The user gets the full access to the functionality but cannot control the layout.

### Properties

| Property | Type | Description | Defined in |
| ------ | ------ | ------ | ------ |
| <a id="title"></a> `title` | `string` | Defines the modal dialog title. | [interfaces/components/ICreateDialog.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L111) |
| <a id="startvalue"></a> `startValue` | `string` | Defines the modal dialog start value. | [interfaces/components/ICreateDialog.ts:118](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L118) |
| <a id="visible"></a> `visible` | `boolean` | Specifies if the modal dialog is visible or not. | [interfaces/components/ICreateDialog.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L125) |
| <a id="iscreatedisabled"></a> `isCreateDisabled?` | `boolean` | Specifies if the create button is disabled. | [interfaces/components/ICreateDialog.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L132) |
| <a id="iscloseaftercreate"></a> `isCloseAfterCreate?` | `boolean` | Specifies if the modal dialog should be closed after the create action. | [interfaces/components/ICreateDialog.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L139) |
| <a id="options"></a> `options?` | [`IComboBoxItem`](IComboBox.md#icomboboxitem)[] | Defines an array of the modal dialog options. | [interfaces/components/ICreateDialog.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L146) |
| <a id="selectedoption"></a> `selectedOption?` | [`IComboBoxItem`](IComboBox.md#icomboboxitem) | Defines the selected modal dialog option. | [interfaces/components/ICreateDialog.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L153) |
| <a id="errortext"></a> `errorText?` | `string` | Error text to display when validation fails or an error occurs. | [interfaces/components/ICreateDialog.ts:160](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L160) |
| <a id="onselect"></a> `onSelect?` | (`option`: [`IComboBoxItem`](IComboBox.md#icomboboxitem)) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the modal dialog option is selected. | [interfaces/components/ICreateDialog.ts:167](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L167) |
| <a id="onchange"></a> `onChange?` | (`value`: `string`) => `void` \| [`IMessage`](../utils.md#imessage) | Sets a function which is triggered whenever the input value changes. | [interfaces/components/ICreateDialog.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L174) |
| <a id="onsave"></a> `onSave?` | (`e`: `any`, `value`: `string`) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Sets a function which is triggered whenever the data in the modal dialog is saved. | [interfaces/components/ICreateDialog.ts:181](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L181) |
| <a id="oncancel"></a> `onCancel?` | (`e`: `any`) => `void` | Sets a function which is triggered whenever an action in the modal dialog is canceled. | [interfaces/components/ICreateDialog.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L191) |
| <a id="onclose"></a> `onClose?` | (`e`: `any`) => `void` | Sets a function which is triggered whenever the modal dialog is closed. | [interfaces/components/ICreateDialog.ts:198](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L198) |
| <a id="onerror"></a> `onError?` | (`e`: `any`) => \| `void` \| `Promise`\<`void`\> \| [`IMessage`](../utils.md#imessage) \| `Promise`\<[`IMessage`](../utils.md#imessage)\> | Sets a function which is triggered whenever an error occurs during the onSave operation. | [interfaces/components/ICreateDialog.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L205) |
| <a id="iscreatedialog"></a> `isCreateDialog` | `boolean` | Specifies if this modal dialog is for creating certain item (file, folder, etc.). | [interfaces/components/ICreateDialog.ts:212](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L212) |
| <a id="isautofocusonerror"></a> `isAutoFocusOnError?` | `boolean` | Specifies if this modal dialog should automatically focus on the error input field when an error occurs during the onSave operation. | [interfaces/components/ICreateDialog.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L219) |
| <a id="extension"></a> `extension?` | `string` | Defines an extension of an item which will be created (file, folder, etc.). | [interfaces/components/ICreateDialog.ts:226](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L226) |
### Example

Document creation dialog with multiple format options

```typescript
const newDocumentDialog: ICreateDialog = {
  title: "Create New Document",
  startValue: "Untitled",
  visible: true,
  options: [
    {
      key: "docx",
      label: "Word Document",
      icon: "word.svg"
    },
    {
      key: "xlsx",
      label: "Excel Spreadsheet",
      icon: "excel.svg"
    },
    {
      key: "pptx",
      label: "PowerPoint Presentation",
      icon: "powerpoint.svg"
    }
  ],
  selectedOption: {
    key: "docx",
    label: "Word Document",
    icon: "word.svg"
  },
  onSelect: (option) => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        selectedOption: option,
        extension: option.key
      }
    };
  },
  onSave: async (e, value) => {
    try {
      // Create the document
      await createDocument(value, selectedOption.key);

      return {
        actions: [Actions.updateProps, Actions.showToast],
        newProps: {
          visible: false
        },
        toastProps: [{
          title: "Success",
          type: "success",
          message: `Document "${value}" created successfully`
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Error",
          type: "error",
          message: "Failed to create document. Please try again."
        }]
      };
    }
  },
  onCancel: (e) => {
    // Clean up any temporary state if needed
  },
  onClose: (e) => {
    // Additional cleanup or analytics
  },
  isCreateDialog: true,
  extension: "docx"
}
```

