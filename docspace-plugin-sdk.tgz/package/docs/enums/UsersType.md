---
toc_max_heading_level: 3
hide_title: true
---

# UsersType

Defined in: [enums/UsersType.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L22)

Defines the supported user types.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `owner` | `"Owner"` | System owner with full administrative rights and control over the entire DocSpace instance |
| `docSpaceAdmin` | `"DocSpaceAdmin"` | Administrator with system-wide management capabilities but limited compared to owner |
| `roomAdmin` | `"RoomAdmin"` | User with administrative rights within specific rooms or workspaces |
| `collaborator` | `"Collaborator"` | User with enhanced permissions for content creation and modification |
| `user` | `"User"` | Regular user with basic access rights for viewing and interacting with content |
