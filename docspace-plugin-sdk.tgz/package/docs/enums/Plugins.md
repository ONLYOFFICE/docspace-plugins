---
sidebar_label: "Plugins"
toc_max_heading_level: 3
hide_title: true
---

# Plugins

Enumerations for plugin status and supported locales.

## PluginStatus

Defined in: [enums/Plugins.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L27)

Defines the supported plugin statuses.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `active` | `"active"` | Plugin is enabled and visible to users |
| `hide` | `"hide"` | Plugin is disabled and hidden from the user interface |
## PluginLocale

Defined in: [enums/Plugins.ts:38](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L38)

Defines the supported plugin languages.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `AZ` | `"az"` | — |
| `CS` | `"cs"` | — |
| `DE` | `"de"` | — |
| `EN` | `"en-GB"` | — |
| `EN` | `"en-US"` | — |
| `ES` | `"es"` | — |
| `FR` | `"fr"` | — |
| `IT` | `"it"` | — |
| `LV` | `"lv"` | — |
| `NL` | `"nl"` | — |
| `PL` | `"pl"` | — |
| `PT` | `"pt-BR"` | — |
| `PT` | `"pt"` | — |
| `RO` | `"ro"` | — |
| `SK` | `"sk"` | — |
| `SL` | `"sl"` | — |
| `SQ` | `"sq-AL"` | — |
| `FI` | `"fi"` | — |
| `VI` | `"vi"` | — |
| `TR` | `"tr"` | — |
| `EL` | `"el-GR"` | — |
| `BG` | `"bg"` | — |
| `RU` | `"ru"` | — |
| `SR` | `"sr-Cyrl-RS"` | — |
| `SR` | `"sr-Latn-RS"` | — |
| `UK` | `"uk-UA"` | — |
| `HY` | `"hy-AM"` | — |
| `AR` | `"ar-SA"` | — |
| `SI` | `"si"` | — |
| `LO` | `"lo-LA"` | — |
| `ZH` | `"zh-CN"` | — |
| `JA` | `"ja-JP"` | — |
| `KO` | `"ko-KR"` | — |
