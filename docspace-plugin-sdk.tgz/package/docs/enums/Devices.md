---
toc_max_heading_level: 3
hide_title: true
---

# Devices

Defined in: [enums/Devices.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Devices.ts#L22)

Defines the supported device types.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `mobile` | `"mobile"` | Smartphones and small-screen mobile devices |
| `tablet` | `"tablet"` | Tablet devices and medium-sized screens |
| `desktop` | `"desktop"` | Desktop computers and large-screen devices |
