---
toc_max_heading_level: 3
hide_title: true
---

# Components

Defined in: [enums/Components.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L22)

Defines the available UI component.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `box` | `"box"` | Container component for grouping other elements |
| `button` | `"button"` | Interactive button element |
| `checkbox` | `"checkbox"` | Selectable checkbox input |
| `input` | `"input"` | Text input field |
| `label` | `"label"` | Text label for form elements |
| `text` | `"text"` | Static text display |
| `textArea` | `"textArea"` | Multi-line text input |
| `toggleButton` | `"toggleButton"` | Switch-like button with two states |
| `img` | `"img"` | Image display component |
| `iFrame` | `"iFrame"` | Embedded frame component |
| `comboBox` | `"comboBox"` | Dropdown selection input |
| `skeleton` | `"skeleton"` | Loading placeholder component |
| `iconButton` | `"iconButton"` | Icon button component with hover and click states |
| `link` | `"link"` | Hyperlink component |
