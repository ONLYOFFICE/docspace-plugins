---
toc_max_heading_level: 3
hide_title: true
---

# FilterType

Defined in: [enums/Utility.ts:2](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L2)

Enum for filter type used in file selectors.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `None` | `0` | No filter applied. |
| `FilesOnly` | `1` | Show files only (excludes folders). |
| `FoldersOnly` | `2` | Show folders only (excludes files). |
| `DocumentsOnly` | `3` | Show document files only (e.g. .docx, .odt). |
| `PresentationsOnly` | `4` | Show presentation files only (e.g. .pptx, .odp). |
| `SpreadsheetsOnly` | `5` | Show spreadsheet files only (e.g. .xlsx, .ods). |
| `ImagesOnly` | `7` | Show image files only (e.g. .png, .jpg, .gif). |
