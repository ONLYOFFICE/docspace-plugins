---
toc_max_heading_level: 3
hide_title: true
---

# SelectorType

Defined in: [enums/Selector.ts:4](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L4)

Defines the types of selector components that can be rendered.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `Base` | `"base"` | A generic selector with a customizable list of items. |
| `Files` | `"files"` | A selector for browsing and selecting files and folders. |
| `Groups` | `"groups"` | A selector for choosing user groups. |
| `People` | `"people"` | A selector for choosing users and guests. |
| `Room` | `"room"` | A selector for browsing and selecting rooms. |
