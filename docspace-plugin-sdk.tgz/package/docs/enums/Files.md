---
sidebar_label: "Files"
toc_max_heading_level: 3
hide_title: true
---

# Files

Enumerations for file types, supported extensions, and security permissions.

## FilesType

Defined in: [enums/Files.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L27)

Defines the supported file types.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `room` | `"room"` | DocSpace room or workspace |
| `file` | `"file"` | Generic file type |
| `folder` | `"folder"` | Directory or folder |
| `image` | `"image"` | Image file (various formats) |
| `video` | `"video"` | Video file (various formats) |
## FilesExst

Defined in: [enums/Files.ts:47](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L47)

Defines the supported file extensions.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `doc` | `".doc"` | Microsoft Word document |
| `docx` | `".docx"` | Microsoft Word document (XML-based) |
| `docm` | `".docm"` | Microsoft Word macro-enabled document |
| `dotx` | `".dotx"` | Microsoft Word template |
| `odt` | `".odt"` | OpenDocument text format |
| `fodt` | `".fodt"` | OpenDocument flat XML text format |
| `ott` | `".ott"` | OpenDocument text template |
| `rtf` | `".rtf"` | Rich Text Format |
| `txt` | `".txt"` | Plain text |
| `pdf` | `".pdf"` | Portable Document Format |
| `docxf` | `".docxf"` | Form document (DOCX-based) |
| `oform` | `".oform"` | Form document (OpenDocument-based) |
| `xls` | `".xls"` | Microsoft Excel spreadsheet |
| `xlsx` | `".xlsx"` | Microsoft Excel spreadsheet (XML-based) |
| `xlsm` | `".xlsm"` | Microsoft Excel macro-enabled spreadsheet |
| `ods` | `".ods"` | OpenDocument spreadsheet |
| `ots` | `".ots"` | OpenDocument spreadsheet template |
| `ppt` | `".ppt"` | Microsoft PowerPoint presentation |
| `pptx` | `".pptx"` | Microsoft PowerPoint presentation (XML-based) |
| `pptm` | `".pptm"` | Microsoft PowerPoint macro-enabled presentation |
| `odp` | `".odp"` | OpenDocument presentation |
| `otp` | `".otp"` | OpenDocument presentation template |
| `pps` | `".pps"` | PowerPoint show format |
| `ppsx` | `".ppsx"` | PowerPoint show format (XML-based) |
| `pot` | `".pot"` | PowerPoint template |
| `avi` | `".avi"` | Video file (AVI format) |
| `flv` | `".flv"` | Video file (FLV format) |
| `mkv` | `".mkv"` | Video file (MKV format) |
| `mov` | `".mov"` | Video file (MOV format) |
| `mp4` | `".mp4"` | Video file (MP4 format) |
| `mpg` | `".mpg"` | Video file (MPEG format) |
| `webm` | `".webm"` | Video file (WebM format) |
| `m2ts` | `".m2ts"` | Video file (M2TS format) |
| `dvd` | `".dvd"` | Video file (DVD format) |
| `svg` | `".svg"` | Scalable Vector Graphics |
| `csv` | `".csv"` | Comma-separated values |
| `djvu` | `".djvu"` | DjVu format |
| `epub` | `".epub"` | E-book format (EPUB) |
| `fb2` | `".fb2"` | E-book format (FB2) |
| `pb2` | `".pb2"` | E-book format (PB2) |
| `iaf` | `".iaf"` | Archive format (IAF) |
| `ics` | `".ics"` | Calendar format (ICS) |
| `mht` | `".mht"` | Web archive (MHT) |
| `xps` | `".xps"` | XML Paper Specification |
| `xml` | `".xml"` | Extensible Markup Language |
## FilesSecurity

Defined in: [enums/Files.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L154)

Defines the supported file security parameters.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `Convert` | `"Convert"` | Permission to convert files to other formats |
| `Copy` | `"Copy"` | Permission to copy files and folders |
| `CustomFilter` | `"CustomFilter"` | Permission to apply custom filters |
| `Delete` | `"Delete"` | Permission to delete items |
| `Download` | `"Download"` | Permission to download files |
| `Duplicate` | `"Duplicate"` | Permission to create duplicates of items |
| `Edit` | `"Edit"` | Permission to edit files |
| `EditHistory` | `"EditHistory"` | Permission to view and edit file history |
| `FillForms` | `"FillForms"` | Permission to fill forms |
| `Lock` | `"Lock"` | Permission to lock/unlock files |
| `Move` | `"Move"` | Permission to move items |
| `Read` | `"Read"` | Permission to view and read content |
| `ReadHistory` | `"ReadHistory"` | Permission to read file history |
| `Rename` | `"Rename"` | Permission to rename items |
| `Review` | `"Review"` | Permission to review documents |
| `SubmitToFormGallery` | `"SubmitToFormGallery"` | Permission to submit forms to gallery |
| `StopFilling` | `"StopFilling"` | Permission to stop form filling process |
| `ResetFilling` | `"ResetFilling"` | Permission to reset form filling |
| `EditForm` | `"EditForm"` | Permission to edit forms |
| `Comment` | `"Comment"` | Permission to comment on files |
| `CreateRoomFrom` | `"CreateRoomFrom"` | Permission to create rooms from existing content |
| `CopyLink` | `"CopyLink"` | Permission to copy links to files |
| `Embed` | `"Embed"` | Permission to embed content |
