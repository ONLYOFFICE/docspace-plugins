---
toc_max_heading_level: 3
toc_min_heading_level: 3
hide_title: true
---

# Actions

Defined in: [enums/Actions.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L22)

A collection of events that will be processed on the portal side.

### updateProps

```ts
updateProps: "update-props";
```

Defined in: [enums/Actions.ts:37](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L37)

Calls a function to update the state of the item which action was passed.
It does not work if the "newProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  newProps: {...acceptButton, isDisabled: true},
  actions: [Actions.showToast, Actions.updateStatus, Actions.updateProps],
  toastProps,
}
```

### updateContext

```ts
updateContext: "update-context";
```

Defined in: [enums/Actions.ts:61](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L61)

Calls a function to update the state of the parent or child items which were passed.
It does not work if the "contextProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateProps, Actions.updateContext],
  newProps: {...nameInputProps, value},
  contextProps: [
    {
      name: "accept-button",
      props: {
        ...acceptButtonProps,
        isDisabled: !value,
      },
    },
  ],
}
```

### updateStatus

```ts
updateStatus: "update-status";
```

Defined in: [enums/Actions.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L76)

Calls a function to update the plugin status.

#### Example

```typescript
const message: IMessage = {
  newProps: {...acceptButton, isDisabled: true},
  actions: [Actions.showToast, Actions.updateProps, Actions.updateStatus],
  toastProps,
}
```

### updateContextMenuItems

```ts
updateContextMenuItems: "update-context-menu-items";
```

Defined in: [enums/Actions.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L89)

Calls a function to update all the context menu items.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateContextMenuItems],
}
```

### updateInfoPanelItems

```ts
updateInfoPanelItems: "update-info-panel-items";
```

Defined in: [enums/Actions.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L102)

Calls a function to update all the info panel items.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateInfoPanelItems],
}
```

### updateMainButtonItems

```ts
updateMainButtonItems: "update-main-button-items";
```

Defined in: [enums/Actions.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L115)

Calls a function to update all the main button menu items.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateMainButtonItems],
}
```

### updateProfileMenuItems

```ts
updateProfileMenuItems: "update-profile-menu-items";
```

Defined in: [enums/Actions.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L128)

Calls a function to update all the profile menu items.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateProfileMenuItems],
}
```

### updateFileItems

```ts
updateFileItems: "update-file-items";
```

Defined in: [enums/Actions.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L141)

Calls a function to update all the file items.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateFileItems],
}
```

### updateEventListenerItems

```ts
updateEventListenerItems: "update-event-listener-items";
```

Defined in: [enums/Actions.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L153)

Calls a function to update all the event listener items.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateEventListenerItems],
}
```

### showToast

```ts
showToast: "show-toast";
```

Defined in: [enums/Actions.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L169)

Calls a function to display a toast notification after the user actions.
It does not work if the "toastProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  newProps: {...acceptButton, isDisabled: true},
  actions: [Actions.showToast, Actions.updateProps, Actions.updateStatus],
  toastProps,
}
```

### showCreateDialogModal

```ts
showCreateDialogModal: "show-create-dialog-modal";
```

Defined in: [enums/Actions.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L199)

Calls a function to open a modal window for creating certain item (file, folder, etc.).
It does not work if the "createDialogProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.showCreateDialogModal],
  createDialogProps: {
    title: "Create diagram",
    startValue: "New diagram",
    visible: true,
    isCreateDialog: true,
    extension: ".drawio",
    onSave: async (e: any, value: string) => {
      await drawIo.createNewFile(value)
    },
    onCancel: (e: any) => {
      drawIo.setCurrentFolderId(null)
    },
    onClose: (e: any) => {
      drawIo.setCurrentFolderId(null)
    },
  },
}
```

### updateCreateDialogModal

```ts
updateCreateDialogModal: "update-create-dialog-modal";
```

Defined in: [enums/Actions.ts:216](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L216)

Calls a function to update a modal window for creating certain item (file, folder, etc.).
It does not work if the "createDialogProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateCreateDialogModal],
  createDialogProps: {
    title: "some title value",
  },
};
```

### showModal

```ts
showModal: "show-modal";
```

Defined in: [enums/Actions.ts:231](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L231)

Calls a function to open a modal window.
It does not work if the "modalDialogProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.showModal],
  modalDialogProps: openFromUrlProps,
}
```

### closeModal

```ts
closeModal: "close-modal";
```

Defined in: [enums/Actions.ts:244](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L244)

Calls a function to close a modal window.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.closeModal],
}
```

### sendPostMessage

```ts
sendPostMessage: "send-post-message";
```

Defined in: [enums/Actions.ts:250](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L250)

Calls a function to send a message to a frame.
It does not work if the "postMessage" parameter is not passed to the message or the specified frame is not found.

### saveSettings

```ts
saveSettings: "save-settings";
```

Defined in: [enums/Actions.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L274)

Calls a function to save the data that was transferred in the "settings" parameter
and returns it in the "setAdminPluginSettingsValue" method each time the plugin is requested.
It functions only when the "Save" button is clicked in the "Settings" block.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.sendPostMessage],
  postMessage: {
    frameId: this.frameId,
    message: {
      action: "export",
      format: this.format,
      xml: msg.xml,
      spinKey: "export",
    },
  },
}
```

### showSelector

```ts
showSelector: "show-selector";
```

Defined in: [enums/Actions.ts:292](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L292)

Calls a function to display a selector.
It does not work if the "selectorProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.showSelector],
  selectorProps: {
    type: SelectorType.Base,
    props: { ...selectorProps },
  },
}
```

### updateSelector

```ts
updateSelector: "update-selector";
```

Defined in: [enums/Actions.ts:310](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L310)

Calls a function to update a selector.
It does not work if the "selectorProps" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.updateSelector],
  selectorProps: {
    type: SelectorType.Base,
    props: { ...selectorProps },
  },
}
```

### closeSelector

```ts
closeSelector: "close-selector";
```

Defined in: [enums/Actions.ts:323](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L323)

Calls a function to close a selector.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.closeSelector],
}
```

### addFloatingOperationsButton

```ts
addFloatingOperationsButton: "add-floating-operations-button";
```

Defined in: [enums/Actions.ts:342](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L342)

Calls a function to add operations in floating button.
Multiple plugins can show operations simultaneously - they will be aggregated.
It does not work if the "floatingOperationsButtonProps" parameter is not passed to the message.

**Note:** Each floating operations is identified by its id. Calling this  action again
will not replace the previous operations.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.addFloatingOperationsButton],
  floatingOperationsButtonProps: { ...floatingOperationsButtonProps },
}
```

### updateFloatingOperationsButton

```ts
updateFloatingOperationsButton: "update-floating-operations-button";
```

Defined in: [enums/Actions.ts:371](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L371)

Calls a function to update operations in floating button.
It does not work if the "floatingOperationsButtonProps" parameter is not passed to the message.

#### Examples

```typescript
const message: IMessage = {
  actions: [Actions.updateFloatingOperationsButton],
  floatingOperationsButtonProps: { ...floatingOperationsButtonProps },
}
```

```typescript
onLoad(dispatchMessage) {
  const message: IMessage = {
    actions: [Actions.updateFloatingOperationsButton],
    floatingOperationsButtonProps: { ...floatingOperationsButtonProps },
  }
  dispatchMessage(message)
}
```

#### Remarks

To update the status directly, you can use the "dispatchMessage" callback from the onLoad event.

### removeFloatingOperationsButton

```ts
removeFloatingOperationsButton: "remove-floating-operations-button";
```

Defined in: [enums/Actions.ts:386](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L386)

Calls a function to remove the floating operations.
It does not work if the "floatingOperationsButtonPropsId" parameter is not passed to the message.

#### Example

```typescript
const message: IMessage = {
  actions: [Actions.removeFloatingOperationsButton],
  floatingOperationsButtonPropsId: floatingOperationsButtonProps.id,
}
```

### navigate

```ts
navigate: "navigate";
```

Defined in: [enums/Actions.ts:393](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L393)

Calls a function to navigate to the specified path.
All actions listed after navigate will be called after the navigation is complete.
It does not work if the "navigatePath" parameter is not passed to the message.

### openInfoPanel

```ts
openInfoPanel: "open-info-panel";
```

Defined in: [enums/Actions.ts:398](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L398)

Calls a function to open the plugin info panel.

### showMediaViewer

```ts
showMediaViewer: "show-media-viewer";
```

Defined in: [enums/Actions.ts:403](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L403)

Calls a function to open the plugin media viewer.

### updateMediaViewer

```ts
updateMediaViewer: "update-media-viewer";
```

Defined in: [enums/Actions.ts:408](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L408)

Calls a function to update the plugin media viewer.

### closeMediaViewer

```ts
closeMediaViewer: "close-media-viewer";
```

Defined in: [enums/Actions.ts:413](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L413)

Calls a function to close the plugin media viewer.
