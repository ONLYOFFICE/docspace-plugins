---
sidebar_label: "Rooms"
toc_max_heading_level: 3
hide_title: true
---

# Rooms

Enumerations for DocSpace room types and search scopes.

## RoomSearchArea

Defined in: [enums/Rooms.ts:9](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L9)

Defines the available search scopes for rooms within a room selector.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `Any` | `"Any"` | Search across all available rooms. |
| `Active` | `"Active"` | Search only within active rooms. |
| `Archive` | `"Archive"` | Search only within archived rooms. |
| `Templates` | `"Templates"` | Search only within room templates. |
## RoomsType

Defined in: [enums/Rooms.ts:23](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L23)

Defines the different types of rooms available in the system.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `PublicRoom` | `"public-room"` | A public room accessible to a wide audience. |
| `FormRoom` | `"form-room"` | A room designed for filling out forms. |
| `EditingRoom` | `"editing-room"` | A room focused on collaborative document editing. |
| `VirtualDataRoom` | `"virtual-data-room"` | A secure room for data storage and review. |
| `CustomRoom` | `"custom-room"` | A room with custom permissions and settings. |
