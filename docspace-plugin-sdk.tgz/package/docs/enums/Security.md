---
toc_max_heading_level: 3
hide_title: true
---

# Security

Defined in: [enums/Security.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L22)

Defines the supported room/folder security parameters.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `Copy` | `"Copy"` | Permission to copy files and folders |
| `CopySharedLink` | `"CopySharedLink"` | Permission to copy sharing links |
| `CopyTo` | `"CopyTo"` | Permission to copy items to other locations |
| `Create` | `"Create"` | Permission to create new files and folders |
| `Delete` | `"Delete"` | Permission to delete items |
| `Download` | `"Download"` | Permission to download files |
| `Duplicate` | `"Duplicate"` | Permission to create duplicates of items |
| `EditAccess` | `"EditAccess"` | Permission to modify access rights |
| `EditRoom` | `"EditRoom"` | Permission to modify room settings |
| `Move` | `"Move"` | Permission to move items |
| `MoveTo` | `"MoveTo"` | Permission to move items to other locations |
| `Mute` | `"Mute"` | Permission to mute notifications |
| `Pin` | `"Pin"` | Permission to pin items |
| `Read` | `"Read"` | Permission to view and read content |
| `Rename` | `"Rename"` | Permission to rename items |
| `CreateRoomFrom` | `"CreateRoomFrom"` | Permission to create rooms from existing content |
| `CopyLink` | `"CopyLink"` | Permission to copy links to files |
| `Embed` | `"Embed"` | Permission to embed content |
