---
toc_max_heading_level: 3
hide_title: true
---

# Events

Defined in: [enums/Events.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L22)

Defines the supported event types for the plugin system.

### Enumeration Members

| Member | Value | Description |
| :------ | :------ | :------ |
| `CREATE` | `"create"` | Triggered when a new item is created |
| `RENAME` | `"rename"` | Triggered when an item is renamed |
| `ROOM` | `"create_room"` | Triggered when a new room is created |
| `ROOM` | `"edit_room"` | Triggered when a room is edited |
| `CHANGE` | `"change_column"` | Triggered when a column configuration is changed |
| `CHANGE` | `"change_user_type"` | Triggered when a user's type or role is modified |
| `CREATE` | `"create_plugin_file"` | Triggered when a new file is created through a plugin |
