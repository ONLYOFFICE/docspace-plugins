---
sidebar_position: 5
---

# Enums

Enumerations for actions, component types, events, file types, security permissions, room types and other SDK-wide constants.

Import and use these typed constants in place of raw strings throughout your plugin.

## Overview

Available enumerations:

| Interface | Description |
| --- | --- |
| [`Actions`](Actions.md) | A collection of events that will be processed on the portal side. |
| [`Components`](Components.md) | Defines the available UI component. |
| [`Devices`](Devices.md) | Defines the supported device types. |
| [`Events`](Events.md) | Defines the supported event types for the plugin system. |
| [`Files`](Files.md) | Defines the supported file types. |
| [`Plugins`](Plugins.md) | Defines the supported plugin statuses. |
| [`Rooms`](Rooms.md) | Defines the available search scopes for rooms within a room selector. |
| [`Security`](Security.md) | Defines the supported room/folder security parameters. |
| [`Selector`](Selector.md) | Defines the types of selector components that can be rendered. |
| [`UsersType`](UsersType.md) | Defines the supported user types. |
| [`Utility`](Utility.md) | Enum for filter type used in file selectors. |